title: 始终保持 solo docker 镜像最新版本
date: '2019-03-06 11:09:57'
updated: '2019-03-18 00:17:15'
tags: [Docker, Solo]
permalink: /articles/2019/03/05/1551841793596.html
---
>[沐风](https://blog.mufengs.com)

成品图

![image.png](https://img.hacpai.com/file/2019/03/image-c94b2bbe.png)

dockerhub截图
![image.png](https://img.hacpai.com/file/2019/03/image-62116eb0.png)

## 功能
一键启动solo
```
docker run -d --restart="always"  -p 8080:8080 --name=solo mufeng5619/solo_auto:release-x.x.x
```
这边的x.x.x就是solo的版本好，比如最新的3.3.0
数据持久化的话，可以通过挂载的方式自己搞下，不清楚的可以给我提issus
https://github.com/mufengcoding/docker/tree/master/solo

默认使用h2数据库   


镜像随着solo一起更新，方便省事 无需自己构建 体积小只有 680M

跟随github自动更新，始终保持最新镜像

加入autoupdate功能，通python做自动获取solo版本号，打包solo镜像，提交git，打相应的tag的脚本，然后dockerhub那边自动build

项目代码见：
https://github.com/mufengcoding/docker





## Todo
下个更新加入mysql



