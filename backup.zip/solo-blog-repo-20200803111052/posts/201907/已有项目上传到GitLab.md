title: 已有项目上传到 GitLab
date: '2019-07-10 15:29:13'
updated: '2019-07-10 15:30:18'
tags: [Python, GitLab]
permalink: /articles/2019/07/10/1562743750381.html
---
生成requirements.txt文件
```
pip freeze > requirements.txt
```
安装requirements.txt依赖
```
pip install -r requirements.txt
```
新建一个项目devops
![image.png](https://img.hacpai.com/file/2019/07/image-d17b6612.png)

本地项目命令行下执行
1. git init 生成本地./git 文件

```html
git init
```

2. 添加需要上传的文件
```
git add *         #需要上传的文件  文件夹
```
3. 对上传的文件进行说明
```
git commit -m "**"          #双引号内对上传文件描述
```

4.关联远程仓库，添加后，远程库的名字就是 origin，这是 Git 默认的叫法，也可以改成别的，但是 origin 这个名字一看就知道是远程库。
```
 git remote add origin http://192.168.1.1/projects/new.git
```

5.上传分支
```
git push origin master
```
这边报错了
> ! [remote rejected] master -> master (pre-receive hook declined)
> remote: GitLab: You are not allowed to force push code to a protected branch on this project.

需要解除项目master的保护模式，或者新建分支
![image.png](https://img.hacpai.com/file/2019/07/image-4ad6e5a0.png)


最后提交成功
![image.png](https://img.hacpai.com/file/2019/07/image-316ee708.png)

设置关注模式
```
git branch --set-upstream-to=origin/master master
```








