title: linux 下的 qq 又活了
date: '2019-11-04 20:49:41'
updated: '2019-11-04 20:49:41'
tags: [Linux]
permalink: /articles/2019/11/04/1572871779796.html
---
*    Linux QQ全新回归
* 支持x64、ARM64、MIPS64四种架构
* 优化消息体验，完善消息收发能力
* 性能优化
![image.png](https://img.hacpai.com/file/2019/11/image-a4015a77.png)

https://im.qq.com/linuxqq/index.html
