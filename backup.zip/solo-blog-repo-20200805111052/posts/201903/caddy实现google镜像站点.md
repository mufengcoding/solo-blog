title: caddy 实现 google 镜像站点
date: '2019-03-29 00:29:47'
updated: '2019-03-29 08:58:07'
tags: [Caddy]
permalink: /articles/2019/03/28/1553790582694.html
---
>[沐风](https://hacpai.com/forward?goto=https%3A%2F%2Fblog.mufengs.com)

[https://blog.mufengs.com/google](https://guge.schove.com/)

原先是想为了解决跨域，而做的方向代理
后来发现不管怎么配置都不生效，不像nginx那么灵动，多个location的时候
然后悲催的是，把caddy搞GG了

作为一个资深运维会被这么点小困难搞慌了吗，不存在的（删库都不慌，ps：内心慌的一笔）

查阅[caddy官网](https://caddyserver.com/docs)

重新安装一次
这边安利caddy一波的是插件安装很方便

下载caddy 
https://caddyserver.com/download

![image.png](https://img.hacpai.com/file/2019/03/image-5d6ece3b.png)

这边我们可以选择我们的服务器系统，需要的插件等

选完了之后你可以直接下载，他也会帮你生成一个sh脚本

![image.png](https://img.hacpai.com/file/2019/03/image-bea3bc30.png)

我这边配置完了是这样的
```
CADDY_TELEMETRY=on curl https://getcaddy.com | bash -s personal http.authz,http.cache,http.expires,http.filebrowser,http.filter,http.forwardproxy,http.geoip,http.git,http.ipfilter,http.locale,http.login,http.mailout,http.minify,http.nobots,http.proxyprotocol,http.ratelimit,http.realip,http.upload
```
这边等待5分钟左右，就会发现安装成功
讲到这里忽然发现跑题了，峰会路转下

google镜像配置
![image.png](https://img.hacpai.com/file/2019/03/image-484c0ad4.png)

然后启动caddy
`
 nohup caddy -conf=Caddyfile &
`

是不是很简单我们测试下

访问 测试下

![image.png](https://img.hacpai.com/file/2019/03/image-e599bea1.png)

这边有熟悉caddy的大佬，可以交流下怎么做多个反向代理


