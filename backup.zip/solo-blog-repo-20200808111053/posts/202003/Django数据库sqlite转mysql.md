title: Django数据库sqlite转mysql
date: '2020-03-05 11:29:28'
updated: '2020-03-05 11:29:28'
tags: [Django]
permalink: /articles/2020/03/04/1583378968260.html
---
网上的 百度出来结果十个有九个坑，还有一个半吊子。幸亏备份了，弄出了一个真实可行的

## 1.添加mysql做为slave

```ini
DATABASES = {
    'default': {
         'ENGINE': 'django.db.backends.sqlite3',
         'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
     },
    'slave': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'devops',
        'USER': 'root',
        'PASSWORD': 'ddddddd',
        'HOST': '192.168.0.2',
        'PORT': '3306',
    }
}
```

## 2.安装mysqlclient

```shell
pip install mysqlclient
```

## 3.迁移数据库到slave

```bash
python manage.py migrate --database slave
```

## 4.确认是否有遗漏再执行一边

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py migrate --database slave
```

## 5.导出数据

```python
python manage.py dumpdata --database default > dumpdata20200305.json
```

## 6.导入数据到mysql

```python
python manage.py loaddata --database slave  dumpdata20200305.json
```

mac下会出现一个报错

第一行会有一个当前目录的字符串，删掉第一就可以了

## 7. 修改配置文件settings.py

将配置修改default为mysql

```ini
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'devops',
        'USER': 'root',
        'PASSWORD': 'xxxx',
        'HOST': 'xxx',
        'PORT': '3306',
    }
}
```

## 8.访问测试


搞定收工！
![image.png](https://img.hacpai.com/file/2020/03/image-82115c1e.png)

