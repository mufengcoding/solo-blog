title: 'git fatal: 拒绝合并无关的历史的错误解决'
date: '2019-10-25 17:29:08'
updated: '2019-10-25 17:29:08'
tags: [GitHub]
permalink: /articles/2019/10/25/1571995748461.html
---
`  
在pull 时候, 添加–allow-unrelated-histories参数 即可.`

 

`$ git pull origin master --allow-unrelated-histories   `
