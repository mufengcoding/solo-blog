title: Github&dockerhub 实现 dockerfile 持续构建镜像
date: '2019-03-06 10:12:08'
updated: '2019-03-06 10:12:08'
tags: [GitHub, Docker]
permalink: /articles/2019/03/05/1551838325812.html
---
>[沐风](https://blog.mufengs.com)

Link repository service
=======================

首先需要绑定一个仓库服务（Github）：
1.点击右上角的头像
2.选择下拉中的Account Settings
3.链接github服务
![image.png](https://img.hacpai.com/file/2019/03/image-e8a0ede1.png)

Create an automated build
=========================

新建一个自动构建的dockerhub仓库
![image.png](https://img.hacpai.com/file/2019/03/image-b68bfddc.png)

配置自动构建规则
![image.png](https://img.hacpai.com/file/2019/03/image-155fcf91.png)

这样的话 每一次提交到master都会触发构建
