title: https 证书不自动更新
date: '2020-02-18 20:53:25'
updated: '2020-02-18 20:53:25'
tags: [HTTPS]
permalink: /articles/2020/02/18/1582030402261.html
---
之前用的容器自动更新 https 证书，这两天陆陆续续收到证书到期的邮件

进入服务器，查看日志，出现如下

```
"Could not get nonce, let's try again
```

查看相关文章，得出是 acme.sh 的 版本太久的原因导致的

```
docker exec acme /bin/bash
cd .acme.sh
./acme.sh  --upgrade --auto-upgrade

```

刷新页面发现证书更新成功
