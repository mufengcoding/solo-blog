title: 优雅的将 solo 从 2.96 升级到 2.99
date: '2019-03-08 16:08:36'
updated: '2019-03-08 16:08:36'
tags: [Solo, 升级, 博客]
permalink: /articles/2019/03/08/1549987072007.html
---
>[沐风博客](https://blog.mufengs.com)

```
wget https://github.com/b3log/solo/releases/download/v2.9.7/solo-2.9.7.war
wget https://github.com/b3log/solo/releases/download/v2.9.7/solo-2.9.8.war
wget https://github.com/b3log/solo/releases/download/v2.9.7/solo-v2.9.9.war
```
按顺序执行就完事了
```
unzip solo-2.9.7.war -d blog2.97/
unzip solo-2.9.8.war -d blog2.98/
unzip solo-2.9.9.war -d blog2.99/
```
进入解压的目录下
`
cp -r /root/blog/WEB-INF/classes/*.properties WEB-INF/classes/
`
重新启动
```
ps -ef |grep java

kill 914
```
`
nohup java -cp WEB-INF/lib/*:WEB-INF/classes org.b3log.solo.Starter >/dev/null 2>&1 &
`

这边遇到三个问题
1.是配置文件那边还是不要覆盖了 ，对比以前的手改吧
2.同步功能后台报b3key不对，但是两边是一致的，不知道你们有没有遇到这样的问题
3.github的仓库只同步了一个如下图
![imagepng](https://img.hacpai.com/file/2019/02/image-16d1f23f.png)

