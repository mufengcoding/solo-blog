title: instant.page提升博客加载速度
date: '2020-03-02 10:15:19'
updated: '2020-03-02 10:25:48'
tags: [前端]
permalink: /articles/2020/03/01/1583115319033.html
---
有一项技术叫做 prefetch，这个技术，其实说白了，就是一项预加载技术，当用户有意向访问某个页面之前，浏览器首先对此页面进行预加载，当用户真正点击链接后，会从预加载的缓存中直接读取页面内容，缩短页面的加载时间。

而如何来使用这项技术？其实在 html5 的链接标签中有一个 rel 属性，其中有个参数就是 prefetch，不过使用的人不多。

本文介绍的 instant.page，就是使用这项技术的一个脚本，脚本会根据用户鼠标在链接上的停留时间进行判断，当达到 65 毫秒，用户有一半的机会打开此链接，instant.page 将会对此页面进行预加载。

使用
1、使用官方提供的带有 Cloudflare 加速的脚本

instant.page 的使用非常简单：
```
<script src="//instant.page/1.2.2" type="module"></script>
```
只需要把这行代码添加到网站的 </body> 之前即可。

2、自托管

建议服务器在国内的朋友使用。只需将下面这段 js 上传到自己服务器，然后在 </body> 标签之前根据路径添加下面的代码即可。

然后在 </body> 标签之前根据路径添加下面的代码即可。

[instantclick-1.2.2.js](https://blog.mufengs.com/instantclick-1.2.2.js)
```
<script src="存放路径/instantclick-1.2.2.js" type="module"></script>
```
3、TRHX提供的 cdn。使用 jsDeliver CDN 加速，不用担心拖慢速度。
```
<script src="https://cdn.jsdelivr.net/gh/TRHX/CDN-for-itrhx.com@2.0.2/js/instantclick-1.2.2.js" type="module"></script>

```
[屏幕录制20200302上午10.09.41.mov](https://img.hacpai.com/file/2020/03/屏幕录制20200302上午10.09.41-92295e90.mov)
