title: 'easyexcel 程序启动时报: Invalid byte tag in constant pool: 19'
date: '2020-07-09 16:38:03'
updated: '2020-07-09 16:38:03'
tags: [Docker, Tomcat, Java]
permalink: /articles/2020/07/09/1594283867824.html
---
## 01.环境

开发环境

tomcat版本 9

测试环境

tomcat版本 8.5.9

## 02.问题描述

后端小伙伴用了easyexcel ,之前有其他项目用到过在tomcat8.5.49下正常运行✅，在tomcat8.5.9版本下运行，疯狂爆如题的错误。

## 03.解决方法

网上查找相关资料，发现大多数和log4j升级版本相关，更新tomcat版本就可以了

于是基于原先的镜像更新了tomcat的版本

```
docker run -d --name=tomcat_tmp tomcat:9

docker cp tomcat_tmp:/usr/local/tomcat ./
```

更新Dockerfile

```
From tomcat:8.5.9

....
ADD tomcat /usr/local/tomcat
....
```

将容器删除，使用的新的镜像运行即可，解决了问题
