title: '[日常 LeetCode] 2. Add Two Numbers'
date: '2019-04-02 22:37:59'
updated: '2019-04-02 22:37:59'
tags: [Python]
permalink: /articles/2019/04/02/1554215874877.html
---
Q:
You are given two**non-empty**linked lists representing two non-negative integers. The digits are stored in**reverse order**and each of their nodes contain a single digit. Add the two numbers and return it as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.

**Example:**

```
**Input:** (2 -> 4 -> 3) + (5 -> 6 -> 4)
**Output:** 7 -> 0 -> 8
**Explanation:** 342 + 465 = 807.
```
以下解答方式纯属抄的，尴尬的是好几天 没看懂题目
A:
```
# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    def addTwoNumbers(self, l1: ListNode, l2: ListNode) -> ListNode:
        c1=l1
        c2=l2
        c_val=''
        c2_val=''
        while c1:
            c_val += str(c1.val)
            c1=c1.next
        while c2:
            c2_val += str(c2.val)
            c2=c2.next
        c_val = c_val[::-1]
        c2_val=c2_val[::-1]

        added = int(c_val) + int(c2_val)

        added =str(added)
        added =added[::-1]

        LL=[]
        for i in added:

            LL.append(int(i))


        return LL
```