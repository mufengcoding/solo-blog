title: Nginx 反向代理过程中出现 https 访问 http 问题
date: '2020-02-13 00:16:52'
updated: '2020-02-13 00:16:52'
tags: [NGINX]
permalink: /articles/2020/02/12/1581524209582.html
---
一般对于浏览器来说 https 的网站 中访问 http 是 如下有问题的

```
Mixed Content: The page at 'https://www.xxx.com/' was loaded over HTTPS, 
but requested an insecure script 'http://www.xxx.com/a.js'.
 This request has been blocked; the content must be served over HTTPS.
```

修改 nginx 的 proxy 配置部分，如下所示

```ini
add_header Content-Security-Policy upgrade-insecure-requests;
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
```

重启 nginx，这个时候我们会发现，问题解决了
