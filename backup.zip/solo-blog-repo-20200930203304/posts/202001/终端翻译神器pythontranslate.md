title: 终端翻译神器 python-translate
date: '2020-01-09 16:36:46'
updated: '2020-01-09 16:38:53'
tags: [Python]
permalink: /articles/2020/01/09/1578559002546.html
---
此项目改自[caspartse/python-translate](https://github.com/caspartse/python-translate)

因为python2今年停止维护，果断上python3。然后原先项目只能翻译单词，想翻译句子就比较蛋疼了，简单的改了下

https://github.com/mufengcoding/python-translate
使用效果
![image.png](https://img.hacpai.com/file/2020/01/image-9e46cda0.png)

欢迎大家来star，求个小✨🌟
