title: 关于 utools 官方自动化助手（获取公网 IP）bug 修复
date: '2020-06-25 21:19:06'
updated: '2020-06-25 21:19:06'
tags: [uTools]
permalink: /articles/2020/06/25/1593091067592.html
---
第一次使用自动化助手，随便开了一个获取公网ip，输入关键字发现没有反应

![image.png](https://b3logfile.com/file/2020/06/image-16144a34.png)

在官方代码中加入错误提示

```
https.get('https://api.ip.sb/ip' ,(res) => {
  if (res.statusCode !== 200) return
    res.on('data', (d) => {
      const ip = d.toString().trim()
      utools.copyText(ip)
      utools.showNotification('公网IP: ' + ip + ' 已复制到剪贴板')
      utools.simulateKeyboardTap('v', utools.isMacOs() ? 'command' : 'ctrl')
    })
}).on('error', (e) => {
//加上错误提示
  utools.showNotification('公网IP:   error'+e)
})[/colort]
```

在多吉上查询 nodejs https 证书过期，发现如下帖子
[https://blog.ipsfan.com/6277.html](https://blog.ipsfan.com/6277.html)

修改原代码如下

```
const https = require('https');
const options = {
  strictSSL: false,
  rejectUnauthorized: false
};

https.get('https://api.ip.sb/ip',options ,(res) => {
  if (res.statusCode !== 200) return
    res.on('data', (d) => {
      const ip = d.toString().trim()
      utools.copyText(ip)
      utools.showNotification('公网IP: ' + ip + ' 已复制到剪贴板')
      utools.simulateKeyboardTap('v', utools.isMacOs() ? 'command' : 'ctrl')
    })
}).on('error', (e) => {
  utools.showNotification('公网IP:   error'+e)
})
```

修复完成✅，优秀！

![image.png](https://b3logfile.com/file/2020/06/image-aec020c9.png)

上一个我用的插件

![image.png](https://b3logfile.com/file/2020/06/image-f057b2c8.png)

很是方便快捷，多端适配。欢迎大家来体验！👏👏
