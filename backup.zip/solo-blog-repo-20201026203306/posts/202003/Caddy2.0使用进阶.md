title: Caddy2.0使用进阶
date: '2020-03-20 15:45:59'
updated: '2020-03-20 15:46:28'
tags: [Caddy]
permalink: /articles/2020/03/20/1584690359268.html
---
![](https://img.hacpai.com/bing/20200307.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 01.起因

有小伙伴问到关于 caddy2.0 的高阶使用，之前只是简单的使用，以及自己的博客维护，于是乎搞之！

原文地址：《[Https 就是这么简单之 Caddy2](https://blog.mufengs.com/articles/2020/01/08/1578496435040.html)》

待解决如下：
1.关于 curl localhost:2019/load 这个接口的防护
2.docker 版的 autos ave. JSON 配置文件路径和普通的配置文件 auto save. 路径不一样，无论放哪里都一样，关键是如何更改这个路径？caddy envrion 只能打印出这个路径，但是没有说怎么配置这个路径，用 JSON 配置吗？如何配置？
3.caddy2 能不能配置成 systemd 服务了

## 02. upload 接口防护

貌似研究了半天，貌似是 API 是运行着的，应该是内嵌到底层的，不过这个问题也没有什么问题，因为他只能通过 localhost 的方式调用，除非黑进系统了，但黑进系统的话，那不运行 API 服务也是可以修改文件的，所以这个问题不大

## 03. docker 版的 autos ave. JSON 配置文件路径修改

大致看了下，docker 版本的 caddy 是做成服务的，每次直接自动转换 caddyfile 到
autos ave. JSON 这个文件里面， JSON 文件的话，路径没有必要手动指定，因为你改了/etc/caddy/caddyfile 这个文件，会自动适配到 JSON 文件的。

使用指定路经的 JSON

```
curl localhost:2019/load \
  -X POST \
  -H "Content-Type: application/json" \
  -d @caddy.json
```

用这个就可以了  @后面写 JSON 的路径

## 04. caddy2 能不能配置成 systemd 服务

这个在官方文档是有说到的，如下图位置
![image.png](https://img.hacpai.com/file/2020/03/image-e821c879.png)

### 4.1 手动安装为 Linux 服务

要求：
一个 caddy 二进制您下载或从源代码构建
系统版本 232 或更高版本
超级用户权限
将 caddy 二进制文件移到您的中 $PATH，例如：

```
sudo mv caddy /usr/bin/
```

测试它是否有效：

```
caddy version
```

创建一个名为的组 caddy：

```
groupadd --system caddy
```

创建一个名为的用户 caddy，该用户具有可写的主文件夹：

```
useradd --system \
	--gid caddy \
	--create-home \
	--home-dir /var/lib/caddy \
	--shell /usr/sbin/nologin \
	--comment "Caddy web server" \
	caddy
```

接下来，获取此 systemd 单位文件并将其保存到/etc/systemd/system/caddy.service。仔细检查 ExecStart 和 ExecReload 指令-确保二进制文件的位置和命令行参数对于您的安装是正确的。

在继续之前，请仔细检查您的 systemd 和 Caddy 配置是否正确。确保您的配置文件在命令中指定的位置。

要首次启动该服务，请执行通常的 systemctl 舞蹈：

```
sudo systemctl daemon-reload
sudo systemctl enable caddy
sudo systemctl start caddy
```

验证它正在运行：

```
systemctl status caddy
```

使用我们的官方服务文件运行时，Caddy 的输出将重定向到 journalctl：

```
journalctl -u caddy
```

要对配置文件进行任何更改（如果使用的话）：

```
sudo systemctl reload caddy
```

您可以通过以下方式停止服务：

```
sudo systemctl stop caddy
```

### 4.2 使用 yum 安装 caddy，并设置自启动

* RHEL/CentOS 7

```
yum-config-manager --add-repo https://copr.fedorainfracloud.org/coprs/g/caddy/caddy/repo/epel-7/group_caddy-caddy-epel-7.repo


```

* RHEL/CentOS 7

```
yum install caddy
```

启动

```
service caddy start
```

设置开机自启动

```
systemctl enable caddy
```
