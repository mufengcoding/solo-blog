title: ArchLinux 安装 seafile
date: '2019-02-28 16:39:04'
updated: '2019-02-28 16:39:04'
tags: [seafile, Linux]
permalink: /articles/2019/02/28/1551343140136.html
---
>[沐风](https://blog.mufengs.com)

安装docker
`
pacman -S docker
`
pull seafile环境
`
docker pull jenserat/seafile
`

启动容器
```
docker run -d --restart=always -p 10001:10001 -p 12001:12001 -p 8000:8000 -p 8080:8080 -p 8082:8082 -v/home/app/seafile:/opt/seafile -e autostart=true --name=seafile jenserat/seafile
```

进入容器
`
docker exec -it seafile bash
`
`
cd /opt/
`
```
wget http://seafile-downloads.oss-cn-shanghai.aliyuncs.com/seafile-server_6.0.8_x86-64.tar.gz
```
`
tar -zxcf seafile-server_6.0.8_x86-64.tar.gz
`
`
mv seafile-server_6.0.8_x86-64 seafile
`
依次执行三个命令
![image.png](https://img.hacpai.com/file/2019/02/image-8df68717.png)

查看进程
![image.png](https://img.hacpai.com/file/2019/02/image-3881599e.png)

访问页面
http://127.0.0.1:8000
![image.png](https://img.hacpai.com/file/2019/02/image-bbc6acd9.png)

就这么简单用来了，拯救mac的空间不够![image.png](https://img.hacpai.com/file/2019/02/image-72edcbbc.png)




