title: python 导出项目依赖包
date: '2020-01-02 16:06:52'
updated: '2020-01-02 16:06:52'
tags: [Python]
permalink: /articles/2020/01/02/1577952409887.html
---
导出项目中使用的依赖基本都是``` pip freeze >  requirements.txt  ```

这样导出来的项目依赖，可能会包含环境中的依赖
```shell
pip install pipreqs -i https://pypi.tuna.tsinghua.edu.cn/simple
```
使用方法

进入项目的根目录
```
pipreqs ./
```
在项目根目录下生成一个 requirements.txt  文件

安装依赖的时候使用
```
pip install -r  requirements.txt
```

