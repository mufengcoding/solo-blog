title: mysql优化工具mysqltuner
date: '2020-04-10 21:04:31'
updated: '2020-04-10 21:04:31'
tags: [MySQL, 数据库运维, 服务器运维]
permalink: /articles/2020/04/10/1586523870867.html
---
![](https://img.hacpai.com/bing/20180824.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 01. 介绍

https://github.com/major/MySQLTuner-perl
MySQLTuner是用Perl编写的脚本，可让您快速查看MySQL安装并进行调整以提高性能和稳定性。 检索当前配置变量和状态数据，并以简短的格式提供一些基本的性能建议。

在此最新版本中，MySQLTuner支持MySQL / MariaDB / Percona Server的约300个指标。

MySQLTuner持续更新，并且指标收集逐周增加，以支持许多配置，例如Galera Cluster，TokuDB，Performance模式，Linux OS指标，InnoDB，MyISAM，Aria等。

## 02. 环境初始化

服务器环境：
```
CentOS Linux release 7.7.1908 (Core)

model name	: Intel(R) Xeon(R) CPU @ 2.00GHz
model name	: Intel(R) Xeon(R) CPU @ 2.00GHz
physical id	: 0
physical id	: 0

MemTotal:        1882032 kB
```

数据库：

```
docker run -d -p 3306:3306 --env MYSQL_ROOT_PASSWORD=123456 mysql
```


## 03. 安装mysqltuner

```
wget http://mysqltuner.pl/ -O mysqltuner.pl
wget https://raw.githubusercontent.com/major/MySQLTuner-perl/master/basic_passwords.txt -O basic_passwords.txt
wget https://raw.githubusercontent.com/major/MySQLTuner-perl/master/vulnerabilities.csv -O vulnerabilities.csv
```

## 04. 使用mysqltuner

```
perl mysqltuner.pl   --forcemem 1024 --host  10.170.0.6 --user root --pass root --buffers --dbstat --idxstat --sysstat --pfstat --tbstat --cvefile=./vulnerabilities.csv
```
如果执行报错
```
Can't locate Data/Dumper.pm in @INC (@INC contains: /usr/local/lib64/perl5 /usr/local/share/perl5 /usr/lib64/perl5/vendor_perl /usr/share/perl5/vendor_perl /usr/lib64/perl5 /usr/share/perl5 .) at ./mysqltuner.pl line 52
```
则需要安装perl依赖
```
 yum install 'perl(Data::Dumper)'
```


```
 >>  MySQLTuner 1.7.19 - Major Hayden <major@mhtx.net>
 >>  Bug reports, feature requests, and downloads at http://mysqltuner.com/
 >>  Run with '--help' for additional options and output filtering

[--] Skipped version check for MySQLTuner script
[--] Performing tests on 10.170.0.6:3306
[OK] Logged in using credentials passed on the command line
[--] Assuming 1024 MB of physical memory
[!!] Assuming 0 MB of swap space (use --forceswap to specify)
[OK] Currently running supported MySQL version 8.0.19

-------- System Linux Recommendations --------------------------------------------------------------
Look for related Linux system recommendations
[--] CentOS Linux release 7.7.1908 (Core)
[--] Machine type          : Virtual machine
[--] Internet              : Connected
[--] Number of Core CPU : 1

[--] Operating System Type : GNU/Linux
[--] Kernel Release        : 3.10.0-1062.12.1.el7.x86_64
[--] Hostname              : centos75
[--] Network Cards         :
[--] 	docker0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
[--] 	        inet 172.17.0.1  netmask 255.255.0.0  broadcast 172.17.255.255
[--] 	--
[--] 	eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1460
[--] 	        inet 10.170.0.6  netmask 255.255.255.255  broadcast 10.170.0.6
[--] 	--
[--] 	lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
[--] 	        inet 127.0.0.1  netmask 255.0.0.0
[--] 	--
[--] 	veth281034b: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
[--] 	        inet6 fe80::ccdd:79ff:fe3b:1fae  prefixlen 64  scopeid 0x20<link>
[--] Internal IP           : 10.170.0.6 172.17.0.1
[--] HTTP client found: /usr/bin/curl
[--] External IP           :   % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current,                                  Dload  Upload   Total   Spent    Le100    14  100    14    0     0     36      0 --:--:-- --:--:-- --:--:--    35, 35.220.214.171
[--] Name Servers          : 169.254.169.254
[--] Logged In users       :
[--] 	mac      pts/0        2020-04-10 12:32 (114.221.177.194)
[--] Ram Usages in Mb      :
[--] 	              total        used        free      shared  buff/cache   available
[--] 	Mem:           1837         665          90          16        1081         975
[--] 	Swap:             0           0           0
[--] Load Average          :
[--] 	top - 12:59:33 up 3 days,  3:10,  1 user,  load average: 0.02, 0.06, 0.06
[--] System Uptime         :
[--] 	 12:59:33 up 3 days,  3:10,  1 user,  load average: 0.02, 0.06, 0.06
[--] User process except mysqld used 144M RAM.
[--] Other user process except mysqld used less than 15% of total physical memory 14.16% (144M / 1G)
[--] mount point / is using 57 % of total space
[--] mount point /var/lib/docker/overlay2/03182f264b9db783d41706b288fdb9efd79541ec370b16948380b255fd05b1ce/merged is using 57 % of total space
[--] mount point / is using 2 % of max allowed inodes
[--] mount point /var/lib/docker/overlay2/03182f264b9db783d41706b288fdb9efd79541ec370b16948380b255fd05b1ce/merged is using 2 % of max allowed inodes
[--] Information about kernel tuning:
[--] 	fs.aio-max-nr = 65536
[--] 	fs.aio-nr = 2661
[--] 	fs.file-max = 184428
[--] 	vm.swappiness = 30
[!!] Swappiness is > 10, please consider having a value lower than 10
[--] TCP slot entries is > 100.
[!!] Max running total of the number of events is < 1M, please consider having a value greater than 1M

-------- Log file Recommendations ------------------------------------------------------------------
[!!] log_error is set to stderr MT can't read stderr

-------- Storage Engine Statistics -----------------------------------------------------------------
[--] Status: +ARCHIVE +BLACKHOLE +CSV -FEDERATED +InnoDB +MEMORY +MRG_MYISAM +MyISAM +PERFORMANCE_SCHEMA
[--] Data in InnoDB tables: 16.0K (Tables: 1)
[OK] Total fragmented tables: 0

-------- Analysis Performance Metrics --------------------------------------------------------------
[--] innodb_stats_on_metadata: OFF
[OK] No stat updates during querying INFORMATION_SCHEMA.

-------- Database Metrics --------------------------------------------------------------------------
[--] There is 0 Database(s).
[--] All User Databases:
[--]  +-- TABLE : 0
[--]  +-- ROWS  : 0
[--]  +-- DATA  : 0B(0%)
[--]  +-- INDEX : 0B(0%)
[--]  +-- SIZE  : 0B
[--]  +-- COLLA : 0 (NULL, utf8_bin, utf8_general_ci, utf8mb4_0900_ai_ci, utf8mb4_bin)
[--]  +-- ENGIN : 0 (NULL, InnoDB, CSV, PERFORMANCE_SCHEMA)


-------- Table Column Metrics ----------------------------------------------------------------------
[--] MySQL and Percona version 8 and greater have remove PROCEDURE ANALYSE feature

-------- Indexes Metrics ---------------------------------------------------------------------------
[--] Worst selectivity indexes:
[--] Unused indexes:

-------- Security Recommendations ------------------------------------------------------------------
[--] Skipped due to unsupported feature for MySQL 8

-------- CVE Security Recommendations --------------------------------------------------------------
[OK] NO SECURITY CVE FOUND FOR YOUR VERSION

-------- Performance Metrics -----------------------------------------------------------------------
[--] Up for: 23m 24s (24 q [0.017 qps], 19 conn, TX: 54K, RX: 1K)
[--] Reads / Writes: 100% / 0%
[--] Binary logging is enabled (GTID MODE: OFF)
[--] Physical Memory     : 1.0G
[--] Max MySQL memory    : 9.8G
[--] Other process memory: 145.0M
[--] Total buffers: 168.0M global + 65.1M per thread (151 max threads)
[--] P_S Max memory usage: 72B
[--] Galera GCache Max memory usage: 0B
[--] Global Buffers
[--]  +-- Key Buffer: 8.0M
[--]  +-- Max Tmp Table: 16.0M
[--] Per Thread Buffers
[--]  +-- Read Buffer: 128.0K
[--]  +-- Read RND Buffer: 256.0K
[--]  +-- Sort Buffer: 256.0K
[--]  +-- Thread stack: 280.0K
[--]  +-- Join Buffer: 256.0K
[--] Binlog Cache Buffers
[--]  +-- Binlog Cache: 32.0K
[OK] Maximum reached memory usage: 233.1M (22.77% of installed RAM)
[!!] Maximum possible memory usage: 9.8G (977.09% of installed RAM)
[!!] Overall possible memory usage with other process exceeded memory
[OK] Slow queries: 0% (0/24)
[OK] Highest usage of available connections: 0% (1/151)
[!!] Aborted connections: 21.05%  (4/19)
[--] Query cache have been removed in MySQL 8
[OK] No Sort requiring temporary tables
[OK] No joins without indexes
[OK] Temporary tables created on disk: 0% (0 on disk / 4 total)
[OK] Thread cache hit rate: 94% (1 created / 19 connections)
[OK] Table cache hit rate: 55% (99 open / 179 opened)
[OK] table_definition_cache(2000) is upper than number of tables(310)
[OK] Open file limit used: 0% (2/1M)
[OK] Table locks acquired immediately: 100% (4 immediate / 4 locks)
[OK] Binlog cache memory access: 100.00% (3 Memory / 3 Total)

-------- Performance schema ------------------------------------------------------------------------
[--] Memory used by P_S: 72B
[--] Sys schema is installed.
[--] Sys schema Version: 2.1.1

-------- Performance schema: Top 5 user per connection ---------------------------------------------
[--]  +-- 1: background	51 conn(s)
[--]  +-- 2: root	39 conn(s)

-------- Performance schema: Top 5 user per statement ----------------------------------------------
[--]  +-- 1: root	242 stmt(s)
[--]  +-- 2: background	1 stmt(s)

-------- Performance schema: Top 5 user per statement latency --------------------------------------
[--]  +-- 1: root	5543505451.6129
[--]  +-- 2: background	333773000.0000

-------- Performance schema: Top 5 user per lock latency -------------------------------------------
[--]  +-- 1: root	23120000000
[--]  +-- 2: background	0

-------- Performance schema: Top 5 user per nb full scans ------------------------------------------
[--]  +-- 1: root	14
[--]  +-- 2: background	0

-------- Performance schema: Top 5 user per rows sent ----------------------------------------------
[--]  +-- 1: root	2398
[--]  +-- 2: background	1

-------- Performance schema: Top 5 user per rows modified ------------------------------------------
[--]  +-- 1: root	0
[--]  +-- 2: background	0

-------- Performance schema: Top 5 user per io -----------------------------------------------------
[--]  +-- 1: background	1891
[--]  +-- 2: root	176

-------- Performance schema: Top 5 user per io latency ---------------------------------------------
[--]  +-- 1: background	567053922156
[--]  +-- 2: root	21365954616

-------- Performance schema: Top 5 host per connection ---------------------------------------------
[--]  +-- 1: 10.170.0.6	47 conn(s)
[--]  +-- 2: localhost	1 conn(s)

-------- Performance schema: Top 5 host per statement ----------------------------------------------
[--]  +-- 1: 10.170.0.6	142 stmt(s)
[--]  +-- 2: localhost	6 stmt(s)

-------- Performance schema: Top 5 host per statement latency --------------------------------------
[--]  +-- 1: localhost	5123038166.6667
[--]  +-- 2: 10.170.0.6	4909615206.8966

-------- Performance schema: Top 5 host per lock latency -------------------------------------------
[--]  +-- 1: 10.170.0.6	25278000000
[--]  +-- 2: localhost	3084000000
[--]  +-- 3: background	0

-------- Performance schema: Top 5 host per nb full scans ------------------------------------------
[--]  +-- 1: 10.170.0.6	23
[--]  +-- 2: localhost	0
[--]  +-- 3: background	0

-------- Performance schema: Top 5 host per rows sent ----------------------------------------------
[--]  +-- 1: 10.170.0.6	2426
[--]  +-- 2: localhost	1
[--]  +-- 3: background	1

-------- Performance schema: Top 5 host per rows modified ------------------------------------------
[--]  +-- 1: 10.170.0.6	0
[--]  +-- 2: localhost	0
[--]  +-- 3: background	0

-------- Performance schema: Top 5 host per io -----------------------------------------------------
[--]  +-- 1: 10.170.0.6	80
[--]  +-- 2: localhost	8

-------- Performance schema: Top 5 host per io latency ---------------------------------------------
[--]  +-- 1: localhost	8112703020
[--]  +-- 2: 10.170.0.6	2570274288

-------- Performance schema: Top IO type order by total io -----------------------------------------
[--]  +-- 1: innodb/innodb_data_file	1287 i/o
[--]  +-- 2: sql/binlog	402 i/o
[--]  +-- 3: innodb/innodb_log_file	160 i/o
[--]  +-- 4: innodb/innodb_temp_file	70 i/o
[--]  +-- 5: sql/binlog_index	21 i/o
[--]  +-- 6: sql/casetest	10 i/o
[--]  +-- 7: csv/metadata	8 i/o
[--]  +-- 8: sql/ERRMSG	5 i/o
[--]  +-- 9: mysys/cnf	5 i/o
[--]  +-- 10: csv/data	4 i/o
[--]  +-- 11: sql/pid	3 i/o
[--]  +-- 12: mysys/charset	3 i/o
[--]  +-- 13: sql/misc	1 i/o

-------- Performance schema: Top IO type order by total latency ------------------------------------
[--]  +-- 1: innodb/innodb_data_file	385416811032.0
[--]  +-- 2: innodb/innodb_log_file	128894712876.0
[--]  +-- 3: innodb/innodb_temp_file	44303011164.0
[--]  +-- 4: sql/binlog	14091306360.0
[--]  +-- 5: sql/ERRMSG	2443618482.0
[--]  +-- 6: sql/binlog_index	1012155270.0
[--]  +-- 7: csv/data	638847144.0
[--]  +-- 8: csv/metadata	439258764.0
[--]  +-- 9: sql/casetest	234047160.0
[--]  +-- 10: sql/pid	146735886.0
[--]  +-- 11: mysys/cnf	56504784.0
[--]  +-- 12: mysys/charset	51275346.0
[--]  +-- 13: sql/misc	8615196.0

-------- Performance schema: Top IO type order by max latency --------------------------------------
[--]  +-- 1: innodb/innodb_data_file	303207928446
[--]  +-- 2: innodb/innodb_log_file	12346552818
[--]  +-- 3: innodb/innodb_temp_file	2956493184
[--]  +-- 4: sql/binlog	2642930310
[--]  +-- 5: sql/ERRMSG	2217455058
[--]  +-- 6: sql/binlog_index	669078486
[--]  +-- 7: csv/data	535190244
[--]  +-- 8: csv/metadata	192331896
[--]  +-- 9: sql/casetest	116812158
[--]  +-- 10: sql/pid	101995584
[--]  +-- 11: mysys/cnf	33992850
[--]  +-- 12: mysys/charset	32925720
[--]  +-- 13: sql/misc	8615196

-------- Performance schema: Top Stages order by total io ------------------------------------------
[--]  +-- 1: innodb/buffer pool load	1 i/o

-------- Performance schema: Top Stages order by total latency -------------------------------------
[--]  +-- 1: innodb/buffer pool load	2528269000.0

-------- Performance schema: Top Stages order by avg latency ---------------------------------------
[--]  +-- 1: innodb/buffer pool load	2528269000

-------- Performance schema: Top 5 host per table scans --------------------------------------------
[--]  +-- 1: 10.170.0.6	34
[--]  +-- 2: localhost	0

-------- Performance schema: InnoDB Buffer Pool by schema ------------------------------------------
[--]  +-- 1: mysql	5931008	3309765	362 page(s)

-------- Performance schema: 40 InnoDB Buffer Pool by table ----------------------------------------
[--]  +-- 1: mysql	columns	1359872	1017938	83 page(s)
[--]  +-- 2: mysql	time_zone_transition	1097728	984008	67 page(s)
[--]  +-- 3: mysql	tables	704512	519069	43 page(s)
[--]  +-- 4: mysql	help_topic	245760	133558	15 page(s)
[--]  +-- 5: mysql	time_zone_transition_type	212992	172459	13 page(s)
[--]  +-- 6: mysql	index_column_usage	212992	105381	13 page(s)
[--]  +-- 7: mysql	help_keyword	163840	95159	10 page(s)
[--]  +-- 8: mysql	time_zone_name	131072	46698	8 page(s)
[--]  +-- 9: mysql	table_partitions	114688	0	7 page(s)
[--]  +-- 10: mysql	indexes	98304	42612	6 page(s)
[--]  +-- 11: mysql	triggers	98304	1076	6 page(s)
[--]  +-- 12: mysql	collations	81920	29916	5 page(s)
[--]  +-- 13: mysql	events	81920	0	5 page(s)
[--]  +-- 14: mysql	foreign_keys	65536	10554	4 page(s)
[--]  +-- 15: mysql	column_type_elements	65536	33755	4 page(s)
[--]  +-- 16: mysql	global_grants	49152	18680	3 page(s)
[--]  +-- 17: mysql	index_partitions	49152	0	3 page(s)
[--]  +-- 18: mysql	check_constraints	49152	0	3 page(s)
[--]  +-- 19: mysql	help_relation	49152	20946	3 page(s)
[--]  +-- 20: mysql	time_zone	49152	19625	3 page(s)
[--]  +-- 21: mysql	schemata	49152	472	3 page(s)
[--]  +-- 22: mysql	column_statistics	49152	0	3 page(s)
[--]  +-- 23: mysql	foreign_key_column_usage	49152	4794	3 page(s)
[--]  +-- 24: mysql	character_sets	49152	4296	3 page(s)
[--]  +-- 25: mysql	procs_priv	32768	0	2 page(s)
[--]  +-- 26: mysql	view_routine_usage	32768	1626	2 page(s)
[--]  +-- 27: mysql	proxies_priv	32768	1192	2 page(s)
[--]  +-- 28: mysql	view_table_usage	32768	23905	2 page(s)
[--]  +-- 29: mysql	tablespace_files	32768	475	2 page(s)
[--]  +-- 30: mysql	help_category	32768	7084	2 page(s)
[--]  +-- 31: mysql	tables_priv	32768	1774	2 page(s)
[--]  +-- 32: mysql	resource_groups	32768	2192	2 page(s)
[--]  +-- 33: mysql	catalogs	32768	56	2 page(s)
[--]  +-- 34: mysql	tablespaces	32768	975	2 page(s)
[--]  +-- 35: mysql	db	32768	1496	2 page(s)
[--]  +-- 36: mysql	innodb_index_stats	16384	951	1 page(s)
[--]  +-- 37: mysql	slave_master_info	16384	0	1 page(s)
[--]  +-- 38: mysql	slave_worker_info	16384	0	1 page(s)
[--]  +-- 39: mysql	innodb_table_stats	16384	189	1 page(s)
[--]  +-- 40: mysql	table_partition_values	16384	0	1 page(s)

-------- Performance schema: Process per time ------------------------------------------------------
[--]  +-- 1: innodb/clone_gtid_thread	NULL	1407
[--]  +-- 2: innodb/dict_stats_thread	NULL	1407
[--]  +-- 3: innodb/srv_worker_thread	NULL	1407
[--]  +-- 4: sql/compress_gtid_table	Daemon	1407
[--]  +-- 5: innodb/page_flush_coordinator_thread	NULL	1407
[--]  +-- 6: innodb/srv_master_thread	NULL	1407
[--]  +-- 7: innodb/srv_purge_thread	NULL	1407
[--]  +-- 8: sql/main	NULL	1407
[--]  +-- 9: innodb/fts_optimize_thread	NULL	1407
[--]  +-- 10: innodb/srv_worker_thread	NULL	1407
[--]  +-- 11: innodb/srv_worker_thread	NULL	1407
[--]  +-- 12: mysqlx/acceptor_network	NULL	1406
[--]  +-- 13: root@10.170.0.6	Query	0
[--]  +-- 14: innodb/buf_dump_thread	NULL	NULL
[--]  +-- 15: innodb/buf_resize_thread	NULL	NULL
[--]  +-- 16: innodb/io_write_thread	NULL	NULL
[--]  +-- 17: innodb/log_write_notifier_thread	NULL	NULL
[--]  +-- 18: mysqlx/acceptor_network	NULL	NULL
[--]  +-- 19: innodb/io_write_thread	NULL	NULL
[--]  +-- 20: innodb/io_write_thread	NULL	NULL
[--]  +-- 21: innodb/log_writer_thread	NULL	NULL
[--]  +-- 22: innodb/srv_worker_thread	NULL	NULL
[--]  +-- 23: innodb/io_ibuf_thread	NULL	NULL
[--]  +-- 24: innodb/io_write_thread	NULL	NULL
[--]  +-- 25: innodb/srv_lock_timeout_thread	NULL	NULL
[--]  +-- 26: mysqlx/worker	NULL	NULL
[--]  +-- 27: innodb/io_log_thread	NULL	NULL
[--]  +-- 28: innodb/srv_monitor_thread	NULL	NULL
[--]  +-- 29: innodb/srv_error_monitor_thread	NULL	NULL
[--]  +-- 30: mysqlx/worker	NULL	NULL
[--]  +-- 31: innodb/io_read_thread	NULL	NULL
[--]  +-- 32: innodb/log_checkpointer_thread	NULL	NULL
[--]  +-- 33: innodb/srv_worker_thread	NULL	NULL
[--]  +-- 34: innodb/io_read_thread	NULL	NULL
[--]  +-- 35: innodb/log_closer_thread	NULL	NULL
[--]  +-- 36: innodb/srv_purge_thread	NULL	NULL
[--]  +-- 37: sql/event_scheduler	Sleep	NULL
[--]  +-- 38: innodb/io_read_thread	NULL	NULL
[--]  +-- 39: innodb/log_flush_notifier_thread	NULL	NULL
[--]  +-- 40: innodb/srv_worker_thread	NULL	NULL
[--]  +-- 41: sql/signal_handler	NULL	NULL
[--]  +-- 42: innodb/io_read_thread	NULL	NULL
[--]  +-- 43: innodb/log_flusher_thread	NULL	NULL

-------- Performance schema: InnoDB Lock Waits -----------------------------------------------------
[--] No information found or indicators deactivated.

-------- Performance schema: Thread IO Latency -----------------------------------------------------
[--]  +-- 1: log_flusher_thread	105171298752	12346552818
[--]  +-- 2: page_flush_coordinator_thread	25729644576	4666420212
[--]  +-- 3: io_write_thread	19404733002	2551872558
[--]  +-- 4: main	10870938480	2353891386
[--]  +-- 5: log_checkpointer_thread	9120101796	2373966456
[--]  +-- 6: io_write_thread	7479784710	2892239934
[--]  +-- 7: buf_dump_thread	1703120442	39872586
[--]  +-- 8: log_writer_thread	1517317578	57119010
[--]  +-- 9: clone_gtid_thread	72625962	23992890

-------- Performance schema: Top 15 Most latency statements ----------------------------------------
[--]  +-- 1: SHOW VARIABLES	222356550000
[--]  +-- 2: SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000
[--]  +-- 3: SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	47908832000
[--]  +-- 4: SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	44909821000
[--]  +-- 5: SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	43674802000
[--]  +-- 6: SHOW SLAVE STATUS	39744918000
[--]  +-- 7: SELECT `CONCAT` ( `CONCAT` ( `object_schema` , ? ) , `object_name` ) AS ? , `index_name` FROM `performance_schema` . `ta	38254594000
[--]  +-- 8: SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	21709623000
[--]  +-- 9: SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	17214886000
[--]  +-- 10: SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	11673571000
[--]  +-- 11: SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	10819511000
[--]  +-- 12: SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	10189354000
[--]  +-- 13: ALTER SYSTEM_USER ? @? IDENTIFIED BY ? PASSWORD EXPIRE NEVER	9133951000
[--]  +-- 14: SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	7211658000
[--]  +-- 15: ALTER SYSTEM_USER ? @? IDENTIFIED WITH `mysql_native_password` BY ?	6803889000

-------- Performance schema: Top 15 slower queries -------------------------------------------------
[--]  +-- 1: SHOW VARIABLES	1 s
[--]  +-- 2: SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1 s

-------- Performance schema: Top 15 nb statement type ----------------------------------------------
[--]  +-- 1: select	127
[--]  +-- 2: Quit	70
[--]  +-- 3: show_engine_status	6
[--]  +-- 4: Init DB	6
[--]  +-- 5: alter_user	3
[--]  +-- 6: show_table_status	3
[--]  +-- 7: show_databases	2
[--]  +-- 8: show_variables	2
[--]  +-- 9: show_status	2
[--]  +-- 10: flush	1
[--]  +-- 11: show_slave_status	1
[--]  +-- 12: show_slave_hosts	1
[--]  +-- 13: show_storage_engines	1
[--]  +-- 14: Statistics	1
[--]  +-- 15: Ping	1

-------- Performance schema: Top 15 statement by total latency -------------------------------------
[--]  +-- 1: select	488768450000
[--]  +-- 2: show_variables	226693623000
[--]  +-- 3: show_table_status	198410624000
[--]  +-- 4: show_databases	43419246000
[--]  +-- 5: show_slave_status	39744918000
[--]  +-- 6: alter_user	25071792000
[--]  +-- 7: show_status	5091934000
[--]  +-- 8: flush	4420957000
[--]  +-- 9: show_engine_status	926904000
[--]  +-- 10: Quit	726310000
[--]  +-- 11: Init DB	576690000
[--]  +-- 12: show_storage_engines	214300000
[--]  +-- 13: show_slave_hosts	63682000
[--]  +-- 14: Statistics	44348000
[--]  +-- 15: Ping	39665000

-------- Performance schema: Top 15 statement by lock latency --------------------------------------
[--]  +-- 1: select	27807000000
[--]  +-- 2: alter_user	2796000000
[--]  +-- 3: show_table_status	2281000000
[--]  +-- 4: show_status	1881000000
[--]  +-- 5: show_variables	1835000000
[--]  +-- 6: show_databases	1400000000
[--]  +-- 7: flush	288000000
[--]  +-- 8: show_storage_engines	116000000
[--]  +-- 9: Quit	0
[--]  +-- 10: show_engine_status	0
[--]  +-- 11: show_slave_status	0
[--]  +-- 12: show_slave_hosts	0
[--]  +-- 13: Init DB	0
[--]  +-- 14: Statistics	0
[--]  +-- 15: Ping	0

-------- Performance schema: Top 15 statement by full scans ----------------------------------------
[--]  +-- 1: select	38
[--]  +-- 2: show_databases	2
[--]  +-- 3: show_variables	2
[--]  +-- 4: show_status	2
[--]  +-- 5: show_storage_engines	1
[--]  +-- 6: flush	0
[--]  +-- 7: alter_user	0
[--]  +-- 8: Quit	0
[--]  +-- 9: show_engine_status	0
[--]  +-- 10: show_slave_status	0
[--]  +-- 11: show_table_status	0
[--]  +-- 12: show_slave_hosts	0
[--]  +-- 13: Init DB	0
[--]  +-- 14: Statistics	0
[--]  +-- 15: Ping	0

-------- Performance schema: Top 15 statement by rows sent -----------------------------------------
[--]  +-- 1: show_variables	1132
[--]  +-- 2: show_status	931
[--]  +-- 3: select	367
[--]  +-- 4: show_table_status	237
[--]  +-- 5: show_storage_engines	9
[--]  +-- 6: show_databases	8
[--]  +-- 7: flush	0
[--]  +-- 8: alter_user	0
[--]  +-- 9: Quit	0
[--]  +-- 10: show_engine_status	0
[--]  +-- 11: show_slave_status	0
[--]  +-- 12: show_slave_hosts	0
[--]  +-- 13: Init DB	0
[--]  +-- 14: Statistics	0
[--]  +-- 15: Ping	0

-------- Performance schema: Top 15 statement by rows modified -------------------------------------
[--]  +-- 1: select	0
[--]  +-- 2: flush	0
[--]  +-- 3: alter_user	0
[--]  +-- 4: Quit	0
[--]  +-- 5: show_databases	0
[--]  +-- 6: show_variables	0
[--]  +-- 7: show_status	0
[--]  +-- 8: show_engine_status	0
[--]  +-- 9: show_slave_status	0
[--]  +-- 10: show_table_status	0
[--]  +-- 11: show_slave_hosts	0
[--]  +-- 12: show_storage_engines	0
[--]  +-- 13: Init DB	0
[--]  +-- 14: Statistics	0
[--]  +-- 15: Ping	0

-------- Performance schema: 15 sample queries using temp table ------------------------------------
[--]  +-- 1: SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?,
[--]  +-- 2: SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?,
[--]  +-- 3: SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema
[--]  +-- 4: SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema
[--]  +-- 5: SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `
[--]  +-- 6: SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform
[--]  +-- 7: SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform
[--]  +-- 8: SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT`
[--]  +-- 9: SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform
[--]  +-- 10: SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT
[--]  +-- 11: SELECT `r` . `trx_wait_started` AS `wait_started` , `timediff` ( NOW ( ) , `r` . `trx_wait_started` ) AS `wait_age` , TI
[--]  +-- 12: SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance
[--]  +-- 13: SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( (
[--]  +-- 14: SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_
[--]  +-- 15: SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .

-------- Performance schema: Unused indexes --------------------------------------------------------
[--] No information found or indicators deactivated.

-------- Performance schema: Tables with full table scans ------------------------------------------
[--] No information found or indicators deactivated.

-------- Performance schema: Latest FILE IO by latency ---------------------------------------------
[--] No information found or indicators deactivated.

-------- Performance schema: FILE by IO read bytes -------------------------------------------------
[--]  +-- 1: /var/lib/mysql/mysql.ibd	6897664
[--]  +-- 2: /var/lib/mysql/undo_001	5242880
[--]  +-- 3: /var/lib/mysql/undo_002	4603904
[--]  +-- 4: /var/lib/mysql/binlog.000001	3109443
[--]  +-- 5: /var/lib/mysql/ibdata1	2310144
[--]  +-- 6: /usr/share/mysql-8.0/english/errmsg.sys	308724
[--]  +-- 7: /var/lib/mysql/ib_logfile0	70656
[--]  +-- 8: /usr/share/mysql-8.0/charsets/Index.xml	19495
[--]  +-- 9: /var/lib/mysql/auto.cnf	56
[--]  +-- 10: /var/lib/mysql/mysql/slow_log.CSM	35
[--]  +-- 11: /var/lib/mysql/mysql/general_log.CSM	35
[--]  +-- 12: /var/lib/mysql/binlog.index	32
[--]  +-- 13: /var/lib/mysql/#innodb_temp/temp_3.ibt	0
[--]  +-- 14: /var/lib/mysql/#innodb_temp/temp_4.ibt	0
[--]  +-- 15: /var/lib/mysql/#innodb_temp/temp_5.ibt	0

-------- Performance schema: FILE by IO written bytes ----------------------------------------------
[--]  +-- 1: /var/lib/mysql/ibtmp1	14729216
[--]  +-- 2: /var/lib/mysql/ibdata1	1310720
[--]  +-- 3: /var/lib/mysql/undo_002	524288
[--]  +-- 4: /var/lib/mysql/undo_001	491520
[--]  +-- 5: /var/lib/mysql/#innodb_temp/temp_10.ibt	376832
[--]  +-- 6: /var/lib/mysql/mysql.ibd	131072
[--]  +-- 7: /var/lib/mysql/ib_logfile0	118784
[--]  +-- 8: /var/lib/mysql/#innodb_temp/temp_9.ibt	114688
[--]  +-- 9: /var/lib/mysql/#innodb_temp/temp_1.ibt	114688
[--]  +-- 10: /var/lib/mysql/#innodb_temp/temp_2.ibt	114688
[--]  +-- 11: /var/lib/mysql/#innodb_temp/temp_3.ibt	114688
[--]  +-- 12: /var/lib/mysql/#innodb_temp/temp_4.ibt	114688
[--]  +-- 13: /var/lib/mysql/#innodb_temp/temp_5.ibt	114688
[--]  +-- 14: /var/lib/mysql/#innodb_temp/temp_6.ibt	114688
[--]  +-- 15: /var/lib/mysql/#innodb_temp/temp_7.ibt	114688

-------- Performance schema: file per IO total latency ---------------------------------------------
[--]  +-- 1: /var/lib/mysql/ibtmp1	312621423858
[--]  +-- 2: /var/lib/mysql/ib_logfile0	128865756078
[--]  +-- 3: /var/lib/mysql/ibdata1	33225099564
[--]  +-- 4: /var/lib/mysql/#innodb_temp/temp_10.ibt	18065415714
[--]  +-- 5: /var/lib/mysql/undo_002	14738626416
[--]  +-- 6: /var/lib/mysql/mysql.ibd	13285319604
[--]  +-- 7: /var/lib/mysql/binlog.000002	12179822022
[--]  +-- 8: /var/lib/mysql/undo_001	11377638858
[--]  +-- 9: /var/lib/mysql/#innodb_temp/temp_1.ibt	4943425116
[--]  +-- 10: /var/lib/mysql/#innodb_temp/temp_3.ibt	4726685502
[--]  +-- 11: /var/lib/mysql/#innodb_temp/temp_5.ibt	4652774976
[--]  +-- 12: /var/lib/mysql/#innodb_temp/temp_8.ibt	4497305658
[--]  +-- 13: /var/lib/mysql/#innodb_temp/temp_6.ibt	4491348768
[--]  +-- 14: /var/lib/mysql/#innodb_temp/temp_7.ibt	4470359874
[--]  +-- 15: /var/lib/mysql/#innodb_temp/temp_4.ibt	4380243000
[--]  +-- 16: /var/lib/mysql/#innodb_temp/temp_2.ibt	4340530734
[--]  +-- 17: /var/lib/mysql/#innodb_temp/temp_9.ibt	4004619252
[--]  +-- 18: /usr/share/mysql-8.0/english/errmsg.sys	2443618482
[--]  +-- 19: /var/lib/mysql/binlog.000001	1906212816
[--]  +-- 20: /var/lib/mysql/binlog.index	701909016

-------- Performance schema: file per IO read latency ----------------------------------------------
[--]  +-- 1: /var/lib/mysql/mysql.ibd	7948974216
[--]  +-- 2: /var/lib/mysql/undo_002	7150204866
[--]  +-- 3: /var/lib/mysql/undo_001	5686260822
[--]  +-- 4: /var/lib/mysql/ib_logfile0	3286406694
[--]  +-- 5: /var/lib/mysql/binlog.000001	1822442610
[--]  +-- 6: /var/lib/mysql/ibdata1	1804646088
[--]  +-- 7: /usr/share/mysql-8.0/english/errmsg.sys	215202546
[--]  +-- 8: /usr/share/mysql-8.0/charsets/Index.xml	14358660
[--]  +-- 9: /var/lib/mysql/auto.cnf	12430812
[--]  +-- 10: /var/lib/mysql/mysql/general_log.CSM	11148252
[--]  +-- 11: /var/lib/mysql/mysql/slow_log.CSM	9656274
[--]  +-- 12: /var/lib/mysql/binlog.index	6202380
[--]  +-- 13: /var/lib/mysql/#innodb_temp/temp_1.ibt	0
[--]  +-- 14: /var/lib/mysql/#innodb_temp/temp_3.ibt	0
[--]  +-- 15: /var/lib/mysql/#innodb_temp/temp_4.ibt	0
[--]  +-- 16: /var/lib/mysql/#innodb_temp/temp_5.ibt	0
[--]  +-- 17: /var/lib/mysql/#innodb_temp/temp_6.ibt	0
[--]  +-- 18: /var/lib/mysql/#innodb_temp/temp_7.ibt	0
[--]  +-- 19: /var/lib/mysql/#innodb_temp/temp_9.ibt	0
[--]  +-- 20: /var/lib/mysql/ibtmp1	0

-------- Performance schema: file per IO write latency ---------------------------------------------
[--]  +-- 1: /var/lib/mysql/ibtmp1	9132555654
[--]  +-- 2: /var/lib/mysql/ib_logfile0	1680851994
[--]  +-- 3: /var/lib/mysql/ibdata1	1174978266
[--]  +-- 4: /var/lib/mysql/undo_002	671388096
[--]  +-- 5: /var/lib/mysql/undo_001	613750050
[--]  +-- 6: /var/lib/mysql/#innodb_temp/temp_10.ibt	363565680
[--]  +-- 7: /var/lib/mysql/mysql.ibd	190912062
[--]  +-- 8: /var/lib/mysql/#innodb_temp/temp_1.ibt	140955348
[--]  +-- 9: /var/lib/mysql/binlog.000002	137673798
[--]  +-- 10: /var/lib/mysql/#innodb_temp/temp_5.ibt	133612692
[--]  +-- 11: /var/lib/mysql/#innodb_temp/temp_2.ibt	123812130
[--]  +-- 12: /var/lib/mysql/#innodb_temp/temp_4.ibt	119781084
[--]  +-- 13: /var/lib/mysql/#innodb_temp/temp_6.ibt	118945416
[--]  +-- 14: /var/lib/mysql/#innodb_temp/temp_3.ibt	113923392
[--]  +-- 15: /var/lib/mysql/#innodb_temp/temp_7.ibt	113351250
[--]  +-- 16: /var/lib/mysql/#innodb_temp/temp_9.ibt	107924418
[--]  +-- 17: /var/lib/mysql/#innodb_temp/temp_8.ibt	107432436
[--]  +-- 18: /run/mysqld/mysqld.pid	26353602
[--]  +-- 19: /usr/share/mysql-8.0/english/errmsg.sys	0
[--]  +-- 20: /var/lib/mysql/mysql/slow_log.CSV	0

-------- Performance schema: Event Wait by read bytes ----------------------------------------------
[--]  +-- 1: innodb/innodb_data_file	19070976
[--]  +-- 2: sql/binlog	3109443
[--]  +-- 3: sql/io_cache	1121838
[--]  +-- 4: sql/ERRMSG	308724
[--]  +-- 5: innodb/innodb_log_file	70656
[--]  +-- 6: mysys/charset	19495
[--]  +-- 7: csv/metadata	70
[--]  +-- 8: sql/binlog_index	64
[--]  +-- 9: mysys/cnf	56
[--]  +-- 10: sql/casetest	0
[--]  +-- 11: sql/misc	0
[--]  +-- 12: sql/pid	0
[--]  +-- 13: csv/data	0
[--]  +-- 14: innodb/innodb_temp_file	0

-------- Performance schema: Event Wait written bytes ----------------------------------------------
[--]  +-- 1: innodb/innodb_data_file	17186816
[--]  +-- 2: innodb/innodb_temp_file	1409024
[--]  +-- 3: sql/io_cache	1121838
[--]  +-- 4: innodb/innodb_log_file	118784
[--]  +-- 5: sql/binlog	1280
[--]  +-- 6: sql/pid	2
[--]  +-- 7: sql/binlog_index	0
[--]  +-- 8: sql/casetest	0
[--]  +-- 9: sql/ERRMSG	0
[--]  +-- 10: sql/misc	0
[--]  +-- 11: mysys/charset	0
[--]  +-- 12: mysys/cnf	0
[--]  +-- 13: csv/metadata	0
[--]  +-- 14: csv/data	0

-------- Performance schema: event per wait total latency ------------------------------------------
[--]  +-- 1: innodb/innodb_data_file	385306573998
[--]  +-- 2: innodb/innodb_log_file	128894712876
[--]  +-- 3: innodb/innodb_temp_file	58572708594
[--]  +-- 4: sql/binlog	14091306360
[--]  +-- 5: sql/io_cache	5819708184
[--]  +-- 6: sql/ERRMSG	2443618482
[--]  +-- 7: sql/binlog_index	1012155270
[--]  +-- 8: csv/data	638847144
[--]  +-- 9: csv/metadata	439258764
[--]  +-- 10: sql/casetest	234047160
[--]  +-- 11: sql/pid	146735886
[--]  +-- 12: mysys/cnf	56504784
[--]  +-- 13: mysys/charset	51275346
[--]  +-- 14: sql/misc	8615196

-------- Performance schema: event per wait read latency -------------------------------------------
[--]  +-- 1: innodb/innodb_data_file	22606054866
[--]  +-- 2: innodb/innodb_log_file	3286406694
[--]  +-- 3: sql/binlog	1822442610
[--]  +-- 4: sql/io_cache	285116094
[--]  +-- 5: sql/ERRMSG	215202546
[--]  +-- 6: csv/metadata	20804526
[--]  +-- 7: sql/binlog_index	19016958
[--]  +-- 8: mysys/charset	14358660
[--]  +-- 9: mysys/cnf	12430812
[--]  +-- 10: sql/casetest	0
[--]  +-- 11: sql/misc	0
[--]  +-- 12: sql/pid	0
[--]  +-- 13: csv/data	0
[--]  +-- 14: innodb/innodb_temp_file	0

-------- Performance schema: event per wait write latency ------------------------------------------
[--]  +-- 1: innodb/innodb_data_file	11783584128
[--]  +-- 2: sql/io_cache	4119678912
[--]  +-- 3: innodb/innodb_log_file	1680851994
[--]  +-- 4: innodb/innodb_temp_file	1443303846
[--]  +-- 5: sql/binlog	137673798
[--]  +-- 6: sql/pid	26353602
[--]  +-- 7: sql/binlog_index	0
[--]  +-- 8: sql/casetest	0
[--]  +-- 9: sql/ERRMSG	0
[--]  +-- 10: sql/misc	0
[--]  +-- 11: mysys/charset	0
[--]  +-- 12: mysys/cnf	0
[--]  +-- 13: csv/metadata	0
[--]  +-- 14: csv/data	0

-------- Performance schema: TOP 15 most read indexes ----------------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 most modified indexes ------------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 high read latency index ----------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 most modified indexes ------------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 high update latency index --------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 high delete latency index --------------------------------------
[--]  +-- 1: mysql	schemata	PRIMARY	0
[--]  +-- 2: mysql	schemata	catalog_id	0
[--]  +-- 3: mysql	schemata	default_collation_id	0
[--]  +-- 4: mysql	tablespace_files	tablespace_id	0
[--]  +-- 5: mysql	tablespace_files	file_name	0
[--]  +-- 6: mysql	tablespaces	PRIMARY	0
[--]  +-- 7: mysql	tablespaces	name	0
[--]  +-- 8: mysql	check_constraints	PRIMARY	0
[--]  +-- 9: mysql	check_constraints	schema_id	0
[--]  +-- 10: mysql	check_constraints	table_id	0
[--]  +-- 11: mysql	column_type_elements	PRIMARY	0
[--]  +-- 12: mysql	columns	PRIMARY	0
[--]  +-- 13: mysql	columns	table_id	0
[--]  +-- 14: mysql	columns	table_id_2	0
[--]  +-- 15: mysql	columns	collation_id	0

-------- Performance schema: TOP 15 most read tables -----------------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: TOP 15 most modified tables -------------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: TOP 15 high read latency tables ---------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: TOP 15 high insert latency tables -------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: TOP 15 high update latency tables -------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: TOP 15 high delete latency tables -------------------------------------
[--]  +-- 1: mysql	dd_properties	0
[--]  +-- 2: mysql	schemata	0
[--]  +-- 3: mysql	tablespace_files	0
[--]  +-- 4: mysql	tablespaces	0
[--]  +-- 5: mysql	check_constraints	0
[--]  +-- 6: mysql	column_type_elements	0
[--]  +-- 7: mysql	columns	0
[--]  +-- 8: mysql	foreign_key_column_usage	0
[--]  +-- 9: mysql	foreign_keys	0
[--]  +-- 10: mysql	index_column_usage	0
[--]  +-- 11: mysql	index_partitions	0
[--]  +-- 12: mysql	indexes	0
[--]  +-- 13: mysql	table_partition_values	0
[--]  +-- 14: mysql	table_partitions	0
[--]  +-- 15: mysql	tables	0

-------- Performance schema: Redundant indexes -----------------------------------------------------
[--] No information found or indicators deactivated.

-------- Performance schema: Table not using InnoDB buffer -----------------------------------------
[--]  +-- 1: performance_schema	session_variables
[--]  +-- 2: performance_schema	global_variables
[--]  +-- 3: performance_schema	session_status
[--]  +-- 4: performance_schema	global_status
[--]  +-- 5: mysql	general_log
[--]  +-- 6: mysql	slow_log
[--]  +-- 7: performance_schema	accounts
[--]  +-- 8: performance_schema	cond_instances
[--]  +-- 9: performance_schema	data_lock_waits
[--]  +-- 10: performance_schema	data_locks
[--]  +-- 11: performance_schema	events_errors_summary_by_account_by_error
[--]  +-- 12: performance_schema	events_errors_summary_by_host_by_error
[--]  +-- 13: performance_schema	events_errors_summary_by_thread_by_error
[--]  +-- 14: performance_schema	events_errors_summary_by_user_by_error
[--]  +-- 15: performance_schema	events_errors_summary_global_by_error
[--]  +-- 16: performance_schema	events_stages_current
[--]  +-- 17: performance_schema	events_stages_history
[--]  +-- 18: performance_schema	events_stages_history_long
[--]  +-- 19: performance_schema	events_stages_summary_by_account_by_event_name
[--]  +-- 20: performance_schema	events_stages_summary_by_host_by_event_name
[--]  +-- 21: performance_schema	events_stages_summary_by_thread_by_event_name
[--]  +-- 22: performance_schema	events_stages_summary_by_user_by_event_name
[--]  +-- 23: performance_schema	events_stages_summary_global_by_event_name
[--]  +-- 24: performance_schema	events_statements_current
[--]  +-- 25: performance_schema	events_statements_histogram_by_digest
[--]  +-- 26: performance_schema	events_statements_histogram_global
[--]  +-- 27: performance_schema	events_statements_history
[--]  +-- 28: performance_schema	events_statements_history_long
[--]  +-- 29: performance_schema	events_statements_summary_by_account_by_event_name
[--]  +-- 30: performance_schema	events_statements_summary_by_digest
[--]  +-- 31: performance_schema	events_statements_summary_by_host_by_event_name
[--]  +-- 32: performance_schema	events_statements_summary_by_program
[--]  +-- 33: performance_schema	events_statements_summary_by_thread_by_event_name
[--]  +-- 34: performance_schema	events_statements_summary_by_user_by_event_name
[--]  +-- 35: performance_schema	events_statements_summary_global_by_event_name
[--]  +-- 36: performance_schema	events_transactions_current
[--]  +-- 37: performance_schema	events_transactions_history
[--]  +-- 38: performance_schema	events_transactions_history_long
[--]  +-- 39: performance_schema	events_transactions_summary_by_account_by_event_name
[--]  +-- 40: performance_schema	events_transactions_summary_by_host_by_event_name
[--]  +-- 41: performance_schema	events_transactions_summary_by_thread_by_event_name
[--]  +-- 42: performance_schema	events_transactions_summary_by_user_by_event_name
[--]  +-- 43: performance_schema	events_transactions_summary_global_by_event_name
[--]  +-- 44: performance_schema	events_waits_current
[--]  +-- 45: performance_schema	events_waits_history
[--]  +-- 46: performance_schema	events_waits_history_long
[--]  +-- 47: performance_schema	events_waits_summary_by_account_by_event_name
[--]  +-- 48: performance_schema	events_waits_summary_by_host_by_event_name
[--]  +-- 49: performance_schema	events_waits_summary_by_instance
[--]  +-- 50: performance_schema	events_waits_summary_by_thread_by_event_name
[--]  +-- 51: performance_schema	events_waits_summary_by_user_by_event_name
[--]  +-- 52: performance_schema	events_waits_summary_global_by_event_name
[--]  +-- 53: performance_schema	file_instances
[--]  +-- 54: performance_schema	file_summary_by_event_name
[--]  +-- 55: performance_schema	file_summary_by_instance
[--]  +-- 56: performance_schema	host_cache
[--]  +-- 57: performance_schema	hosts
[--]  +-- 58: performance_schema	keyring_keys
[--]  +-- 59: performance_schema	log_status
[--]  +-- 60: performance_schema	memory_summary_by_account_by_event_name
[--]  +-- 61: performance_schema	memory_summary_by_host_by_event_name
[--]  +-- 62: performance_schema	memory_summary_by_thread_by_event_name
[--]  +-- 63: performance_schema	memory_summary_by_user_by_event_name
[--]  +-- 64: performance_schema	memory_summary_global_by_event_name
[--]  +-- 65: performance_schema	metadata_locks
[--]  +-- 66: performance_schema	mutex_instances
[--]  +-- 67: performance_schema	objects_summary_global_by_type
[--]  +-- 68: performance_schema	performance_timers
[--]  +-- 69: performance_schema	persisted_variables
[--]  +-- 70: performance_schema	prepared_statements_instances
[--]  +-- 71: performance_schema	replication_applier_configuration
[--]  +-- 72: performance_schema	replication_applier_filters
[--]  +-- 73: performance_schema	replication_applier_global_filters
[--]  +-- 74: performance_schema	replication_applier_status
[--]  +-- 75: performance_schema	replication_applier_status_by_coordinator
[--]  +-- 76: performance_schema	replication_applier_status_by_worker
[--]  +-- 77: performance_schema	replication_connection_configuration
[--]  +-- 78: performance_schema	replication_connection_status
[--]  +-- 79: performance_schema	replication_group_member_stats
[--]  +-- 80: performance_schema	replication_group_members
[--]  +-- 81: performance_schema	rwlock_instances
[--]  +-- 82: performance_schema	session_account_connect_attrs
[--]  +-- 83: performance_schema	session_connect_attrs
[--]  +-- 84: performance_schema	setup_actors
[--]  +-- 85: performance_schema	setup_consumers
[--]  +-- 86: performance_schema	setup_instruments
[--]  +-- 87: performance_schema	setup_objects
[--]  +-- 88: performance_schema	setup_threads
[--]  +-- 89: performance_schema	socket_instances
[--]  +-- 90: performance_schema	socket_summary_by_event_name
[--]  +-- 91: performance_schema	socket_summary_by_instance
[--]  +-- 92: performance_schema	status_by_account
[--]  +-- 93: performance_schema	status_by_host
[--]  +-- 94: performance_schema	status_by_thread
[--]  +-- 95: performance_schema	status_by_user
[--]  +-- 96: performance_schema	table_handles
[--]  +-- 97: performance_schema	table_io_waits_summary_by_index_usage
[--]  +-- 98: performance_schema	table_io_waits_summary_by_table
[--]  +-- 99: performance_schema	table_lock_waits_summary_by_table
[--]  +-- 100: performance_schema	threads
[--]  +-- 101: performance_schema	user_defined_functions
[--]  +-- 102: performance_schema	user_variables_by_thread
[--]  +-- 103: performance_schema	users
[--]  +-- 104: performance_schema	variables_by_thread
[--]  +-- 105: performance_schema	variables_info

-------- Performance schema: Top 15 Tables using InnoDB buffer -------------------------------------
[--]  +-- 1: mysql	columns	1425408
[--]  +-- 2: mysql	time_zone_transition	1097728
[--]  +-- 3: mysql	tables	704512
[--]  +-- 4: mysql	routines	229376
[--]  +-- 5: mysql	index_column_usage	212992
[--]  +-- 6: mysql	time_zone_transition_type	212992
[--]  +-- 7: mysql	time_zone_name	131072
[--]  +-- 8: mysql	table_partitions	114688
[--]  +-- 9: mysql	indexes	98304
[--]  +-- 10: mysql	triggers	98304
[--]  +-- 11: mysql	events	81920
[--]  +-- 12: mysql	collations	81920
[--]  +-- 13: mysql	foreign_keys	65536
[--]  +-- 14: mysql	column_type_elements	65536
[--]  +-- 15: mysql	time_zone	49152

-------- Performance schema: Top 15 Tables with InnoDB buffer free ---------------------------------
[--]  +-- 1: mysql	columns	364103
[--]  +-- 2: mysql	tables	185443
[--]  +-- 3: mysql	routines	131535
[--]  +-- 4: mysql	table_partitions	114688
[--]  +-- 5: mysql	time_zone_transition	113720
[--]  +-- 6: mysql	index_column_usage	107611
[--]  +-- 7: mysql	triggers	97228
[--]  +-- 8: mysql	time_zone_name	84374
[--]  +-- 9: mysql	events	81920
[--]  +-- 10: mysql	indexes	55692
[--]  +-- 11: mysql	foreign_keys	54982
[--]  +-- 12: mysql	collations	52004
[--]  +-- 13: mysql	check_constraints	49152
[--]  +-- 14: mysql	index_partitions	49152
[--]  +-- 15: mysql	column_statistics	49152

-------- Performance schema: Top 15 Most executed queries ------------------------------------------
[--]  +-- 1: NULL	SELECT @@`version_comment` LIMIT ?	106
[--]  +-- 2: NULL	SELECT SCHEMA ( )	31
[--]  +-- 3: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	13
[--]  +-- 4: NULL	SHOW ENGINE `PERFORMANCE_SCHEMA` STATUS	6
[--]  +-- 5: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	6
[--]  +-- 6: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	6
[--]  +-- 7: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	6
[--]  +-- 8: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	6
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	5
[--]  +-- 10: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	4
[--]  +-- 11: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	4
[--]  +-- 12: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 13: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	3
[--]  +-- 14: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	3
[--]  +-- 15: NULL	ALTER SYSTEM_USER ? @? IDENTIFIED BY ? PASSWORD EXPIRE NEVER	2

-------- Performance schema: Latest SQL queries in errors or warnings ------------------------------
[--]  +-- 1: SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2020-04-10 12:59:35.536306

-------- Performance schema: Top 20 queries with full table scans ----------------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	6
[--]  +-- 2: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	6
[--]  +-- 3: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	6
[--]  +-- 4: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	6
[--]  +-- 5: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	5
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	4
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	4
[--]  +-- 8: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 9: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	3
[--]  +-- 10: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	3
[--]  +-- 11: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	2
[--]  +-- 12: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2
[--]  +-- 13: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2
[--]  +-- 14: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2
[--]  +-- 15: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2
[--]  +-- 16: sys	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2
[--]  +-- 17: NULL	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2
[--]  +-- 18: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	1
[--]  +-- 19: NULL	SELECT `CONCAT` ( `CONCAT` ( `object_schema` , ? ) , `object_name` ) AS ? , `index_name` FROM `performance_schema` . `ta	1
[--]  +-- 20: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	1

-------- Performance schema: Last 50 queries with full table scans ---------------------------------
[--]  +-- 1: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.087962
[--]  +-- 2: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.074366
[--]  +-- 3: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.060871
[--]  +-- 4: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:36.046946
[--]  +-- 5: sys	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2020-04-10 12:59:35.869837
[--]  +-- 6: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	2020-04-10 12:59:35.853263
[--]  +-- 7: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	2020-04-10 12:59:35.767327
[--]  +-- 8: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2020-04-10 12:59:35.686522
[--]  +-- 9: NULL	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2020-04-10 12:59:35.648891
[--]  +-- 10: sys	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.624241
[--]  +-- 11: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.599982
[--]  +-- 12: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.587863
[--]  +-- 13: sys	SELECT IF ( ( `processlist` . `ID` IS NULL ) , `concat` ( `substring_index` ( `performance_schema` . `threads` . `NAME` 	2020-04-10 12:59:35.563139
[--]  +-- 14: NULL	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `object_schema` , `performanc	2020-04-10 12:59:35.549989
[--]  +-- 15: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2020-04-10 12:59:35.536306
[--]  +-- 16: sys	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:35.521319
[--]  +-- 17: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:35.507220
[--]  +-- 18: NULL	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	2020-04-10 12:59:35.425736
[--]  +-- 19: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	2020-04-10 12:59:35.388462
[--]  +-- 20: NULL	SELECT `r` . `trx_wait_started` AS `wait_started` , `timediff` ( NOW ( ) , `r` . `trx_wait_started` ) AS `wait_age` , TI	2020-04-10 12:59:35.366913
[--]  +-- 21: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	2020-04-10 12:59:35.349687
[--]  +-- 22: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:35.231710
[--]  +-- 23: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:35.122798
[--]  +-- 24: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	2020-04-10 12:59:35.100777
[--]  +-- 25: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.059044
[--]  +-- 26: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.043838
[--]  +-- 27: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:34.969804
[--]  +-- 28: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:34.841183
[--]  +-- 29: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	2020-04-10 12:59:34.804669
[--]  +-- 30: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	2020-04-10 12:59:34.679678
[--]  +-- 31: NULL	SELECT `CONCAT` ( `CONCAT` ( `object_schema` , ? ) , `object_name` ) AS ? , `index_name` FROM `performance_schema` . `ta	2020-04-10 12:59:34.112163
[--]  +-- 32: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	2020-04-10 12:59:33.634198

-------- Performance schema: TOP 15 reader queries (95% percentile) --------------------------------
[--]  +-- 1: NULL	SHOW VARIABLES	577
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	175
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1

-------- Performance schema: TOP 15 most row look queries (95% percentile) -------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	28437
[--]  +-- 2: NULL	SHOW VARIABLES	577
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2

-------- Performance schema: TOP 15 total latency queries (95% percentile) -------------------------
[--]  +-- 1: NULL	SHOW VARIABLES	222356550000
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	186945177000
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000

-------- Performance schema: TOP 15 max latency queries (95% percentile) ---------------------------
[--]  +-- 1: NULL	SHOW VARIABLES	222356550000
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	57497769000

-------- Performance schema: TOP 15 average latency queries (95% percentile) -----------------------
[--]  +-- 1: NULL	SHOW VARIABLES	222356550000
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	46736294000

-------- Performance schema: Top 20 queries with sort ----------------------------------------------
[--]  +-- 1: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	13
[--]  +-- 2: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	6
[--]  +-- 3: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	6
[--]  +-- 4: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	6
[--]  +-- 5: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	6
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	5
[--]  +-- 7: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	5
[--]  +-- 8: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	4
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	4
[--]  +-- 10: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 11: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	3
[--]  +-- 12: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	3
[--]  +-- 13: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	2
[--]  +-- 14: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2
[--]  +-- 15: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2
[--]  +-- 16: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2
[--]  +-- 17: sys	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2
[--]  +-- 18: NULL	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2
[--]  +-- 19: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2
[--]  +-- 20: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	1

-------- Performance schema: Last 50 queries with sort ---------------------------------------------
[--]  +-- 1: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.214912
[--]  +-- 2: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	2020-04-10 12:59:36.200801
[--]  +-- 3: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.102283
[--]  +-- 4: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.074366
[--]  +-- 5: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:36.060871
[--]  +-- 6: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:36.046946
[--]  +-- 7: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	2020-04-10 12:59:35.853263
[--]  +-- 8: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	2020-04-10 12:59:35.767327
[--]  +-- 9: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2020-04-10 12:59:35.686522
[--]  +-- 10: NULL	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	2020-04-10 12:59:35.648891
[--]  +-- 11: sys	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.624241
[--]  +-- 12: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.599982
[--]  +-- 13: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	2020-04-10 12:59:35.587863
[--]  +-- 14: sys	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	2020-04-10 12:59:35.521319
[--]  +-- 15: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:35.507220
[--]  +-- 16: NULL	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	2020-04-10 12:59:35.425736
[--]  +-- 17: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	2020-04-10 12:59:35.388462
[--]  +-- 18: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	2020-04-10 12:59:35.349687
[--]  +-- 19: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:35.231710
[--]  +-- 20: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:35.122798
[--]  +-- 21: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	2020-04-10 12:59:35.100777
[--]  +-- 22: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.059044
[--]  +-- 23: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.043838
[--]  +-- 24: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:34.969804
[--]  +-- 25: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:34.841183
[--]  +-- 26: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	2020-04-10 12:59:34.804669
[--]  +-- 27: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	2020-04-10 12:59:34.679678
[--]  +-- 28: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	2020-04-10 12:59:34.654600
[--]  +-- 29: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	2020-04-10 12:59:33.634198

-------- Performance schema: TOP 15 row sorting queries with sort ----------------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2306
[--]  +-- 2: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	1044
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	364
[--]  +-- 4: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	238
[--]  +-- 5: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	129
[--]  +-- 6: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	90
[--]  +-- 7: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	90
[--]  +-- 8: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	78
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	65
[--]  +-- 10: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	52
[--]  +-- 11: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	49
[--]  +-- 12: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	42
[--]  +-- 13: sys	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	40
[--]  +-- 14: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	30
[--]  +-- 15: NULL	SELECT `performance_schema` . `file_summary_by_instance` . `FILE_NAME` AS `file` , `performance_schema` . `file_summary_	30

-------- Performance schema: TOP 15 total latency queries with sort --------------------------------
[--]  +-- 1: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	223793529000
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	186945177000
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000
[--]  +-- 4: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	64917071000
[--]  +-- 5: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	44909821000
[--]  +-- 6: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	43674802000
[--]  +-- 7: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	43419246000
[--]  +-- 8: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	37151265000
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	36058292000
[--]  +-- 10: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	16553200000
[--]  +-- 11: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	12531199000
[--]  +-- 12: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	11690103000
[--]  +-- 13: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	10189354000
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	8889783000
[--]  +-- 15: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	8843444000

-------- Performance schema: TOP 15 merge queries with sort ----------------------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1
[--]  +-- 3: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	0
[--]  +-- 4: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	0
[--]  +-- 5: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	0
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	0
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	0
[--]  +-- 8: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	0
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	0
[--]  +-- 10: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 11: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 12: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	0
[--]  +-- 13: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	0
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	0
[--]  +-- 15: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	0

-------- Performance schema: TOP 15 average sort merges queries with sort --------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1
[--]  +-- 3: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	0
[--]  +-- 4: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	0
[--]  +-- 5: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	0
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	0
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	0
[--]  +-- 8: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	0
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	0
[--]  +-- 10: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 11: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 12: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	0
[--]  +-- 13: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	0
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	0
[--]  +-- 15: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	0

-------- Performance schema: TOP 15 scans queries with sort ----------------------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	30
[--]  +-- 2: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	30
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	14
[--]  +-- 4: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	12
[--]  +-- 5: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	10
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	8
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	8
[--]  +-- 8: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	6
[--]  +-- 9: sys	SELECT `performance_schema` . `table_io_waits_summary_by_index_usage` . `OBJECT_SCHEMA` AS `table_schema` , `performance	6
[--]  +-- 10: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	4
[--]  +-- 11: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	3
[--]  +-- 12: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	3
[--]  +-- 13: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	3
[--]  +-- 14: sys	SELECT `substring_index` ( `performance_schema` . `file_summary_by_event_name` . `EVENT_NAME` , ? , - (?) ) AS `event_na	3
[--]  +-- 15: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	3

-------- Performance schema: TOP 15 range queries with sort ----------------------------------------
[--]  +-- 1: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	0
[--]  +-- 2: NULL	SELECT `cat` . `name` AS `CATALOG_NAME` , `sch` . `name` AS `SCHEMA_NAME` , `cs` . `name` AS `DEFAULT_CHARACTER_SET_NAME	0
[--]  +-- 3: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	0
[--]  +-- 4: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	0
[--]  +-- 5: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	0
[--]  +-- 6: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	0
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	0
[--]  +-- 8: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	0
[--]  +-- 10: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	0
[--]  +-- 11: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	0
[--]  +-- 12: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	0
[--]  +-- 13: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	0
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	0
[--]  +-- 15: NULL	SELECT `performance_schema` . `events_statements_summary_by_digest` . `DIGEST_TEXT` AS `query` , `performance_schema` . 	0

-------- Performance schema: Top 20 queries with temp table ----------------------------------------
[--]  +-- 1: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	13
[--]  +-- 2: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	6
[--]  +-- 3: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	6
[--]  +-- 4: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	6
[--]  +-- 5: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	5
[--]  +-- 6: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	5
[--]  +-- 7: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	4
[--]  +-- 8: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	4
[--]  +-- 9: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 10: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	3
[--]  +-- 11: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2
[--]  +-- 12: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2
[--]  +-- 13: NULL	SHOW VARIABLES	1
[--]  +-- 14: NULL	SHOW GLOBAL VARIABLES	1
[--]  +-- 15: NULL	SHOW STATUS	1
[--]  +-- 16: NULL	SHOW GLOBAL STATUS	1
[--]  +-- 17: NULL	SHOW ENGINES	1
[--]  +-- 18: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	1
[--]  +-- 19: NULL	SELECT ? AS `sys_version` , `version` ( ) AS `mysql_version`	1
[--]  +-- 20: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	1

-------- Performance schema: Last 50 queries with temp table ---------------------------------------
[--]  +-- 1: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	2020-04-10 12:59:36.200801
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:36.046946
[--]  +-- 3: sys	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2020-04-10 12:59:35.869837
[--]  +-- 4: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	2020-04-10 12:59:35.853263
[--]  +-- 5: sys	SELECT IF ( ( `processlist` . `ID` IS NULL ) , `concat` ( `substring_index` ( `performance_schema` . `threads` . `NAME` 	2020-04-10 12:59:35.563139
[--]  +-- 6: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	2020-04-10 12:59:35.536306
[--]  +-- 7: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:35.507220
[--]  +-- 8: NULL	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	2020-04-10 12:59:35.425736
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	2020-04-10 12:59:35.388462
[--]  +-- 10: NULL	SELECT `r` . `trx_wait_started` AS `wait_started` , `timediff` ( NOW ( ) , `r` . `trx_wait_started` ) AS `wait_age` , TI	2020-04-10 12:59:35.366913
[--]  +-- 11: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	2020-04-10 12:59:35.349687
[--]  +-- 12: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	2020-04-10 12:59:35.231710
[--]  +-- 13: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:35.122798
[--]  +-- 14: sys	SELECT IF ( ( `performance_schema` . `events_stages_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance	2020-04-10 12:59:35.100777
[--]  +-- 15: sys	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.059044
[--]  +-- 16: NULL	SELECT IF ( ( `performance_schema` . `events_waits_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_	2020-04-10 12:59:35.043838
[--]  +-- 17: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	2020-04-10 12:59:34.969804
[--]  +-- 18: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	2020-04-10 12:59:34.841183
[--]  +-- 19: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	2020-04-10 12:59:34.804669
[--]  +-- 20: NULL	SELECT ? AS `sys_version` , `version` ( ) AS `mysql_version`	2020-04-10 12:59:34.692633
[--]  +-- 21: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	2020-04-10 12:59:34.654600
[--]  +-- 22: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	2020-04-10 12:59:33.634198
[--]  +-- 23: NULL	SHOW ENGINES	2020-04-10 12:59:32.245304
[--]  +-- 24: NULL	SHOW GLOBAL STATUS	2020-04-10 12:59:32.230212
[--]  +-- 25: NULL	SHOW STATUS	2020-04-10 12:59:32.215600
[--]  +-- 26: NULL	SHOW GLOBAL VARIABLES	2020-04-10 12:59:32.198419
[--]  +-- 27: NULL	SHOW VARIABLES	2020-04-10 12:59:32.181307

-------- Performance schema: TOP 15 total latency queries with temp table --------------------------
[--]  +-- 1: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	223793529000
[--]  +-- 2: NULL	SHOW VARIABLES	222356550000
[--]  +-- 3: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	186945177000
[--]  +-- 4: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	97253123000
[--]  +-- 5: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	64917071000
[--]  +-- 6: NULL	SELECT `t` . `THREAD_ID` AS `thread_id` , IF ( ( `t` . `NAME` = ? ) , `concat` ( `t` . `PROCESSLIST_USER` , ? , CONVERT 	44909821000
[--]  +-- 7: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	43674802000
[--]  +-- 8: sys	SELECT COUNT (?) AS `cnt` , `round` ( ( `performance_schema` . `events_statements_summary_by_digest` . `AVG_TIMER_WAIT` 	37151265000
[--]  +-- 9: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	36058292000
[--]  +-- 10: sys	SELECT `extract_schema_from_file_name` ( `performance_schema` . `file_summary_by_instance` . `FILE_NAME` ) AS `table_sch	16553200000
[--]  +-- 11: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	15129926000
[--]  +-- 12: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	12531199000
[--]  +-- 13: sys	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `perform	11690103000
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `threads` . `PROCESSLIST_ID` IS NULL ) , `substring_index` ( `performance_schema` .	10189354000
[--]  +-- 15: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	8889783000

-------- Performance schema: TOP 15 queries with temp table to disk --------------------------------
[--]  +-- 1: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	4
[--]  +-- 2: NULL	SELECT IF ( ( `locate` ( ? , `ibp` . `TABLE_NAME` ) = ? ) , ? , REPLACE ( `substring_index` ( `ibp` . `TABLE_NAME` , ?, 	1
[--]  +-- 3: sys	SELECT IF ( ( `processlist` . `ID` IS NULL ) , `concat` ( `substring_index` ( `performance_schema` . `threads` . `NAME` 	1
[--]  +-- 4: NULL	SHOW VARIABLES	0
[--]  +-- 5: NULL	SHOW GLOBAL VARIABLES	0
[--]  +-- 6: NULL	SHOW STATUS	0
[--]  +-- 7: NULL	SHOW GLOBAL STATUS	0
[--]  +-- 8: NULL	SHOW ENGINES	0
[--]  +-- 9: NULL	SELECT ENGINE , `SUPPORT` FROM `information_schema` . `ENGINES` ORDER BY ENGINE ASC	0
[--]  +-- 10: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , `tbl` . `	0
[--]  +-- 11: NULL	SELECT `cat` . `name` AS `TABLE_CATALOG` , `sch` . `name` AS `TABLE_SCHEMA` , `tbl` . `name` AS `TABLE_NAME` , IF ( ( ( 	0
[--]  +-- 12: NULL	SELECT ? AS `sys_version` , `version` ( ) AS `mysql_version`	0
[--]  +-- 13: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `performance_schema	0
[--]  +-- 14: NULL	SELECT IF ( ( `performance_schema` . `events_statements_summary_by_user_by_event_name` . `USER` IS NULL ) , ? , `perform	0
[--]  +-- 15: NULL	SELECT IF ( ( `performance_schema` . `memory_summary_by_host_by_event_name` . `HOST` IS NULL ) , ? , `performance_schema	0

-------- Performance schema: TOP 15 class events by number -----------------------------------------
[--]  +-- 1: wait/io/file	2160

-------- Performance schema: TOP 30 events by number -----------------------------------------------
[--]  +-- 1: wait/io/file/innodb/innodb_data_file	1299
[--]  +-- 2: wait/io/file/sql/binlog	402
[--]  +-- 3: wait/io/file/innodb/innodb_log_file	160
[--]  +-- 4: wait/io/file/sql/io_cache	146
[--]  +-- 5: wait/io/file/innodb/innodb_temp_file	93
[--]  +-- 6: wait/io/file/sql/binlog_index	21
[--]  +-- 7: wait/io/file/sql/casetest	10
[--]  +-- 8: wait/io/file/csv/metadata	8
[--]  +-- 9: wait/io/file/sql/ERRMSG	5
[--]  +-- 10: wait/io/file/mysys/cnf	5
[--]  +-- 11: wait/io/file/csv/data	4
[--]  +-- 12: wait/io/file/sql/pid	3
[--]  +-- 13: wait/io/file/mysys/charset	3
[--]  +-- 14: wait/io/file/sql/misc	1

-------- Performance schema: TOP 15 class events by total latency ----------------------------------
[--]  +-- 1: wait/io/file	614679578346

-------- Performance schema: TOP 30 events by total latency ----------------------------------------
[--]  +-- 1: wait/io/file/innodb/innodb_data_file	385324172124
[--]  +-- 2: wait/io/file/innodb/innodb_log_file	128894712876
[--]  +-- 3: wait/io/file/innodb/innodb_temp_file	70112474058
[--]  +-- 4: wait/io/file/sql/binlog	14091306360
[--]  +-- 5: wait/io/file/sql/io_cache	11225854896
[--]  +-- 6: wait/io/file/sql/ERRMSG	2443618482
[--]  +-- 7: wait/io/file/sql/binlog_index	1012155270
[--]  +-- 8: wait/io/file/csv/data	638847144
[--]  +-- 9: wait/io/file/csv/metadata	439258764
[--]  +-- 10: wait/io/file/sql/casetest	234047160
[--]  +-- 11: wait/io/file/sql/pid	146735886
[--]  +-- 12: wait/io/file/mysys/cnf	56504784
[--]  +-- 13: wait/io/file/mysys/charset	51275346
[--]  +-- 14: wait/io/file/sql/misc	8615196

-------- Performance schema: TOP 15 class events by max latency ------------------------------------
[--]  +-- 1: wait/io/file	303207928446

-------- Performance schema: TOP 30 events by max latency ------------------------------------------
[--]  +-- 1: wait/io/file/innodb/innodb_data_file	303207928446
[--]  +-- 2: wait/io/file/innodb/innodb_log_file	12346552818
[--]  +-- 3: wait/io/file/innodb/innodb_temp_file	5796889638
[--]  +-- 4: wait/io/file/sql/binlog	2642930310
[--]  +-- 5: wait/io/file/sql/ERRMSG	2217455058
[--]  +-- 6: wait/io/file/sql/binlog_index	669078486
[--]  +-- 7: wait/io/file/csv/data	535190244
[--]  +-- 8: wait/io/file/sql/io_cache	483917904
[--]  +-- 9: wait/io/file/csv/metadata	192331896
[--]  +-- 10: wait/io/file/sql/casetest	116812158
[--]  +-- 11: wait/io/file/sql/pid	101995584
[--]  +-- 12: wait/io/file/mysys/cnf	33992850
[--]  +-- 13: wait/io/file/mysys/charset	32925720
[--]  +-- 14: wait/io/file/sql/misc	8615196

-------- ThreadPool Metrics ------------------------------------------------------------------------
[--] ThreadPool stat is disabled.

-------- MyISAM Metrics ----------------------------------------------------------------------------
[--] MyISAM Metrics are disabled on last MySQL versions.

-------- InnoDB Metrics ----------------------------------------------------------------------------
[--] InnoDB is enabled.
[--] InnoDB Buffers
[--]  +-- InnoDB Buffer Pool: 128.0M
[--]  +-- InnoDB Buffer Pool Instances: 1
[--]  +-- InnoDB Buffer Pool Chunk Size: 128.0M
[--]  +-- InnoDB Log File Size: 48.0M
[--]  +-- InnoDB Log File In Group: 2
[--]  +-- InnoDB Total Log File Size: 96.0M(75 % of buffer pool)
[--]  +-- InnoDB Log Buffer: 16.0M
[--]  +-- InnoDB Log Buffer Free: 6.9K
[--]  +-- InnoDB Log Buffer Used: 8.0K
[--] InnoDB Thread Concurrency: 0
[OK] InnoDB File per table is activated
[OK] InnoDB buffer pool / data size: 128.0M/16.0K
[!!] Ratio InnoDB log file size / InnoDB Buffer pool size (75 %): 48.0M * 2/128.0M should be equal to 25%
[OK] InnoDB buffer pool instances: 1
[--] Number of InnoDB Buffer Pool Chunk : 1 for 1 Buffer Pool Instance(s)
[OK] Innodb_buffer_pool_size aligned with Innodb_buffer_pool_chunk_size & Innodb_buffer_pool_instances
[OK] InnoDB Read buffer efficiency: 93.44% (13237 hits/ 14166 total)
[OK] InnoDB Write log efficiency: 95.90% (631 hits/ 658 total)
[OK] InnoDB log waits: 0.00% (0 waits / 27 writes)

-------- AriaDB Metrics ----------------------------------------------------------------------------
[--] AriaDB is disabled.

-------- TokuDB Metrics ----------------------------------------------------------------------------
[--] TokuDB is disabled.

-------- XtraDB Metrics ----------------------------------------------------------------------------
[--] XtraDB is disabled.

-------- Galera Metrics ----------------------------------------------------------------------------
[--] Galera is disabled.

-------- Replication Metrics -----------------------------------------------------------------------
[--] Galera Synchronous replication: NO
[--] No replication slave(s) for this server.
[--] Binlog format: ROW
[--] XA support enabled: ON
[--] Semi synchronous replication Master: Not Activated
[--] Semi synchronous replication Slave: Not Activated
[--] This is a standalone server

-------- Recommendations ---------------------------------------------------------------------------
General recommendations:
    setup swappiness lower or equals to 10
    setup Max running number events greater than 1M
    MySQL was started within the last 24 hours - recommendations may be inaccurate
    Reduce your overall MySQL memory footprint for system stability
    Dedicate this server to your database for highest performance.
    Reduce or eliminate unclosed connections and network issues
    Before changing innodb_log_file_size and/or innodb_log_files_in_group read this: https://bit.ly/2TcGgtU
Variables to adjust:
  *** MySQL's maximum memory usage is dangerously high ***
  *** Add RAM before increasing MySQL buffer variables ***
    vm.swappiness <= 10 (echo 10 > /proc/sys/vm/swappiness)
    fs.aio-max-nr > 1M (echo 1048576 > /proc/sys/fs/aio-max-nr)
    innodb_log_file_size should be (=16M) if possible, so InnoDB total log files size equals to 25% of buffer pool size.
```
这边可以看出来结果还是很详细的，最后几行是根据当前的服务器数据库使用情况给出的优化建议


