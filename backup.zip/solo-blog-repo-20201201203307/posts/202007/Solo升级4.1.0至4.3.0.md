title: Solo 升级 4.1.0 至 4.3.0
date: '2020-07-22 13:44:41'
updated: '2020-07-22 13:44:41'
tags: [Solo]
permalink: /articles/2020/07/22/1595395784632.html
---
## git clone快速搭建solo

```
git clone https://github.com/mufengcoding/solo-easystart.git
```

项目结构

```
.
├── caddy
│   ├── conf
│   │   └── Caddyfile
│   ├── solo_h2
│   │   ├── db.mv.db
│   │   └── db.trace.db
│   └── www
│       ├── access.log
│       ├── error.log
│       ├── index.html
│       ├── ss_access.log
│       └── ss_error.log
├── docker-compose.yml
├── Dockerfile
└── README.md

4 directories, 11 files
```

修改Caddyfile和docker-compose的内容

因为服务器配置，我用的是h2数据库，还有个原因是h2转mysql太麻烦了


## 删除旧的镜像

```
docker-compose down
docker rmi b3log/solo
```

## 更新solo

```
docker-compose up -d
```

## 问题

升级之后发现访问不了，查看容器日志
4.1.0-4.2.0升级成功
4.2.0-4.3.0升级失败

更新sql那边报错了

查看solo github仓库
![image.png](https://b3logfile.com/file/2020/07/image-4d8b4373.png)

![image.png](https://b3logfile.com/file/2020/07/image-76d416e4.png)

这边报错了，应该是sql语法不兼容的问题，咨询了下D大，得知这可能是h2语法不兼容的问题，开了个issue，并告知升级改的内容
https://hacpai.com/article/1595383592871/comment/1595385996801?r=mufengcoding#comments

## 解决

手动起 h2的web服务

```
java -cp h2-1.4.199.jar org.h2.tools.Server -web -webAllowOthers -tcp -tcpPort 19200 -tcpAllowOthers
```

浏览器访问时，将数据库文件选择当前使用的db文件，然后对着D说的修改下

重启solo，就可以了


