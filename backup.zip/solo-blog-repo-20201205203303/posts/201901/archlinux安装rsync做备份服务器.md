title: archlinux 安装 rsync 做备份服务器
date: '2019-01-28 17:51:11'
updated: '2019-01-28 17:51:11'
tags: [备份, Shell]
permalink: /articles/2019/01/28/1548669067442.html
---
## 安装rsync
`pacman -Syy rsync`


![imagepng](https://img.hacpai.com/file/2019/01/image-cf64eece.png)

## 修改配置文件
`nano /etc/rsyncd.conf`

![imagepng](https://img.hacpai.com/file/2019/01/image-ea604332.png)

这边需要注意下模块的名称和密码文件的路径

`echo "abc:1234">/etc/rsync.password`

重启服务

`systemctl restart rsyncd`

查看服务状态

`systemctl status rsyncd`


![imagepng](https://img.hacpai.com/file/2019/01/image-8ba8accd.png)

给文件夹目录加上颜色
将下面的代码加入~/.bashrc
```
export LS_OPTIONS='--color=auto'  
eval "`dircolors`"  
alias ls='ls $LS_OPTIONS'  
alias ll='ls $LS_OPTIONS -l'  
alias la='ls $LS_OPTIONS -lA'
```

![imagepng](https://img.hacpai.com/file/2019/01/image-8454225a.png)


未完待续，因为下班了。。。。。