title: Centos 8 来了吗？
date: '2019-05-16 18:07:34'
updated: '2019-05-16 19:07:21'
tags: [CentOS]
permalink: /articles/2019/05/16/1558001251375.html
---
> [沐风](https://blog.mufengs.com)

1.centos 8来了嘛？

答案是否定的

就是10天之前，redhat发布了 8.0版本，很多人都期待8版本的centos，包括我在内

然后我就在疯狂的查找centos发布时间，最后找到了这样的一段话
> Red Hat Enterprise Linux 8 was released on 2019-05-07, and everyone is waiting to find out when the CentOS rebuild will occur. This document is meant to cover general questions and timeline for what is happening.

这说明centos8并没完成更新完成，还在继续开发中。下面是开发的日程

![image.png](https://img.hacpai.com/file/2019/05/image-37f3227e.png)

上图可以看出来，还是有很多功能模块没有完全开始

以上内容参考自：https://wiki.centos.org/About/Building_8

2. 操作系统升级与否

知乎上有很多大佬在讨论这个问题。大多数人的意见是能不动就不动，一动毁一生

可能对于主机很多的情况下，会出现这样的问题。但是对于小公司来说，我觉的有必要升，一是升级必然带来bug修复，和一些即将来临的新特新，二是在没有完善的系统加固体系的情况下，升级可以减少很多会出现的漏洞。相对不稳定来说，代价是可以接受的。

打个比方，比如又一个软件漏洞，需要升级xxx依赖，但这个依赖由于比较新，又需要升级其他的相关依赖，这时候就比较烦了。

就系统升级这件事，我的看法是升，保守永远解决不了问题，也会阻碍发展

[poll1558001223385]

