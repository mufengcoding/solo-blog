title: 博客使用 cloudflare 加速并加入实时聊天插件
date: '2020-02-27 10:15:00'
updated: '2020-02-27 10:15:00'
tags: [待分类]
permalink: /articles/2020/02/26/1582769700211.html
---
一件有意思的事情就是本来想要做 v2ray+vemss+tls+caddy+cloudflare 的，变成了使用 cloudflare 对博客进行加速。

https://dash.cloudflare.com/

接入 cloudflare 的方法，本文不做说明，可以自行百度

![image.png](https://img.hacpai.com/file/2020/02/image-7f559118.png)

cloudflare 托管了域名解析，唯一不好的就是不能配置通配符，因为通配符是需要收费的，也能理解，毕竟很多 ssl 提供商比如赛门铁克，免费的 ssl 也是不支持通配符的

可以配置防火墙规则

![image.png](https://img.hacpai.com/file/2020/02/image-2f404c56.png)可以查看加速效果

![image.png](https://img.hacpai.com/file/2020/02/image-e37be3ff.png)

可以实现强制 https full strict，所有的域名会每到服务器之前就跳转到 https，我这边使用的是 https full 的

这边主要讲下 chatra 的使用

首先我们点击导航上的 apps，搜索 chatra

![image.png](https://img.hacpai.com/file/2020/02/image-3ce18b15.png)

点击预览效果，这边需要先注册一个 chatra 的帐号，注册完成之后点击 install

![image.png](https://img.hacpai.com/file/2020/02/image-988a8acb.png)

到这里没有结束，我们进入 chatra 的 Web 页面，配置邮箱

![image.png](https://img.hacpai.com/file/2020/02/image-ace5c811.png)

根据提示进行配置，添加 gmail 的转发规则，我这边使用的是 gmail

之后的效果是，在网站上有个聊天的浮窗，可以通过邮件转发来实现，实时聊天，效果不错的

![image.png](https://img.hacpai.com/file/2020/02/image-2d3109d8.png)
