title: '[utools] DNS 快速切换'
date: '2020-07-11 23:47:53'
updated: '2020-07-11 23:47:53'
tags: [uTools, DNS]
permalink: /articles/2020/07/11/1594482453605.html
---
utools工具下载地址：

https://u.tools/

![image.png](https://b3logfile.com/file/2020/07/image-fe1792bd.png)

直接在插件中心搜索dns就可以了



====
Todo

1. dns自动测速排序
2. 优化操作流程

====

版本号：0.0.3

1. 适配Windows机器![image.png](https://b3logfile.com/file/2020/07/image-381e1938.png)

====

版本号：0.0.2

1.添加dns派以及sdns

2.添加logo图标

3.修复获取当前dns缓存的bug

=====

版本号：0.0.1

1.目前只支持MACOS，其他系统后续适配

2.清楚Dns缓存

3.切换为腾讯/阿里/百度/114的DNS

4.切换为自定义的DNS

5.获取当前DNS
