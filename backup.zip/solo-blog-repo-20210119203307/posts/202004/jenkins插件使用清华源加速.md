title: jenkins插件使用清华源加速
date: '2020-04-29 15:07:36'
updated: '2020-04-29 15:07:36'
tags: [Jenkins]
permalink: /articles/2020/04/29/1588144056873.html
---
# 插件汇总
Jenkins 所有镜像列表：
 http://mirrors.jenkins-ci.org/status.html
比如日本的镜像： 
http://mirror.esuni.jp/jenkins/, http://ftp.yz.yamagata-u.ac.jp/pub/misc/jenkins/， http://ftp.tsukuba.wide.ad.jp/software/jenkins/
德国的镜像：
http://jenkins.mirror.isppower.de/ ， http://mirror.yandex.ru/mirrors/jenkins/
官方的镜像：
http://mirrors.jenkins-ci.org/， http://archives.jenkins-ci.org/
清华大学镜像：
https://mirrors.tuna.tsinghua.edu.cn/jenkins/updates/update-center.json

# 实施步骤

1. 进入jenkins的updates文件夹
```
cd {你的Jenkins工作目录}/updates 
```

2.修改升级配置文件中的地址

```
sed -i 's/http:\/\/updates.jenkins-ci.org\/download/https:\/\/mirrors.tuna.tsinghua.edu.cn\/jenkins/g' default.json && sed -i 's/http:\/\/www.google.com/https:\/\/www.baidu.com/g' default.json
```
到这里插件安装速度快如火箭
