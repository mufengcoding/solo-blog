title: 【转载】jmeter http动态参数压测
date: '2020-10-28 17:49:12'
updated: '2020-10-28 17:56:44'
tags: [jmeter]
permalink: /articles/2020/10/28/1603878552310.html
---
# **一．准备txt文档**

### 1.参数说明

在txt文档中写入要调用的数据

如果数据只有一列，就写一列，即：1个参数；

两列就是2个参数，三列就是3个参数，

文档中参数之间都要用英文逗号**分隔**

### 2.txt文档

名字叫gld.txt;里面的值见下：

![image.png](https://b3logfile.com/file/2020/10/image-1644750b.png)

# ****二．启动jmeter.bat进入jmeter界面****

### 1.添加线程组

**右击“测试计划”-添加-Threads-线程组；**

![image.png](https://b3logfile.com/file/2020/10/image-26b01164.png)

****注：如果是英文jmeter可通过“选项”-选择语言-Chinese更改；****

![image.png](https://b3logfile.com/file/2020/10/image-76798ed2.png)

### 2.添加并配置CSV Data Set Config

****（1）添加：****

****右击“线程组”-添加-配置元件-CSV Data Set Config；***


![image.png](https://b3logfile.com/file/2020/10/image-a7ca3413.png)

****（2）配置CSV Data SetConfig参数信息****

![image.png](https://b3logfile.com/file/2020/10/image-2b3d5289.png)

Filename:制定的文档路径和名字；可以右击文档-属性，找到文档的路径，注意要写上文档名字和后缀；

File enconding：编码格式，如果txt文档中有中文，该行就要写入utf-8；

Variable Names:*定义参数；txt文档中有几列就定义*几个参数；

参数见用英文逗号隔开；直接写wxid，在其他模块用的时候直接${wxid}调用即可；

Recycle on EOF：到了文件尾处，是否循环读取参数；

Stop thread on EOF：到了文件尾，是否停止线程；

（3）若：想把文档中所有数据读取一遍，且不重复，那么就要设置为：

Recycle on EOF：False；

Stop thread on EOF：True；

### ******3.添加http请求并配置******

******（1）添加：右击“线程组”-添加-Sample-HTTP请求；******

![image.png](https://b3logfile.com/file/2020/10/image-f89d71b3.png)

******（2）配置http请求******

![image.png](https://b3logfile.com/file/2020/10/image-cffca4c2.png)

### ******4.修改线程组配置******

因为我们只写了一个http请求，所以点击运行只会运行一次，我们想把txt文档中所有行都执行一遍，所以我们要将线程数修改；目前txt中共175行，所以线程组中线程数我们设置为175；

![image.png](https://b3logfile.com/file/2020/10/image-99d4d32a.png)

### ******5.监听结果：添加“查看结果树”和“聚合报告”******

查看结果树：可以看到每个请求的执行成功失败；

聚合报告：可以看出总共执行数和失败情况等；

![image.png](https://b3logfile.com/file/2020/10/image-a212d274.png)

### 6.点击运行，查看结果

点击绿色箭头运行，查看结果

![image.png](https://b3logfile.com/file/2020/10/image-2c44f335.png)

（1）在“查看结果树”中，可以看到参数请求的是那个值：

（2）在“聚合报告”可以看所有线程有没有执行完成

![image.png](https://b3logfile.com/file/2020/10/image-c1f4a84b.png)

****以上结果，只是让txt文档中数据全部执行了1遍，如果想执行多次，那么我们就要让http请求重复执行了；****

### ******7.重复执行http请求******

（1）添加循环控制器：

右击http请求-插入上级-逻辑控制器-循环控制器；

![image.png](https://b3logfile.com/file/2020/10/image-5774dc67.png)

（2）配置循环次数

![image.png](https://b3logfile.com/file/2020/10/image-133ce2ab.png)

### ******8.再次查看运行结果：******

一共175条数据*3=525条记录；

![image.png](https://b3logfile.com/file/2020/10/image-ad9c68b3.png)

到此我们就完成了，多用户多次抽奖的功能；

多用户就是txt文档中多行数据，多次抽奖就是单个请求循环3次，如果抽多次就修改次数即可

版权声明：本文为博主原创文章，遵循[ CC 4.0 BY-SA ](http://creativecommons.org/licenses/by-sa/4.0/)版权协议，转载请附上原文出处链接和本声明。

```link
本文链接：https://blog.csdn.net/gld824125233/article/details/52842914
```
