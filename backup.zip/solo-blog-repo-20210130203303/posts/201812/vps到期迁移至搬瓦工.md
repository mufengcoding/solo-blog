title: vps 到期迁移至搬瓦工
date: '2018-12-04 10:24:07'
updated: '2018-12-04 10:24:07'
tags: [备份, 迁移]
permalink: /articles/2018/12/03/1543890245427.html
---
![](https://img.hacpai.com/bing/20180226.jpg?imageView2/1/w/960/h/520/interlace/1/q/100) 


之前买的vultr的vps到期了，用了2年多挺稳定的。由于移动连ssh快，其他两个运营商链接ssh慢，导致我受不了，迫切寻找替代方案

# Vultr
vps日本的经典厂商速度挺好的之前用的日本节点 后来好像被封了改成新加坡节点
https://www.vultr.com/?ref=7297025

# 搬瓦工 
亲平民玩家的vps 性价比高 一年的话29.9美刀
https://bandwagonhost.com/aff.php?aff=40300

速度一般

话不多说 重点是在于solo博客的备份迁移

# 备份
关于备份的讲过很多，之前因为樱花作妖，试过多种备份方式
1.百度云盘备份
2.邮件备份     
https://www.mufengs.com/articles/2018/10/18/1539882476490.html
3.手工拷贝备份

今天主要讲的是恢复迁移

# 迁移

## 备份数据

登入vps1备份博客

./bakup.sh

![imagepng](https://img.hacpai.com/file/2018/12/image-c67682db.png)


## 文件同步

scp root@vps2:/root/blog_2018_11_30.tar.gz ./


![imagepng](https://img.hacpai.com/file/2018/12/image-53376971.png)

## 安装git
yum install git -y

## 安装ss-fly
git clone https://github.com/flyzy2005/ss-fly

## 启动ss服务
ss-fly/ss-fly.sh -i P@ssw0rd 110

![imagepng](https://img.hacpai.com/file/2018/12/image-55703afd.png)

## 安装caddy
https://www.mufengs.com/articles/2018/11/25/1543153259670.html



## 安装java

yum install java -y

## 解压blog数据包

tar -zxvf blog_2018_11_30.tar.gz

## 启动solo

nohup java -cp WEB-INF/lib/*:WEB-INF/classes org.b3log.solo.Starter >/dev/null 2>&1 &

![imagepng](https://img.hacpai.com/file/2018/12/image-abb1dd7f.png)
#
哈哈换了个vps A+了愉快的一米啊
