title: solo 升级到 3.0.0 相关
date: '2019-02-20 19:31:04'
updated: '2019-02-21 11:17:40'
tags: [Solo, B3log]
permalink: /articles/2019/02/20/1550662259700.html
---
> [沐风博客](https://hacpai.com/forward?goto=https%3A%2F%2Fblog.mufengs.com)

将博客升级到3.0.0,参考
>[优雅的将 solo 从 2.96 升级到 2.99](https://hacpai.com/article/1549987072007)
---------------------------------------------------------------------


发现登陆出现cookies写不了,页面重定向到首页，服务器日志如下
![image.png](https://img.hacpai.com/file/2019/02/image-c6412cb2.png)

于是请教@88250 ，发现原来之前也注册了一个其他的帐号，D大帮忙该过之后，发现还是这样

于是弱弱的去了解了下代码
![image.png](https://img.hacpai.com/file/2019/02/image-49026793.png)

然后没看懂

连到h2数据库，看下用户数据

**发现用户名和github不一致**，此处画个重点，好吧我吉泽了

关于连接内置h2数据库

cd /root/blog2.30/WEB-INF/lib/
java -jar h2-1.4.197.jar -webAllowOthers -tcpAllowOthers
![image.png](https://img.hacpai.com/file/2019/02/image-67b332dc.png)

登陆成功！





