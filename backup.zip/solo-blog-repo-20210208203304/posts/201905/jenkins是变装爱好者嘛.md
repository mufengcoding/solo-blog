title: jenkins 是变装爱好者嘛？
date: '2019-05-22 16:50:27'
updated: '2019-05-22 16:50:27'
tags: [Jenkins]
permalink: /articles/2019/05/22/1558515023146.html
---
> [沐风](https://blog.mufengs.com)

如题，是的

你们见过年轻的老头吗？
![image.png](https://img.hacpai.com/file/2019/05/image-38e2c350.png)

当然这边开的玩笑，只是jenkins的前身[hudson](https://http://www.sohu.com/a/135862123_731023)。

很绅士的jenkins，闭着眼睛拿着毛巾，谁知道为啥这么设计吗
![image.png](https://img.hacpai.com/file/2019/05/image-2820e456.png)

过圣诞季的老头

![image.png](https://img.hacpai.com/file/2019/05/image-8295ede8.png)

秀肌肉的老头

![image.png](https://img.hacpai.com/file/2019/05/image-fc898329.png)
是不是有种下面的人都是小弟的感觉

开始上船的老头

![image.png](https://img.hacpai.com/file/2019/05/image-133f65c6.png)

当上舰长的老头

![image.png](https://img.hacpai.com/file/2019/05/image-c6d57b28.png)


老头，你什么时候会睁开你那闭了十几年的眼睛👀


搞jenkins集成rancher，想到的一件有趣的事情。

