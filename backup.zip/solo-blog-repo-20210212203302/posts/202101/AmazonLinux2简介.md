title: Amazon Linux 2 简介
date: '2021-01-25 10:57:43'
updated: '2021-01-25 10:57:43'
tags: [Linux]
permalink: /articles/2021/01/25/1611543449652.html
---
# Amazon Linux 2 相关

1.简介

Amazon Linux 2 是下一代 Amazon Linux，它是 Amazon Web Services（AWS）的 Linux 服务器操作系统。它提供了一个安全，稳定和高性能的执行环境，以开发和运行云和企业应用程序。借助 Amazon Linux 2，您将获得一个应用程序环境，该环境提供长期支持并可以访问 Linux 生态系统中的最新创新。免费提供 Amazon Linux 2。

Amazon Linux 2 作为 Amazon Machine Image（AMI）可用，可在 Amazon Elastic Compute Cloud（Amazon EC2）上使用。它还可用作 Docker 容器映像和虚拟机映像，以用于基于内核的虚拟机（KVM），Oracle VM VirtualBox，Microsoft Hyper-V 和 VMware ESXi。虚拟机映像可用于本地开发和测试。Amazon Linux 2 支持最新的 Amazon EC2 功能，并包括可轻松与 AWS 集成的软件包。AWS 为 Amazon Linux 2 提供了持续的安全和维护更新。

2.镜像下载地址

[https://cdn.amazonlinux.com/os-images/2.0.20201111.0/virtualbox/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/virtualbox/)

提供了[container-arm64/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/container-arm64/)、[container/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/container/)、[hyperv/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/hyperv/)、[kvm/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/kvm/)、[virtualbox/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/virtualbox/)、[vmware/](https://cdn.amazonlinux.com/os-images/2.0.20201111.0/vmware/)这 6 中本地安装镜像

官网地址：

[https://amazonaws-china.com/cn/amazon-linux-2/](https://amazonaws-china.com/cn/amazon-linux-2/)
