title: Arch 安装 zabbix-agent
date: '2019-01-30 10:06:26'
updated: '2019-01-30 10:06:26'
tags: [Linux, 备份, Zabbix]
permalink: /articles/2019/01/29/1548813982776.html
---
安装zabbix-agent

`[root@ItsFossArch ~]# pacman -Syy zabbix-agent`

配置文件
```
Server=10.10.10.1

ServerActive=10.10.10.1

Hostname=Backupserver
```
重启服务
`
systemctl  restart zabbix-agent.service
`
排除

现象：发现没有日志文件，日志部分配置如下
![imagepng](https://img.hacpai.com/file/2019/01/image-66cbfe84.png)

解决：仔细看了下说明
虽然下面写了日志文件的路径，但是日志类型选错了
只能用下面的命令查看：
 `journalctl -xe`

日志的三种类型system/file/console





