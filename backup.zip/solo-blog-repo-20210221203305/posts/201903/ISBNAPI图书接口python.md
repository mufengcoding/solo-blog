title: ISBN-API 图书接口 python
date: '2019-03-24 02:05:19'
updated: '2019-03-24 02:05:19'
tags: [Python, API]
permalink: /articles/2019/03/23/1553364314161.html
---
>[沐风](https://hacpai.com/forward?goto=https%3A%2F%2Fblog.mufengs.com)

接口地址： http://47.93.251.102:8989/api
请求方式：GET
请求参数
| 参数 | 参数名 | 类型 |描述|示例
| --- | --- | --- | ---|---|
| isbn |  isbn号| string |书的isbn号 |9787553401119 |

Demo

请求

http://47.93.251.102:8989/api?isbn=9787553401119

返回

![image.png](https://img.hacpai.com/file/2019/03/image-3da7c54d.png)

项目地址:https://github.com/mufengcoding/PythonOps/tree/master/isbnapi

欢迎来star✨

