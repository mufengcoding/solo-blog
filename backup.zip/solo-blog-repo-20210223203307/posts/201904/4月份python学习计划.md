title: 4 月份 python 学习计划
date: '2019-04-02 00:18:01'
updated: '2019-04-02 00:18:57'
tags: [Python]
permalink: /articles/2019/04/01/1554135477670.html
---
>[沐风](https://hacpai.com/forward?goto=https%3A%2F%2Fblog.mufengs.com%2F)

目标

很简单就是实现一个简单的运维自动化管理平台，参考资料见附录

本学习计划

1.阅读jumpserver源码

2.阅读jumpserver源码

3.阅读jumpserver源码

加油加油加油！！！

附录：

1.https://github.com/YoLoveLife/DevOps#howtoinstall

2.运维综合管理平台（python3+flask+pycharts+scheduler+gunicorn),模块化结构设计,底层需要mysql、
influxdb、elasticsearch、zabbix、k8s等数据源数据作为支撑。由于依赖数据源相关基础数据，仅限于代码交流学习。别忘了给个star^_^

https://github.com/wylok/opsweb

3.简单的运维管理后台中的python-龙卷风

https://github.com/cnkedao/ops

4.DevOps CLI工具 - Hadoop，Spark，HBase，日志匿名程序，Ambari蓝图，AWS CloudFormation，Linux，Docker，Spark数据转换器和验证器（Avro / Parquet / JSON / CSV / INI / XML / YAML），Elasticsearch，Solr，Travis CI ，猪，IPython - Python / Jython工具 -

https://github.com/HariSekhon/DevOps-Python-tools

5.阿里devops开源工具

https://github.com/alibaba/opstools

6.开源运维平台：帮助中小型企业完成主机，任务，发布部署，配置文件，监控，报警等管理（开源运维管理系统，管理主机，任务，部署，配置文件，监控和报警）https ：//spug.qbangmang.com/login

https://github.com/openspug/spug

7.运维管理平台（阿里云），自动同步阿里云配置信息，给研发使用的跳板机，批量运维，的zabbix管理等功能

https://github.com/ixrjog/opsCloud