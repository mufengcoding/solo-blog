title: Jumperserver 升级到 1.5.0-2
date: '2019-06-26 09:27:39'
updated: '2019-06-26 09:27:39'
tags: [Jumperserver, 运维, Python, 堡垒机]
permalink: /articles/2019/06/25/1561512455525.html
---
原有的jumperserver1.4.5因为被我加了个菜单，不能直接升级

## 备份更新
#### 备份原有的jumpserver
`mv jumperserver jumperserver.bak`

#### 回滚jumperserver
```
git clean -df  # 清除未跟踪文件, 请一定要做好备份后再操作此步骤
git reset --hard  # 还原所有修改, 请一定要做好备份后再操作此步骤
```
#### 更新代码
```
# 更新 config.yml, 请根据你原来的 config.bak 内容进行修改
 mv config.py config_1.4.5.bak
 cp config_example.yml config.yml
 vi config.yml
```
因为1.5.0的配置文件改动比较大，对比原先的配置文件进行修改

```
# SECURITY WARNING: keep the secret key used in production secret!
# 加密秘钥 升级请保证与你原来的 SECRET_KEY 一致, 可以从旧版本的config_1.4.5.bak配置文件里面获取
SECRET_KEY: *****

# SECURITY WARNING: keep the bootstrap token used in production secret!
# 预共享Token koko和guacamole用来注册服务账号, 不在使用原来的注册接受机制, 可随机生成
BOOTSTRAP_TOKEN: *****

# Development env open this, when error occur display the full process track, Production disable it
# DEBUG 模式 开启DEBUG后遇到错误时可以看到更多日志
DEBUG: false

# DEBUG, INFO, WARNING, ERROR, CRITICAL can set. See https://docs.djangoproject.com/en/1.10/topics/logging/
# 日志级别
LOG_LEVEL: ERROR
# LOG_DIR:

# Session expiration setting, Default 24 hour, Also set expired on on browser close
# 浏览器Session过期时间, 默认24小时, 也可以设置浏览器关闭则过期
# SESSION_COOKIE_AGE: 86400
SESSION_EXPIRE_AT_BROWSER_CLOSE: true

# Database setting, Support sqlite3, mysql, postgres ....
# 数据库设置
# See https://docs.djangoproject.com/en/1.10/ref/settings/#databases

# SQLite setting:
# 使用单文件sqlite数据库
# DB_ENGINE: sqlite3
# DB_NAME:

# MySQL or postgres setting like:
# 使用Mysql作为数据库
DB_ENGINE: mysql
DB_HOST: 127.0.0.1
DB_PORT: 3306
DB_USER: jumpserver
DB_PASSWORD: *****
DB_NAME: jumpserver

# When Django start it will bind this host and port
# ./manage.py runserver 127.0.0.1:8080
# 运行时绑定端口
HTTP_BIND_HOST: 0.0.0.0
HTTP_LISTEN_PORT: 8080

# Use Redis as broker for celery and web socket
# Redis配置
REDIS_HOST: 127.0.0.1
REDIS_PORT: 6379
# REDIS_PASSWORD:
# REDIS_DB_CELERY: 3
# REDIS_DB_CACHE: 4

# Use OpenID authorization
# 使用OpenID 来进行认证设置
# BASE_SITE_URL: http://localhost:8080
# AUTH_OPENID: false  # True or False
# AUTH_OPENID_SERVER_URL: https://openid-auth-server.com/
# AUTH_OPENID_REALM_NAME: realm-name
# AUTH_OPENID_CLIENT_ID: client-id
# AUTH_OPENID_CLIENT_SECRET: client-secret

# OTP settings
# OTP/MFA 配置
# OTP_VALID_WINDOW: 0
# OTP_ISSUER_NAME: Jumpserver
```

## 安装启动

```
pip install -r requirements/requirements.txt
./jms start all -d
```

## 更新luna
```
$ cd /opt
$ rm -rf luna luna.tar.gz
$ wget https://github.com/jumpserver/luna/releases/download/1.5.0/luna.tar.gz

# 如果网络有问题导致下载无法完成可以使用下面地址
$ wget https://demo.jumpserver.org/download/luna/1.5.0/luna.tar.gz

$ tar xf luna.tar.gz
$ chown -R root:root luna
```
> 注意把浏览器缓存清理下

## Docker koko Guacamole

说明: Docker 部署的 koko 与 guacamole 升级说明
```
# 先到 Web 会话管理 - 终端管理 删掉所有组件
$ docker stop jms_koko
$ docker stop jms_guacamole

$ docker rm jms_koko
$ docker rm jms_guacamole
$ docker pull jumpserver/jms_koko:1.5.0
$ docker pull jumpserver/jms_guacamole:1.5.0

# BOOTSTRAP_TOKEN 请和 jumpserver 配置文件中保持一致
$ docker run --name jms_koko -d -p 2222:2222 -p 5000:5000 -e CORE_HOST=http://<Jumpserver_url> -e BOOTSTRAP_TOKEN=***** -e LOG_LEVEL=ERROR jumpserver/jms_koko:1.5.0
$ docker run --name jms_guacamole -d -p 8081:8081 -e JUMPSERVER_SERVER=http://<Jumpserver_url> -e BOOTSTRAP_TOKEN=***** jumpserver/jms_guacamole:1.5.0

# 到 Web 会话管理 - 终端管理 查看组件是否已经在线
```

最后修改jumperserver模版中的_nav.html，把原来修改的加上

截图如下

![image.png](https://img.hacpai.com/file/2019/06/image-fa946c22.png)
