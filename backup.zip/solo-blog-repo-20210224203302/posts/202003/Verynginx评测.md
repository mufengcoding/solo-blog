title: Verynginx 评测
date: '2020-03-09 11:41:49'
updated: '2020-03-09 11:41:49'
tags: [NGINX]
permalink: /articles/2020/03/08/1583725309580.html
---
## 01. 前言

之前在公众号上看到的号称 5k star 的 nginx 神器，具备 waf 功能。顿时就心动了，这么强悍，怎么做到的，于是乎就去尝试了一波，并非那么强大，仅表示个人观点，仅供读者参考。以下是踩坑过程。

GitHub 官方地址：https://github.com/alexazhou/VeryNginx

## 02. 基础环境安装

GitHub 提供的方式，太片面了，没有考虑到初始的环境的安装有些依赖也没有提到

操作系统：CentOS7.7

纯净程度：绝对纯净

### 2.1 系统环境安装

在 gce 上创建一个实例，2 核 4G 仅是测试用途

更新操作系统

```
yum update -y
```

安装基础组件

```
 yum install git wget gcc  pcre pcre-devel -y
```

### 2.2 Verynginx 安装

拉取 GitHub 源代码

```
git clone https://github.com/alexazhou/VeryNginx.git
```

进入工作目录

```
cd VeryNginx/
```

执行安装脚本

```
python install.py install
```

可以选择已有的 nginx 进行重新编译，我这边机器性能一般，编译的时间略长

## 03. 启动 Verynginx

启动命令很简单，就是将 nginx 服务拉起来

```
#Start Service
/opt/verynginx/openresty/nginx/sbin/nginx

#Stop Service
/opt/verynginx/openresty/nginx/sbin/nginx -s stop

#Restart Service
/opt/verynginx/openresty/nginx/sbin/nginx -s reload
```

启动的时候如果出现 `nginx: [emerg] getpwnam("nginx") failed in` 大概率是因为踩坑的时候，openrestry 没有正确安装，不过问题不大，手动加上用户

```
useradd -s /sbin/nologin -M nginx
```

## 04. 访问和效果图

访问地址是：

`http://{{your_machine_address}}/verynginx/index.html`.

帐号密码：

`verynginx` / `verynginx`

状态页：

![image.png](https://img.hacpai.com/file/2020/03/image-54b89d16.png)

配置页：

![image.png](https://img.hacpai.com/file/2020/03/image-8a04b80a.png)

概况：

![image.png](https://img.hacpai.com/file/2020/03/image-b96af2f3.png)

## 05. 评测

个人觉得与之前看到公众号时的期待，有点心里落差。因为这个页面，曾经在 nginxconf 那个项目里面看到类似的内容。有点没搞清楚的是，日志会有 lua 的报错，登陆保持好像有点问题，会不时的出现未登录。修改配置保存也有点问题，可能和系统权限有点关系，这边不做深入研究。所谓的 waf 功能就是一些 uri 的规则拦截，平时可以参考加入 nginx 即可。说了这么多，这个项目还是有他不错的地方的，比如将 nginx 配置提到 Web 端，在运维工作中更人性化一点。

---

满星：🌟🌟🌟🌟🌟

---

UI：🌟🌟

---

功能：🌟🌟🌟

---

速度：🌟🌟🌟🌟

---

实用性：🌟🌟🌟

---

就说这么多了，有空的时候去学习下 Verynginx 的源码，嘿嘿
