title: Gitlab 切换过 IP 之后提交代码失败
date: '2020-08-21 16:49:36'
updated: '2020-08-21 16:49:36'
tags: [Git]
permalink: /articles/2020/08/21/1597999746497.html
---
通过命令行的方式

执行以下命令：（注意将下面的替换为自己的远程仓库的 url，比如 `ssh://xxx@xxx.xxx.xxx.xxx:xxx/xxx.git`）

```
git remote set-url origin url
```
