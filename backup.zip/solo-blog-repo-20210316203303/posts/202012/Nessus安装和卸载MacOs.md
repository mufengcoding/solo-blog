title: Nessus 安装和卸载 [MacOs]
date: '2020-12-17 10:36:00'
updated: '2020-12-17 13:31:43'
tags: [漏洞, NESSUS]
permalink: /articles/2020/12/17/1608172560386.html
---
# 一、概述

> Nessus号称是世界上最流行的漏洞扫描程序，全世界有超过75000个组织在使用它。该工具提供完整的电脑漏洞扫描服务，并随时更新其漏洞数据库。Nessus不同于传统的漏洞扫描软件，Nessus可同时在本机或远端上遥控，进行系统的漏洞分析扫描。对应渗透测试人员来说，Nessus是必不可少的工具之一

近期网站系统安全越来越重要了，不断收到与安全相关

# 二、安装

## 2.1 获取安装包

官网下载：[http://www.tenable.com/products/nessus/select-your-operating-system](https://link.jianshu.com/?t=http://www.tenable.com/products/nessus/select-your-operating-system)

![image.png](https://b3logfile.com/file/2020/12/image-e714cea9.png)

我这边选择的是macos

免费版本注册之后会发送一个待激活码的邮件到你的邮箱，这个激活码在你安装的时候有用

安装运行下载的好的dmg文件，待安装完成之后，会在系统中起一个后台的服务

# 三、使用NESSUS

浏览器访问：https://127.0.0.1:8834

![image.png](https://b3logfile.com/file/2020/12/image-d469d75b.png)

这边使用之前的激活码，等待几秒钟激活完成后会自动安装相关插件。。。

一切就绪之后，我们可以看到他的功能非常强大，包含了前段时间比较火的wannacry漏洞检测

![image.png](https://b3logfile.com/file/2020/12/image-6fb2ab87.png)

使用的话，就是非常简单选择扫描模板，然后下一步下一步就可以了。这里我们测试的时候，没有扫描到web的系统漏洞，这边还有待于学校研究下。


# 四、卸载

因为找了一个测试环境，所以不打算装在笔记本上，还是比较吃性能的，15年的老爷机跑着吃力，特别是升级到sur版本之后，总感觉卡卡的

这边的卸载步骤，引用官网的方式：

> # Uninstall Nessus on Mac OS X
>
> []()Stop Nessus
>
> 1. In**System Preferences**, select the**Nessus** button.
> 2. On the**Nessus.Preferences** screen, select the lock to make changes.
> 3. Next, enter your username and password.
> 4. Select the**Stop Nessus** button.
>    The**Status** becomes red and displays**Stopped**.
> 5. Finally, exit the**Nessus.Preferences** screen.
>
> []()Remove the following Nessus directories, subdirectories, or files
>
> /Library/Nessus
> /Library/LaunchDaemons/com.tenablesecurity.nessusd.plist
> /Library/PreferencePanes/Nessus Preferences.prefPane
> /Applications/Nessus
>
> []()Disable the Nessus service
>
> 1. To prevent the Mac OS X from trying to start the now non-existent service, type the following command from a command prompt.
>    $ sudo launchctl remove com.tenablesecurity.nessusd
> 2. If prompted, provide the administrator password.
