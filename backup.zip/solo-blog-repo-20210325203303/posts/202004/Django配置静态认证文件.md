title: Django配置静态认证文件
date: '2020-04-04 22:51:10'
updated: '2020-04-04 22:51:28'
tags: [Django]
permalink: /articles/2020/04/04/1586011870394.html
---
![](https://img.hacpai.com/bing/20190321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


目录结构：
｜-- templates
｜-- apps
｜-- ...... 
｜

修改urls.py
以下配置仅供参考
```
from django.views.generic import TemplateView
urlpatterns = [
    url(r'^b\.html$', TemplateView.as_view(template_name='b.html', content_type='text/html')),
    url(r'^s\.txt$', TemplateView.as_view(template_name='s.txt', content_type='text/plain')),
    url(r'^Auth\.xml$', TemplateView.as_view(template_name='Auth.xml', content_type='text/xml')),
]
```
亲测有效
