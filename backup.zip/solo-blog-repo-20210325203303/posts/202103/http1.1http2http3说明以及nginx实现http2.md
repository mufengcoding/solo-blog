title: http1.1/http2/http3说明以及nginx实现http2
date: '2021-03-11 13:59:21'
updated: '2021-03-11 13:59:21'
tags: [NGINX, HTTPS]
permalink: /articles/2021/03/11/1615442361124.html
---
# 概述


摘自百度百科:

> 超文本传输协议（HTTP，HyperText Transfer Protocol)是互联网上应用最为广泛的一种网络协议。所有的WWW文件都必须遵守这个标准。设计HTTP最初的目的是为了提供一种发布和接收HTML页面的方法。

HTTP属于[OSI网络七层协议模型](https://www.cnblogs.com/Robin-YB/p/6668762.html)中的"最上层":应用层。由请求和响应构成，是一个标准的客户端服务器模型。HTTP是一个无状态的协议。

HTTP默认端口号为80。它也可以承载在TLS和SSL之上，通过加密、认证的方式实现数据传输的安全，称为HTTPS，HTTPS默认端口号为443。

早期HTTP用于传输网页HTML文件，发展到现在，应用变得广泛，客户端软件（PC，Android,iOS等）大部分通过HTTP传输数据。

## HTTP1.1

发布于1997年

持久连接（persistent connection），即TCP连接默认不关闭，可以被多个请求复用，不用声明 `Connection: keep-alive`。解决了1.0版本的keepalive问题，1.1版本加入了持久连接，一个TCP连接可以允许多个HTTP请求；

加入了管道机制，在同一个TCP连接里，允许多个请求同时发送，增加了并发性，进一步改善了HTTP协议的效率，虽然允许复用TCP连接，但是同一个TCP连接里面，所有的数据通信是按次序进行的。；

新增了请求方式PUT、PATCH、OPTIONS、DELETE等；

## HTTP2.0

发布于2015年

为了解决1.1版本利用率不高的问题，提出了HTTP/2.0版本。增加双工模式，即不仅客户端能够同时发送多个请求，服务端也能同时处理多个请求，解决了队头堵塞的问题（HTTP2.0使用了多路复用的技术，做到同一个连接并发处理多个请求，而且并发请求的数量比HTTP1.1大了好几个数量级）；HTTP请求和响应中，状态行和请求/响应头都是些信息字段，并没有真正的数据，因此在2.0版本中将所有的信息字段建立一张表，为表中的每个字段建立索引，客户端和服务端共同使用这个表，他们之间就以索引号来表示信息字段，这样就避免了1.0旧版本的重复繁琐的字段，并以压缩的方式传输，提高利用率。

另外也增加服务器推送的功能，即不经请求服务端主动向客户端发送数据。

## HTTP3.0

TTP3 的主要改进在传输层上。传输层不会再有那些繁重的 TCP 连接了。现在，一切都会走 UDP。QUIC 的意思是“快速 UDP Internet 连接”。协议的这种更改将显著加快连接建立和数据传输的速度。然而，虽说 UDP 肯定更快、更简单，但它不具备 TCP 的可靠性和错误处理能力。

HTTP3 是 HTTP2 的复用和压缩，协议从 TCP 更改为 UDP。然后，谷歌的那些人在协议中添加了他们做的层，以确保稳定性、数据包接收顺序及安全性。

**因此，HTTP3 在保持 QUIC 稳定性的同时使用 UDP 来实现高速度**，同时又不会牺牲 TLS 的安全性。是的，在 QUIC 中就有 TLS1.3，你可以用它发起优雅的 SSL。这些层的底层机制是下面这样：

![](https://b3logfile.com/file/2021/03/solo-fetchupload-939571852908466585-4739c37e.jpeg)

# 通信过程


| ![](https://b3logfile.com/file/2021/03/solo-fetchupload-6708634061997562562-8aa1a37d.jpeg) |
| :-: |
| ![](https://b3logfile.com/file/2021/03/solo-fetchupload-169307745300280594-3cd5ce93.jpeg) |
| ![](https://b3logfile.com/file/2021/03/solo-fetchupload-3718443576595878404-dc6f6aa0.png) |

# Nginx实现http2.0

检查nginx支持的模块

```
/usr/sbin/nginx -V
```

如果包含 `--with-http_v2_module`这个模块，恭喜你可以直接使用

```
server {
    listen       443 ssl http2;
...
```

使用方式很简单在配置文件sever模块里面的listen那边加个http2即可

可以通过chrome的devtools来检查修改是否生效

http1.1：

![image.png](https://b3logfile.com/file/2021/03/image-4fc62c86.png)

http2.0：

![image.png](https://b3logfile.com/file/2021/03/image-e798327b.png)

# Nginx实现http3.0

编译安装支持quic的nginx，可以参看《[Nginx 配置启用 QUIC 和 HTTP/3.0](https://www.nange.cn/quic-and-http3-for-nginx.html)》

```
# Enable QUIC and HTTP/3.
listen 443 quic reuseport;
 
# Enable HTTP/2 (optional).
listen 443 ssl http2;
 
# 只支持tls1.3
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers [TLS13+AESGCM+AES128|TLS13+CHACHA20]:TLS13+AESGCM+AES256:[EECDH+ECDSA+AESGCM+AES128|EECDH+ECDSA+CHACHA20]:EECDH+ECDSA+AESGCM+AES256:EECDH+ECDSA+AES128+SHA:EECDH+ECDSA+AES256+SHA:[EECDH+aRSA+AESGCM+AES128|EECDH+aRSA+CHACHA20]:EECDH+aRSA+AESGCM+AES256:EECDH+aRSA+AES128+SHA:EECDH+aRSA+AES256+SHA;
ssl_prefer_server_ciphers on;
ssl_early_data on;
ssl_ecdh_curve X25519:P-256:P-384;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 10m;
error_page 497  https://$host$request_uri;
 
# OCSP Stapling 启用
ssl_stapling on;
ssl_stapling_verify on;
ssl_stapling_file /home/others/ocsp/nange.cn.ocsp.resp;
 
# Add Alt-Svc header to negotiate HTTP/3.
add_header alt-svc 'quic=":443"; ma=2592000; ';
```

http3.0

我的博客是挂了cloudflare的cdn，可以看出来cloudflare那边已经在使用http3了

![image.png](https://b3logfile.com/file/2021/03/image-de8436f6.png)

如果本文对你有用，麻烦双击·666·加·关注·

原文引用：

https://www.infoq.cn/article/WhCObxfbgtphY7ijv1kp

https://www.nange.cn/quic-and-http3-for-nginx.html

https://blog.csdn.net/qq_22238021/article/details/81197157
