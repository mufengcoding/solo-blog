title: utools 插件开发 --MAC dns 快速切换
date: '2020-06-15 09:04:31'
updated: '2020-06-15 09:05:20'
tags: [utools]
permalink: /articles/2020/06/15/1592183071520.html
---
开发文档：https://u.tools/docs/developer/welcome.html#plugin-json

## 开发初衷

utools 原有的一个插件 DNS 切换，在 mac 下有网线的那个网络设备，切换 DNS 失败。猜测作者截取网络设备时，字段截取有问题，只获取到了 LAN，而没有获取到完整信息 USB 10/100/1000 LAN，导致设置 dns 的时候失败

## 开发准备

首先建立一个空的文件夹 utools_test，目录结构如下：

![image.png](https://b3logfile.com/file/2020/06/image-6e073705.png?imageView2/2/interlace/1/format/webp)

524 x 426

### README.md

主要是显示插件的介绍和使用说明

### index.html

插件的入口文件

### plugin.json

这是最重要的一个文件，用来说明这个插件将如何与 uTools 集成，最基本的格式如下：

```
{
	"pluginName": "helloWorld",
	"description": "我的第一个uTools插件",
	"main": "index.html",
	"version": "0.0.1",
	"features": [
		{
		  "code": "hello",
		  "explain": "hello world",
			"cmds":["hello", "你好"]
		}
	]
}
```

#### 字段说明

`pluginNam` : 插件名称，它会在 uTools 的很多地方出现

`description` : 插件描述，简洁的说明这个插件的作用

`main` : 入口文件，如果没有定义入口文件，此插件将变成一个[模版插件](https://link.hacpai.com/forward?goto=https%3A%2F%2Fu.tools%2Fdocs%2Fdeveloper%2Ftpl.html)

`version` : 插件的版本，需要符合 Semver(语义化版本) 规范。一般情况下形如：`主.次.修订` 即可

`features` : 唯一比较复杂的就是 features 了，首先它是一个数组，每个数组元素用来描述这个插件提供的一个相对独立的功能，例如 uTools 中的「编码小助手」插件，提供了 `md5` 、 `时间戳` 、 `随机数` 等功能。

`features.` : 插件某个功能的识别码，在进入插件时会传递给你的代码，可用于区分不同的功能，显示不同的 UI

`features.cmds` : 通过哪些方式可以进入这个功能，中文会自动添加 `拼音` 及 `拼音首字母`

### preload.js

在传统的 Web 开发中，所有的 JavaScript 脚本都在浏览器沙盒中运行，权限被严格限制，所能实现的功能非常有限。

通过 `preload.js` 能够帮你突破沙盒限制，进入一个崭新的 JavaScript 世界。

`preload.js` 是一个特殊且单独的文件，不需要与其他业务代码编译在一起，在此文件中可以访问 `nodejs`、`electron`、`uTools` 提供的 API，并挂载到 `window` 对象中，你其他的普通 JavaScript 代码就可以访问这些 API。

## 成果演示

![image.png](https://b3logfile.com/file/2020/06/image-e6c17421.png?imageView2/2/interlace/1/format/webp)

728 x 532

1614 x 1180

![image.png](https://b3logfile.com/file/2020/06/image-faf41361.png?imageView2/2/interlace/1/format/webp)

728 x 370

1608 x 818

方便快捷，是真的好用，还有其他各种插件，很是好用。

## 下一个计划--微信读书插件

基于微信读书网页版嵌入到 utools 插件中

`````````````````````````````````````````````````
        *      [](https://hacpai.com/tag/utools)
`````````````````````````````````````````````````

作者：mufengcoding
链接：https://hacpai.com/article/1592103652786
来源：黑客派
协议：CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0/
