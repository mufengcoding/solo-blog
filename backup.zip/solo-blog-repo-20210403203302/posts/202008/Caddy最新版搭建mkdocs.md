title: Caddy 最新版搭建 mkdocs
date: '2020-08-19 13:27:02'
updated: '2020-08-19 13:27:02'
tags: [Caddy]
permalink: /articles/2020/08/19/1597399396508.html
---

官网地址：https://caddyserver.com/

服务器：Centos7.2

## 01.基础环境搭建

### 1.1.安装golang

```shell
rpm --import https://mirror.go-repo.io/centos/RPM-GPG-KEY-GO-REPO
curl -s https://mirror.go-repo.io/centos/go-repo.repo | tee /etc/yum.repos.d/go-repo.repo
yum install golang
```

### 1.2.安装xcaddy

xcaddy是caddy的简易安装方式

```shell
go get -u github.com/caddyserver/xcaddy/cmd/xcaddy
cd go/src/github.com/caddyserver/xcaddy/cmd/xcaddy
go build && cp xcaddy /usr/bin
```

编译安装最新的caddy，插件自行选择编译

```shell
xcaddy build \
    --with github.com/caddyserver/nginx-adapter \
    --with github.com/caddyserver/ntlm-transport@v0.1.1
cp /root/go/src/github.com/caddyserver/xcaddy/cmd/xcaddy/caddy /usr/local/bin/
```

查看安装的caddy版本

```bash
[root@66 xcaddy]# caddy version
v2.1.1 h1:X9k1+ehZPYYrSqBvf/ocUgdLSRIuiNiMo7CvyGUQKeA=
```

## 02.安装caddy服务

### 2.1 添加用户和用户组

```shell
sudo groupadd --system caddy
sudo useradd --system \
    --gid caddy \
    --create-home \
    --home-dir /var/lib/caddy \
    --shell /usr/sbin/nologin \
    --comment "Caddy web server" \
    caddy
```

/etc/systemd/system/caddy.service 文件内容

```conf
# caddy.service
#
# For using Caddy with a config file.
#
# Make sure the ExecStart and ExecReload commands are correct
# for your installation.
#
# See https://caddyserver.com/docs/install for instructions.
#
# WARNING: This service does not use the --resume flag, so if you
# use the API to make changes, they will be overwritten by the
# Caddyfile next time the service is restarted. If you intend to
# use Caddy's API to configure it, add the --resume flag to the
# `caddy run` command or use the caddy-api.service file instead.

[Unit]
Description=Caddy
Documentation=https://caddyserver.com/docs/
After=network.target

[Service]
User=caddy
Group=caddy
ExecStart=/usr/bin/caddy run --environ --config /root/mkdocs-caddyy/Caddyfile
ExecReload=/usr/bin/caddy reload --config /root/mkdocs-caddyy/Caddyfile
TimeoutStopSec=5s
LimitNOFILE=1048576
LimitNPROC=512
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
```

caddy adapter支持下述配置文件

> caddyfile (standard)
> nginx
> jsonc
> json5
> yaml
> cue
> toml

### 2.2 运行caddy服务

启动caddy服务

```shell
service caddy start
```

安装mkdocs

```shell
git clone https://github.com/squidfunk/mkdocs-material.git
pip3 install -r mkdocs-material/requirements.txt
mkdocs new .
mkdocs serve
```

### 2.3 访问测试

http://wiki.opschina.top:8001

截图：
![fehelperwikiopschinatop80011597399329756.png](https://b3logfile.com/file/2020/08/fehelperwikiopschinatop80011597399329756-b0c13dd7.png)



附录：

Caddyfile文件内容

```conf
http://wiki.opschina.top:8001 {
reverse_proxy 127.0.0.1:8000
}
```


