title: 火狐浏览器https报错-MOZILLA_PKIX_ERROR_REQUIRED_TLS_FEATURE_MISSING
date: '2020-03-30 10:33:25'
updated: '2020-03-30 10:33:25'
tags: [HTTPS]
permalink: /articles/2020/03/29/1585535605473.html
---
![](https://img.hacpai.com/bing/20180129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 01. 起因

公司网站 https 在谷歌访问正常，在火狐浏览器访问报错

> " MOZILLA_PKIX_ERROR_REQUIRED_TLS_FEATURE_MISSING"

以及证书没有自动更新

## 02. 排查

### 2.1 证书没有自动更新

开启 debug 模式进行调试

./acme.sh xxx --debug

查看日志发现卡在

```
curl -L --silent --dump-header /root/.acme.sh/http.header  -g
```

回想之前有一次也遇到过，通过更新 acme 就可以

将 ./acme.sh --upgrade 加入到定时任务里面，问题解决

### 2.2 火狐浏览器访问问题

在百度查看了，几乎没有用

在谷歌先去查看下什么原因导致的

在这篇文章中找到答案

[《HTTPS connection fails with "MOZILLA_PKIX_ERROR_REQUIRED_TLS_FEATURE_MISSING"》](https://support.mozilla.org/en-US/questions/1149911)

bug 901698 – implement OCSP-must-staple (off by default)

不知道 ocsp 是个什么东西，再次查阅 wiki

> OCSP 装订（英语：OCSP Stapling），正式名称为 TLS 证书状态查询扩展，可代替在线证书状态协议（OCSP）来查询 X.509 证书的状态。[1]服务器在 TLS 握手时发送事先缓存的 OCSP 响应，用户只需验证该响应的有效性而不用再向数字证书认证机构（CA）发送请求。[2][3]

猜测是我的 nginx 那边缺少配置

通过谷歌查 nginx  ocsp 关键字，找到了相关配置

原文地址：https://www.digicert.com/kb/ssl-support/nginx-enable-ocsp-stapling-on-server.htm

```
ssl_stapling on;
ssl_stapling_verify on;
resolver 8.8.4.4 8.8.8.8;
```

把上面那块配置添加到 ssl 那块中，resolver 这个是需要的，不然访问的时候会出域名解析问题，不知道是因为就是需要配置，还是因为网站在七牛云托管导致的

到这里问题就解决了，so happy！
