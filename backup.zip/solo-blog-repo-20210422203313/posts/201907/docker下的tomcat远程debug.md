title: docker 下的 tomcat 远程 debug
date: '2019-07-24 17:35:09'
updated: '2019-07-24 17:35:09'
tags: [Docker, Tomcat]
permalink: /articles/2019/07/24/1563960906839.html
---
```
 docker run --restart always --name tomcat -p 5005:5005 -p 11083:8080 \
-v /root/timezone:/etc/timezone:ro -v /etc/localtime:/etc/localtime:ro \
-v /data/comm/tomcat/lib/druid-1.0.27.jar:/usr/local/tomcat/lib/druid-1.0.27.jar \
-v /data/comm/tomcat/lib/mysql-connector-java-5.1.36-bin.jar:/usr/local/tomcat/lib/mysql-connector-java-5.1.36-bin.jar \
-v /data/dev/xxx/tomcat/conf/server.xml:/usr/local/tomcat/conf/server.xml \
-v /data/dev/xxx/tomcat/logs:/usr/local/tomcat/logs \
-v /data/dev/xxx/tomcat/webapps:/usr/local/tomcat/webapps \
-v /data/dev/xxx:/data/dev/space_project \
-e CATALINA_OPTS="-Xdebug -Xrunjdwp:transport=dt_socket,address=5005,suspend=n,server=y" \
-d tomcat:8
```

最最主要的是加上
`
-e CATALINA_OPTS="-Xdebug -Xrunjdwp:transport=dt_socket,address=5005,suspend=n,server=y"
`


## 在IntelliJ Idea中远程连接tomcat

点击下图红框中的”run”按钮，在下拉菜单中点击“Edit Configurations…“：

![null](https://img.hacpai.com/e/c689dd66390e43dc87f7437e08229d2c.png)

在弹出的菜单中点击“＋“，再点击“Remote“：

![null](https://img.hacpai.com/e/7598286c646540c9b4b46dfcff310b60.png)

如下图，修改Port框中的数字为之前设置的Tomcatdebug端口号（默认8000），如果tomcat部署在其他机器上，请在Host输入框中填入tomcat所在机器的ip：

![null](https://img.hacpai.com/e/02d31d8461f04c85b53018c6aca8c3d9.png)




设置完毕后点击下面的“ok“，回到主窗口后，点击下图红框中的下拉菜单，选中我们刚才新建的debug配置项，再点击小虫按钮，就能连接到tomcat的debug端口了：

![null](https://img.hacpai.com/e/05cfc521003348cd82325feeb3bd4655.png)

如果看到下图则代表成功了

![null](https://img.hacpai.com/e/a2849385f9714d03936c7c634cdc4fa0.png)



idea部分参考自：
https://www.cnblogs.com/summertime-wu/p/9484420.html