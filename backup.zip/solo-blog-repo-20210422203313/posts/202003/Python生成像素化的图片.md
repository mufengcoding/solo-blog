title: Python 生成像素化的图片
date: '2020-03-16 17:04:03'
updated: '2020-03-16 17:04:44'
tags: [Python]
permalink: /articles/2020/03/16/1584349443553.html
---
![](https://img.hacpai.com/bing/20171202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

分享一个 python 的工具，将图片生成像素化的图片。

可以用来生成桌面，图片背景

官方地址：https://github.com/sedthh/pyxelate

### 安装

```
pip3 install git+https://github.com/sedthh/pyxelate.git
```

### 编写 test.py

```
from pyxelate import Pyxelate
from skimage import io
import matplotlib.pyplot as plt

img = io.imread("blade_runner.jpg") #图片的地址
# generate pixel art that is 1/14 the size
height, width, _ = img.shape 
factor = 14
colors = 6
dither = True

p = Pyxelate(height // factor, width // factor, colors, dither)
img_small = p.convert(img)  # convert an image with these settings

_, axes = plt.subplots(1, 2, figsize=(16, 16))
axes[0].imshow(img)
axes[1].imshow(img_small)
plt.show()
```

### 运行

```
python3 test.py
```

![image.png](https://img.hacpai.com/file/2020/03/image-2df35bdb.png)

哈哈可能图片的原因，没有官方 GitHub 的效果好

![image.png](https://img.hacpai.com/file/2020/03/image-ce7e4bf1.png)
![image.png](https://img.hacpai.com/file/2020/03/image-7bd55f5a.png)

更多效果，大家自己挖掘哈
