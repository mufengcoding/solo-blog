title: 'mysql容器启动报错-chown: cannot read directory ''/var/lib/mysql/'': Permission denied'
date: '2020-03-30 10:18:09'
updated: '2020-03-30 10:18:09'
tags: [Docker]
permalink: /articles/2020/03/29/1585534689132.html
---
![](https://img.hacpai.com/bing/20180129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

容器中没有执行权限

挂载外部数据卷时，无法启动容器

报 chown: cannot read directory '/var/lib/mysql/': Permission denied

查看 docker 日志

```
docker logs mysql
```

该原因为 CentOS7 默认开启 selinux

需要临时关闭该安全模块

```
setenforce 0
```

查看

```
getenforce
```

永久修改 selinux

```
vi /etc/selinux/config

enabled 改成 disabled
```

或者添加 selinux 规则，将要挂载的目录添加到白名单： 示例：

```
chcon -Rt svirt_sandbox_file_t   /data/mysql/databases/
```
