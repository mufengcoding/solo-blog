title: Squid 代理访问日志提示 403 错误
date: '2019-09-24 19:32:11'
updated: '2019-09-24 19:32:11'
tags: [squid]
permalink: /articles/2019/09/24/1569324729282.html
---
直接将 http_access deny all 改为 http_access allow all
端口那边改成 0.0.0.0:3128
