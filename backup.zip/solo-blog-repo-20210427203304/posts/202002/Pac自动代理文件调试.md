title: Pac 自动代理文件调试
date: '2020-02-13 19:18:38'
updated: '2020-02-13 19:18:38'
tags: [代理]
permalink: /articles/2020/02/13/1581592716796.html
---
在您的 `.pac` 档案中使用 `alert` 功能。

* 在 Firefox 浏览器中： 工具 - > Web 开发人员 - > 浏览器控制台(Ctrl + Shift + J)[这不是 Web 控制台!!] - > 过滤器输出：`PAC-alert`
* 在 Chrome 浏览器中： [chrome://net-internals/#events](http://chrome//net-internals/#events) - > 搜索包含说明的记录：`PAC_JAVASCRIPT_ALERT` (关于 Chrome 感谢您的回答：[https://serverfault.com/a/738871](https://serverfault.com/a/738871))

示例 `.pac` 文件：

<pre class="hljs javascript"><span class="hljs-function"><span class="hljs-keyword">function</span> <span class="hljs-title">FindProxyForURL</span>(<span class="hljs-params">url, host</span>) </span>{
    alert(<span class="hljs-string">"url = "</span> + url + <span class="hljs-string">" *** host = "</span> + host + <span class="hljs-string">" *** Resolved IP = "</span> + dnsResolve(host));
<span class="hljs-keyword">return</span> <span class="hljs-string">"DIRECT"</span>;
}
</pre>
