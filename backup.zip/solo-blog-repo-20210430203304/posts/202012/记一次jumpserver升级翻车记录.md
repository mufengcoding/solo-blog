title: 记一次jumpserver升级翻车记录
date: '2020-12-16 10:50:33'
updated: '2020-12-16 10:50:33'
tags: [Jumperserver]
permalink: /articles/2020/12/16/1608087033508.html
---
![](https://b3logfile.com/bing/20200918.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 1.简述

跨版本升级 jumpserver从2.4.2升级到2.5.3

## 1.1运行环境

操作系统：centos7.2

jumpserver：2.4.2

mariadb:       5.2.32

## 1.2 为啥要升级

没有为什么，就是脑子抽了下（都是泪）

闲着没事看了下官方版本已经出到2.5.3，当前使用版本才2.4，感觉太低了。查看相应的changlogs，其中有些改动吸引了我

![image.png](https://b3logfile.com/file/2020/12/image-badcf27d.png)

比如上面的bug修复


# 2.版本升级

根据官方的升级操作，step to step往下复制粘贴

![image.png](https://b3logfile.com/file/2020/12/image-f27c1023.png)

....

...

一起都很顺利，开始启动

`./jms start -d`

# 3.入坑

## 3.1第一关：数据库版本

启动报错了，提示数据库版本太低

直接把系统mariadb版本升级到5.7.32，改完继续启动

启动还是报错，具体报错是数据库在迁移的时候出现表字段报错，重新查看官网升级相关说明，原来是这次版本升级的时候Python的一个依赖库只支持mysql，对于mariadb支持不正常，有未知问题。

启动后根据报错，不停的修改migrations里面变更sql，最后终于启动成功。

## 3.2 第二关：浏览器缓存

一切搞完之后，访问luna（webTerminal）一直出现

```bash
connet error
connet close
```

将koko重新安装几次都没有成功，日志中也没有特别的报错

最后在jumpserver官方群里面管理说可能需要清除缓存，按着这个方法试了下可以正常使用

# 4.总结

经过这次血泪教训，这个升级还是要升的，不过要把准备工作做好。官方人员说2.5.x版本的mariadb不兼容，我这边一顿疯狂操作之后，也是能正常使用，遇到问题解决问题，也是那么的顺畅，等待下个版本重新升级下。描述的轻描淡写，不过过程是蛮曲折的，改了很多表的字段和值，特别是时间这个字段，很多都编程了7888-00-00，导致启动获取不到有效期。望各位仁兄此版本升级，慎重！
