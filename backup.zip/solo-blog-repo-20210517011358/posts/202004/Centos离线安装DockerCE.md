title: Centos离线安装DockerCE
date: '2020-04-10 10:00:52'
updated: '2020-04-10 10:00:52'
tags: [Docker, Linux]
permalink: /articles/2020/04/10/1586484052768.html
---
![](https://img.hacpai.com/bing/20200221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

一、简述

离线在Centos中部署DockerCE

二、操作步骤

可上网机器A（最好是纯净的系统）：
1、配置安装源存放路径


```
mkdir -p /root/docker-ce-local && cd /root/docker-ce-local
```


2、获取createrepo安装包
```
yum install --downloadonly --downloaddir=/root/docker-ce-local createrepo
```

3、获取系统更新yum源
```
yum update --downloadonly --downloaddir=/root/docker-ce-local
```
*4、卸载旧版本（如果没有安装过docker跳过）
```
yum remove docker docker-common docker-selinux docker-engine
```
5、获取docker-ce所需依赖
```
yum install --downloadonly --downloaddir=/root/docker-ce-local yum-utils device-mapper-persistent-data lvm2
```
6、设置docker-ce在线存储库
```
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```
7、更新yum源索引
```
yum makecache fast
```
8、获取docker-ce及相关rpm安装源
```
yum install --downloadonly --downloaddir=/root/docker-ce-local docker-ce
```
9、查看安装时docker所需要的密钥并下载
```
more /etc/yum.repos.d/docker-ce.repo
cd /root/docker-ce-local/
wget https://download.docker.com/linux/centos/gpg
```

10、安装createrepo
```
yum install createrepo
```
11、初始化源文件的repodata
```
createrepo -pdo /root/docker-ce-local /root/docker-ce-local
createrepo --update /root/docker-ce-local
```
12、将文件夹打包为yum-local.tgz
```
cd /root
tar -zcvf centos-local.tgz docker-ce-local/
```

不可上网机器B：

1、在目标计算机上将tgz包上传至/root路径下，并解压centos-local.tgz文件
```
cd /root
tar -xvzf centos-local.tgz
```
2、安装createrepo
```
cd /root/docker-ce-local
rpm -ivh createrepo-0.9.9-28.el7.noarch.rpm
```
注：createrepo版本可能不一样，根据自己下载的包的版本安装

3、备份安装源，将所有的安装源移动到备份文件夹中
```　　
cd /etc/yum.repos.d/
mkdir repobak
mv CentOS* repobak/
```

4、新增docker-ce-local.repo源文件，写入以下内容
```
vi /etc/yum.repos.d/docker-ce-local.repo
[docker-ce-local]
name=Local Yum
baseurl=file:///root/docker-ce-local/
gpgcheck=1
gpgkey=file:///root/docker-ce-local/gpg
enabled=1
```

5、生成源索引及缓存
```
createrepo /root/docker-ce-local
yum makecache
```
6、安装docker-ce
```
yum install docker-ce
```
7、启动并测试
```
systemctl start docker.service
docker version
```


需要注意的是机器A和B一定要系统版本一致，否则会出现缺少依赖

也可以缺少什么找对应的rpm包也是可以的

原文地址：https://www.cnblogs.com/adolfmc/p/11724334.html
