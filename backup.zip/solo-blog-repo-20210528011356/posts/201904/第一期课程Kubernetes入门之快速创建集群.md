title: 第一期课程《Kubernetes 入门之快速创建集群》
date: '2019-04-03 22:02:32'
updated: '2019-04-03 22:02:32'
tags: [Kubernetes]
permalink: /articles/2019/04/03/1554300144376.html
---
> [沐风](https://blog.mufengs.com)

第二次参加rancher在线培训

k8s的发展速度特别快，当时使用的版本最新还是1.8，现在已经是1.13了

本期新版rancher的课程大纲如下：

- 快速部署单节点Rancher Server

- 快速创建AWS集群

- 快速部署工作负载

- 通过node port暴露服务

- 扩容AWS集群

- 创建腾讯云托管k8s集群

- 导入已有k8s集群

- 创建custom集群（RKE YAML配置参数）

- 创建ARM64集群

- 创建Windows集群

最在意的是最后一点支持windows的集群创建



k8s1.14最新资讯，k8s支持window节点生产使用

在Kubernetes中启用Windows容器的一些主要功能包括：

 
*   支持Windows Server 2019的工作站节点和容器
    
*   支持Azure-CNI、OVN-Kubernetes和Flannel的树外网络连接
    
*   改进了对pod、服务类型、工作负载控制器和指标/配额的支持，以便与Linux容器提供的功能紧密匹配

