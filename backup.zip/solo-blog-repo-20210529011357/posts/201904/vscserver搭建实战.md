title: vsc server 搭建实战
date: '2019-04-21 21:29:29'
updated: '2019-04-21 21:29:29'
tags: [Python, Docker, VSCode]
permalink: /articles/2019/04/21/1555853363410.html
---
> [沐风](https://blog.mufengs.com)

官网地址：https://github.com/codercom/code-server

操作系统环境：
centos7.5
1核1G
20G硬盘

软件环境：
docker 1.18.09
![image.png](https://img.hacpai.com/file/2019/04/image-488ce780.png)

安装code-server

````
docker run -it -p 127.0.0.1:8443:8443 -v "${PWD}:/home/coder/project" codercom/code-server --allow-http --no-auth
````

这边会出先几个问题，一个是权限不够的问题

我是在root下运行的，需要把${PWD}改成/opt或者其他

一个是防火墙的问题，打开防火墙的8443端口

效果预览
![image.png](https://img.hacpai.com/file/2019/04/image-66f88755.png)

这边就可以看出来和本机运行的一样

可以更方便的进行python或其他编程语言的开发

让我一起来体验一下吧。


