title: python 的数据库管理系统 -1
date: '2018-12-16 21:10:08'
updated: '2018-12-16 21:10:08'
tags: [运维, MySQL, 原创]
permalink: /articles/2018/12/16/1544965805650.html
---
## 起源
1.数据库太多通过navicat链接麻烦，不能将所有的用户名密码给出去
2.数据库审计回滚 （我觉不适合我现在公司 ，人少会觉的麻烦 ），因为执行ddl需要提交工单
3.统一管理数据库，后续加上操作redis等等

## 项目基础
项目基于yearning
项目地址https://github.com/cookieY/yearning

## 二次开发环境搭建
`git clone https://github.com/cookieY/Yearning.git`
### 安装数据库
docker run -d -p 3306:3306 --name=mysql mysql/mysql

### 安装yearning
```
1. 新建Yearning库，设置字符集为UTF-8，然后在Yearning库中导入sql文件(Yearning/install/yearning-docker-compose/init-sql)

2. docker run -d -e HOST=主机地址 -e MYSQL_ADDR=mysql地址 -e MYSQL_USER=mysql用户名 -e MYSQL_PASSWORD=mysql密码 -p8080:80 -p8000:8000 registry.cn-hangzhou.aliyuncs.com/cookie/yearning:v1.3.4 
```
之后访问8080端口
默认用户admin 密码: Yearning\_admin

### 代码外挂修改
```docker cp id:/mnt/src ./```
```docker cp id:/lib/nginx/html ./```

后段代码修改 有可能需要重启容器  原因没有高兴去研究
前端文件的话是需要编译的
```npm run build```
``cp -r dist/* /html/``

### 现状和Todo
1.去掉代码审计和回滚（原因麻烦）
2.开放ddl操作权限
3.接下来添加数据库ssh代理链接和redis等数据库管理

### 截图


![imagepng](https://img.hacpai.com/file/2018/12/image-5ee3b3a3.png)

