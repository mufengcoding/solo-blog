title: MAC下pip使用阿里云安装加速
date: '2019-07-04 22:29:09'
updated: '2019-07-04 22:29:09'
tags: [Python]
permalink: /articles/2019/07/04/1562250549731.html
---
#### 相关配置
使用pip的时候加参数-i https://pypi.tuna.tsinghua.edu.cn/simple
  
>临时使用:

例如：
```
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -f requirements.txt
```
这样就会从清华这边的镜像去安装依赖。

 
>永久修改：

 
linux下

修改 ~/.pip/pip.conf (没有就创建一个)， 修改 index-url至tuna，内容如下：
``` 
[global]
 index-url = https://pypi.tuna.tsinghua.edu.cn/simple
```
mac下
```
mkdir ~/.pip
tee ~/.pip/pip.conf <<-'EOF'
	[global]
	index-url=http://mirrors.http://aliyun.com/pypi/simple/
	[install]
	trusted-host=mirrors.aliyun.com
EOF
```

#### 效果对比

使用加速之前
![image.png](https://img.hacpai.com/file/2019/07/image-53d22b4b.png)
配置加速之后
![image.png](https://img.hacpai.com/file/2019/07/image-0e696fea.png)
明显速度快的是不是一倍两倍了
