title: jenkins升级【docker版本】
date: '2021-04-19 21:57:13'
updated: '2021-04-19 21:57:13'
tags: [Jenkins]
permalink: /articles/2021/04/19/1618840633907.html
---
进入 Jenkins 容器在宿主机的挂载目录/home/jenkins中

cd /home/jenkins

在 CentOS7 中下载Jenkins的最新war包

wget http://mirrors.jenkins.io/war/latest/jenkins.war

进入容器

docker exec -it -u root +ContainerId bash

查看容器中jenkins war包的位置，并备份原来的war包

whereis jenkins
cd /usr/share/jenkins
cp jenkins.war jenkinsBAK.war

将/var/jenkins_home下的包cp到/usr/share/jenkins下覆盖

cp /var/jenkins_home/jenkins.war /usr/share/jenkins/

退出容器并重启

exit
docker restart +ContainerName



这边发现cp /var/jenkins_home/jenkins.war /usr/share/jenkins/的时候出现没有权限


原因：进入容器时，没有添加-u 参数

没有权限的命令行：docker exec -it jenkins /bin/bash

不汇报权限问题的命令：docker exec -it -u root jenkins  /bin/bash
