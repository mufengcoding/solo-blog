title: 'Navicat 使用 sshtunnel 报错报错 80070007: SSH Tunnel: Server does not support diffie-hellman-group1-sha1
  for keyexchange'
date: '2019-09-24 17:31:17'
updated: '2019-09-24 17:31:44'
tags: [Navicat]
permalink: /articles/2019/09/24/1569317475381.html
---
之前的centos作为跳板链接数据库没有出现这个问题，后来那个机器有问题就使用deepin作为跳板机进行操作了

同事Navicat版本：10.1
我的Navicat版本：12.0.19

我的可以，同事的不可以，可能和navicat的版本也有关系，没有详细的去找原因


修改deepin跳板机的ssh配置
```
vi /etc/ssh/sshd_config
```
在最后一行添加
```
KexAlgorithms diffie-hellman-group1-sha1,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha1
Ciphers 3des-cbc,blowfish-cbc,aes128-cbc,aes128-ctr,aes256-ctr
```

重启openssh服务
```
service sshd restart
```
链接成功

最后总结下，可能和navicat的低版本有关
