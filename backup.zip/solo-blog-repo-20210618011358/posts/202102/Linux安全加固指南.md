title: Linux 安全加固指南
date: '2021-02-03 11:22:27'
updated: '2021-02-03 11:22:27'
tags: [翻译]
permalink: /articles/2021/02/03/1612322532195.html
---
原文链接：https://madaidans-insecurities.github.io/guides/linux-hardening.html#tiocsti

更新时间：2020年12月25日

Linux不是一个安全的开源系统。但是，你可以采取一些措施来提升它的安全性。本指南旨在说明如何尽可能加强Linux的安全性和隐私性。本指南试图与发行版无关，不限于任何特定的发行版本。

免责声明：如果你不清楚的知道你在做什么，请不要尝试应用本文中的任何内容。本指南仅关注安全性和隐私性，而不关注性能，可用性或其他任何内容。

在文章中列出的所有命令都是需要root权限的。以“$”开头的单词表示变量，不同用户的变量会存在差异，需要根据环境做出相应调整。

目录

1. 选择正确的Linux发行版本
2. 内核加固

1) 稳定版本VS长期支持版本
2) Sysctl

• Kernel自我保护

• 网络

• 用户空间

3) Boot参数

• Kernel自我保护

• CPU缓解

• 效果

4) 隐藏进程
5) 减少内核攻击面

• Boot参数

• 内核黑名单模块

• rfkill

6) 其他内核指针泄露
7) 限制对sysfs的访问
8) Linux强化包
9) 安全性
10) Linux内核运行时防护
11) 内核自编译

3. 强制访问控制
4. 沙盒

1) 应用沙盒
2) 常见的沙箱逃逸

• 脉冲音频

• [D-Bus](https://madaidans-insecurities.github.io/guides/linux-hardening.html#d-bus)

• GUI隔离

• 进程跟踪

• [TIOCSTI](https://madaidans-insecurities.github.io/guides/linux-hardening.html#tiocsti)

3) Systemd服务沙盒
4) [gVisor](https://madaidans-insecurities.github.io/guides/linux-hardening.html#gvisor)
5) 虚拟机

5. 强化内存分配器
6. 强化编译标志
7. 内存安全语言
8. root账号

1) [/etc/securetty](https://madaidans-insecurities.github.io/guides/linux-hardening.html#securetty)
2) 限制su
3) 锁定root账户
4) 禁止root通过SSH登录
5) 增加哈希轮数
6) 限制Xorg的root访问
7) 安全地访问root

9. 防火墙
10. 身份标识

1) 主机名和用户名
2) 时区/语言区域/键盘映射
3) 机器ID
4) MAC地址欺骗
5) 时间攻击

• ICMP时间戳

• TCP时间戳

• TCP初始化序列号

• 时间同步

6) 按键指纹

11. 文件授权

1) 设置gid和uid
2) 设置unmask

12. 核心转存

• sysctl

• systemd

• ulimit

• s[etuid processes](https://madaidans-insecurities.github.io/guides/linux-hardening.html#core-dumps-setuid)

13. 内存交换
14. PAM
15. microcode更新
16. IPv6隐私扩展

1) [NetworkManager](https://madaidans-insecurities.github.io/guides/linux-hardening.html#ipv6-networkmanager)
2) [systemd-networkd](https://madaidans-insecurities.github.io/guides/linux-hardening.html#ipv6-systemd-networkd)

17. 分区和挂载点
18. 熵

1) 额外的熵源
2) [RDRAND](https://madaidans-insecurities.github.io/guides/linux-hardening.html#rdrand)

19. 以root权限编辑文件
20. 特定发行版的强化

1) HTTPS包管理器镜像
2) APT seccomp-bpf

21. 物理安全

1) 加密
2) BIOS / UEFI加固
3) 引导程序密码

• GRUB

• Syslinux

• systemd-boot

4) boot校验
5) USB接口
6) DMA攻击
7) 冷启动攻击

22. 最佳实践

持续翻译中，欢迎━(*｀∀´*)ノ亻!提意见
