title: docx转html、md
date: '2021-01-15 17:36:28'
updated: '2021-01-15 17:37:08'
tags: [Python]
permalink: /articles/2021/01/15/1610703388385.html
---
![](https://b3logfile.com/bing/20210107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

平时文档有时候用word

有时候用网页

有时候用markdown来写

导致后来整理起来很麻烦

然后就捣鼓着把docx转成md文件，统一保存

不经常写代码，可以使用，优化的地方也有，不过可以临时应急用下

![image.png](https://b3logfile.com/file/2021/01/image-420ad614.png)

gitee仓库地址如下：

https://gitee.com/mfeng1/docx2html2md

欢迎大伙来体验下，提提issue之类的，给个小心心也是极好的
