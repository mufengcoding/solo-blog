title: vps 配置邮件备份 solo
date: '2018-10-19 01:08:01'
updated: '2018-10-25 11:49:00'
tags: [Solo, B3log, 备份]
permalink: /articles/2018/10/18/1539882476490.html
---
### 安装mailx

> yum install mailx -y

### 配置mail.rc

> vi /etc/mail.rc

```
 set from="mufeng56191@163.com" 

set smtp=smtps://smtp.163.com:465

set smtp-auth-user=xxxxx

set smtp-auth-password=xxxxx

set smpt-auth=login

#set smtp-use-starttls=true

set ssl-verify=ignore

set nss-config-dir=/root/.certs
```

### 生成163 证书
```
mkdir -p /root/.certs/                           ####创建目录，用来存放证书  
echo -n | openssl s\_client -connect smtp.163.com:465 | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > ~/.certs/163.crt ####向163请求证书
  
depth=2 C = US, O = GeoTrust Inc., CN = GeoTrust Global CA  
verify return:1  
depth=1 C = US, O = GeoTrust Inc., CN = GeoTrust SSL CA - G3  
verify return:1  
depth=0 C = CN, ST = Zhejiang, L = Hangzhou, O = "NetEase (Hangzhou) Network Co., Ltd", OU = MAIL Dept., CN = \*.163.com  
verify return:1  
DONE  

 certutil -A -n "GeoTrust SSL CA" -t "C,," -d ~/.certs -i ~/.certs/163.crt                  ####添加一个证书到证书数据库中  

 certutil -A -n "GeoTrust Global CA" -t "C,," -d ~/.certs -i ~/.certs/163.crt               ####添加一个证书到证书数据库中  

 certutil -L -d /root/.certs                                                                                         ####列出目录下证书  
Certificate Nickname Trust Attributes  
SSL,S/MIME,JAR/XPI  
GeoTrust SSL CA
```
### 测试邮件发送
```
mailx -v -s 邮箱测试 1126501575@qq.com < 163.crt
```
```shell
Resolving host smtp.163.com . . . done.

Connecting to 123.125.xx.133:465 . . . connected.

Comparing DNS name: "\*.163.com"

SSL parameters: cipher=AES-256-GCM, keysize=256, secretkeysize=256,

issuer=CN=GeoTrust SSL CA - G3,O=GeoTrust Inc.,C=US

subject=CN=\*.163.com,O="NetEase (Hangzhou) Network Co., Ltd",L=HangZhou,ST=ZheJiang,C=CN

220 163.com Anti-spam GT for Coremail System (163com\[20141201\])

\>>> EHLO vultr.guest

250-mail

250-PIPELINING

250-AUTH LOGIN PLAIN

250-AUTH=LOGIN PLAIN

250-coremail 1Uxr2xKj7kG0xkI17xGrU7I0s8FY2U3Uj8Cz28x1UUUUU7Ic2I0Y2UFqBWZOUCa0xDrUUUUj

250-STARTTLS

250 8BITMIME

\>>> AUTH LOGIN

334 dXNlcm5hbWU6

\>>> bXVmZW5nNTYxOQ==

334 UGFzc3dvcmQ6

\>>> bXVmZW5nNTYxOQ==

235 Authentication successful

\>>> MAIL FROM:<mufeng56x9@163.com>

250 Mail OK

\>>> RCPT TO:<xx265xxx575@qq.com>

250 Mail OK

\>>> DATA

354 End data with <CR><LF>.<CR><LF>

\>>> .

250 Mail OK queued as smtp3,DdGowACHgZ3hrchb2KIvAA--.29S2 1539878374

\>>> QUIT

221 Bye
```
到此邮件支持就已经完成了

### 定时任务脚本
```shell
tar -czvf blog_$(date +%Y_%m_%d).tar.gz blog solo_h2

echo "博客备份"| mailx -v -a ../blog\_2018\_10\_18.tar.gz -s 邮箱测试 ab12222@qq.com
```

### 添加定时任务
```
[root@vultr ~]# crontab -l

0 0 3 * * /bin/bash /root/bakup.sh
```

再也不用担心服务器挂掉的问题了