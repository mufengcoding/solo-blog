title: 如何让 caddy2 使用 cloudflare https证书自动更新
date: '2020-03-02 09:09:44'
updated: '2020-03-02 09:10:44'
tags: [Caddy]
permalink: /articles/2020/03/01/1583111384112.html
---
众所周知，caddy2 可以使用 caddy1 的 caddyfile

首先在 cloudflare 获取 apikey

![image.png](https://img.hacpai.com/file/2020/03/image-1b8ced7c.png)

在服务器先注册变量

```
export CLOUDFLARE_API_KEY="xxxxxxxxxxxxxxx"
export CLOUDFLARE_EMAIL="xxx@gmail.com"
```

caddy 配置如下
![image.png](https://img.hacpai.com/file/2020/03/image-1096db8a.png)
主要是这一部分

```
tls {
    dns cloudflare
}
```

直接上传配置，生效

```
curl localhost:2019/load \
  -X POST \
  -H "Content-Type: text/caddyfile" \
  --data-binary @Caddyfile
```

使用 caddy2 默认的 JSON 可以用这样的方式，以下引用自官网

> 您可以使用配置适配器，方法是在命令行上通过使用--adapter 大多数接受配置的子命令上的标志来指定配置适配器：

```
caddy run --config caddy.yaml --adapter yaml
```

> 或通过/load 端点上的 API ：

```
curl localhost:2019/load \
	-X POST \
	-H "Content-Type: application/yaml" \
	--data-binary @caddy.yaml
	-X POST \
	-H "Content-Type: application/yaml" \
	--data-binary @caddy.yaml
	-X POST \
	-H "Content-Type: application/yaml" \
	--data-binary @caddy.yaml
	-H "Content-Type: application/yaml" \
	--data-binary @caddy.yaml
	-H "Content-Type: application/yaml" \
	--data-binary @caddy.yaml
	--data-binary @caddy.yaml
	--data-binary @caddy.yaml
```

> 如果您只想获取输出 JSON 而不运行它，则可以使用以下 caddy adapt 命令：

```
caddy adapt --config caddy.yaml --adapter yaml
```

@lizhongyue248 兄弟你参考下，应该问题不大。。。
