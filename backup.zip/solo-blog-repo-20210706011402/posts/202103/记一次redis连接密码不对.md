title: 记一次redis连接密码不对
date: '2021-03-05 17:11:38'
updated: '2021-03-05 17:11:38'
tags: [待分类]
permalink: /articles/2021/03/05/1614935498246.html
---
报错现象：

(error) WRONGPASS invalid username-password pair or user is disabled.

解决办法：

由于redis的版本新特性，6.0之后引入username，登录的时候需要传入username，但是不想变动程序，将redis版本降到5.0.12解决问题。
