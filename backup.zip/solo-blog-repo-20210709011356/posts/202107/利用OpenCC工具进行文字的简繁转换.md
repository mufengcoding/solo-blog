title: 利用 OpenCC 工具进行文字的简繁转换
date: '2021-07-08 13:21:03'
updated: '2021-07-08 13:21:03'
tags: [openCC]
permalink: /articles/2021/07/08/1625721662740.html
---
为了将项目整体翻译成 繁体

## OpenCC

OpenCC 正好符合我的预期，先来介绍一下它。

Open Chinese Convert（OpenCC）是一个开源的中文简繁转换项目，致力于制作高质量的基于统计预料的简繁转换词库。

-- 介绍来自网上

使用 brew 安装 OpenCC

<pre>$ brew install OpenCC</pre>

查看当前安装的版本

```
$ opencc --version

Open Chinese Convert (OpenCC) Command Line Tool
Version: 1.0.5
```

先来简单地测试一下工具

```
$ echo '测试简繁转换' | opencc -c s2t
測試簡繁轉換
$ echo '測試簡繁轉換' | opencc -c t2s
测试简繁转换
```

可以看到，简繁互相转换成功。

那么回到主题，如何批量转换文件呢？噢，对了，先了解一下转换单个文件，它的语法是这样的

<pre>opencc -i <源文件> -c s2t -o <转换后的文件></pre>

为了批量转换 .m 文件，我特意写了个 shell 脚本。

```
res=`find . -type f -name '*.m'`

for file in $res
do
    echo $file
    opencc -i $file -c s2t -o $file
done
```

这个应该是可以优化的，命令行应该一句话就可以搞掂了，但我还没熟悉到这种程度。哪个大神知道的，希望可以在评论区留下你的宝贵经验，在此先谢谢。


本文来源：[码农网](https://www.codercto.com/)
本文链接：https://www.codercto.com/a/92171.html
