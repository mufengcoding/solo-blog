title: Django 基础入门篇（一）
date: '2019-04-30 10:44:36'
updated: '2019-04-30 10:45:01'
tags: [Python]
permalink: /articles/2019/04/30/1556635472567.html
---
## 1.概述
![null](https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=713046824,4062371468&fm=26&gp=0.jpg)
为啥选择Django？我不知道，但我知道并可以肯定的是，这种问题你去度娘或者谷歌的话，会出现很多优秀的答案。而我并不关心这点，我选择Django，仅仅是为了去学[jumpserver](https://www.jumpserver.org)开源堡垒机的源码，并尝试做一些简单常用的二次开发。

![null](https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1775603651,194680732&fm=58&s=53321C62269ABE200D070244030080FE&bpow=121&bpoh=75)


## 2.安装Django

基本环境：
操作系统-macOS Mojave
内存-16G
python版本-3.7

使用python安装Django
`pip install Django`

查看Django版本
`python -m django --version`
![image.png](https://img.hacpai.com/file/2019/04/image-9da85699.png)

## 3.初始化Django项目

创建一个工作目录
`mkdir demo && cd demo`

在工作目录下执行初始化命令
`django-admin startproject mysite`
![image.png](https://img.hacpai.com/file/2019/04/image-d61eac2d.png)
```
(venv)  mac@mufengs  ~/PycharmProjects/Django_indoor/Djangoblog/demo   master ●✚  tree
.
└── mysite
    ├── manage.py
    └── mysite
        ├── __init__.py
        ├── settings.py
        ├── urls.py
        └── wsgi.py
2 directories, 5 files
```

## 4.启动demo项目

`cd mysite &  python manage.py runserver`

访问127.0.0.1:8000查看结果
![image.png](https://img.hacpai.com/file/2019/04/image-32d7c449.png)

good job！大功告成！建一个demo是很简单的事情，难得是实际中怎么进行疯狂输出！


