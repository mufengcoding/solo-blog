title: 啃下 python（一）-- 环境安装
date: '2018-12-25 10:18:08'
updated: '2018-12-25 10:18:08'
tags: [Python, 原创]
permalink: /articles/2018/12/25/1545751085393.html
---
# pyenv安装
下载pyenv，并使其在终端生效
```
git clone https://github.com/yyuu/pyenv.git ~/.pyenv
echo 'export PYENV_ROOT="$HOME/.pyenv"' >> ~/.bash_profile
echo 'export PATH="$PYENV_ROOT/bin:$PATH"' >> ~/.bash_profile
echo 'eval "$(pyenv init -)"' >> ~/.bash_profile
```
重启shell终端

`exec $SHELL
`

# 安装python3.7.1

安装相关依赖

yum install zlib-devel bzip2 bzip2-devel readline-devel sqlite sqlite-devel openssl-devel xz xz-devel libffi-devel -y

使用pyenv安装3.7.1

```
pyenv install 3.7.1
```
这边时间稍微长点

# 安装python虚拟环境
```
git clone https://github.com/yyuu/pyenv-virtualenv.git ~/.pyenv/plugins/pyenv-virtualenv
echo 'eval "$(pyenv virtualenv-init -)"' >> ~/.bash_profile
exec $SHELL
eval "$(pyenv virtualenv-init -)"
pyenv virtualenv 3.7.1 dev
pyenv local dev
```
cd /home/dev

![imagepng](https://img.hacpai.com/file/2018/12/image-8dff8ad9.png)

这边就可以在dev下虚拟一个开发用的环境


![imagepng](https://img.hacpai.com/file/2018/12/image-cdbe119a.png)

dev下的3.7.1的第三方包处于这个地方

# 安装ipython
```
mdkir /root/.pip
touch .pip/pip.conf
echo "
[global]
index-url=https://mirrors.aliyun.com/pypi/simple/
[install]
trusted-host=mirrors.aliyun.com
">.pip/pip.conf

pip install ipython jupyter
```
jupyter notebook

![imagepng](https://img.hacpai.com/file/2018/12/image-73d271a5.png)

新建一个目录
mkdir  -p /root/.jupyter
jupyter notebook passwd

jupyter notebook --ip=0.0.0.0

![imagepng](https://img.hacpai.com/file/2018/12/image-3d332c29.png)



# 杂谈
pyenv shell global local 这三个区别
1.shell会话级别
2.global影响全局，影响面大，不建议
3.local当前 推荐使用