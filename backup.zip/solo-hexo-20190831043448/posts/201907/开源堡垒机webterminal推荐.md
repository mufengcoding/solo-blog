title: 开源堡垒机 webterminal 推荐
date: '2019-07-07 00:12:10'
updated: '2019-07-07 00:12:10'
tags: [堡垒机, jumpserver]
permalink: /articles/2019/07/07/1562472728657.html
---
## 简介
>ssh rdp vnc telnet sftp bastion/jump web putty xshell terminal jumpserver audit realtime monitor rz/sz 堡垒机 云桌面 linux devops sftp websocket file management rz/sz 自动化运维 审计 录像 文件管理 sftp上传 实时监控 录像回放 网页版rz/sz上传下载 djang

目前在使用jumpserver，忽然看到了这个项目，做了下简单的对比

#### 部署：
jumperserver 复杂于[webterminal](https://github.com/jimmy201602/webterminal)

#### 功能：
jumpsever 占据上风

#### 使用：
jumperserver使用koko做web控制台
webterminal使用webterminal做控制台，支持本地ssh ftp工具
个人觉的webterminal占一点优势

#### 界面：
jumpserver要比webterminal美观一些
jumpserver图片如下：
![image.png](https://img.hacpai.com/file/2019/07/image-8f6f3908.png)
webterminal图片如下：
![image.png](https://img.hacpai.com/file/2019/07/image-94527d2d.png)

大家可以取尝试下，各有所长，根据自己需要选择

jumperserver演示站点如下：
https://demo.jumpserver.org/auth/login/?next=/

webterminal演示站点如下：
http://193.112.194.114:8000/
user/password: demo/demo12345678
[poll1562472667055]


附录：
github地址
https://github.com/jumpserver/jumpserver
https://github.com/jimmy201602/webterminal



