title: 阿里云快速迭代工具 Cloud Toolkit---pycharm 版
date: '2019-03-13 10:34:24'
updated: '2019-03-13 10:34:24'
tags: [待分类]
permalink: /articles/2019/03/13/1552487661162.html
---
>[沐风](https://hacpai.com/forward?goto=https%3A%2F%2Fblog.mufengs.com)

*   标准的 Java Web Tomcat 应用
*   标准的 Java Fatjar 应用
*   标准的 Spring Boot 应用
*   标准的 Go 应用

首先我这边先安装一个pycharm

安装过程不细说，安装完成如下
![image.png](https://img.hacpai.com/file/2019/03/image-cfc8c5a6.png)
我这边安装的是2018.3.2版本的

安装包下载地址：https://yq.aliyun.com/attachment/download/?spm=a2c4e.11153940.blogcont692467.9.6c4078713zAkG3&id=6471

安装插件
第一步 打开配置
![image.png](https://img.hacpai.com/file/2019/03/image-e8a587f3.png)
第二步 选择plugins
![image.png](https://img.hacpai.com/file/2019/03/image-5e6e534a.png)
第三步 在marketplace搜索Cloud Toolkit
![image.png](https://img.hacpai.com/file/2019/03/image-e6b8186d.png)

这边的话可能设计到pycharm插件下载源的配置，这边不做说明，有需要的朋友可以直接百度

到此我们的Cloud Toolkit已经安装完成了

配置我们的阿里云帐号ak

![image.png](https://img.hacpai.com/file/2019/03/image-6f81d1bb.png)

将你的阿里云的ak填入下面马赛克的地方

![image.png](https://img.hacpai.com/file/2019/03/image-c7fa4f37.png)

配置完之后我们测试下

![image.png](https://img.hacpai.com/file/2019/03/image-ef2939f2.png)

我们这边测试下快速部署到阿里云，别问为什么因为只买的起ecs

![image.png](https://img.hacpai.com/file/2019/03/image-65a6d654.png)

我们将本地的test.py上传到服务器上的root下，并且执行 ll和pwd的命令

![image.png](https://img.hacpai.com/file/2019/03/image-8014b879.png)

控制台输出上面信息表示执行成功

测试部署一个单文件，并运行

![image.png](https://img.hacpai.com/file/2019/03/image-d317d578.png)

点击右下脚的run，可以看到我们想demo已经成功部署

![image.png](https://img.hacpai.com/file/2019/03/image-759373e9.png)

感谢阿里云，这样以后基于云部署就方便很多，同时也支持文件上传等高级功能


其他编程语言类似，详细参考
产品地址：https://help.aliyun.com/document_detail/29968.html?spm=a2c4g.11186623.6.542.2cd45758ubqBvl


[poll1552487614412]




