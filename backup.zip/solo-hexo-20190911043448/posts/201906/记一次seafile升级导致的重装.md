title: 记一次 seafile 升级导致的重装
date: '2019-06-25 21:54:14'
updated: '2019-06-25 21:54:14'
tags: [seafile, Docker]
permalink: /articles/2019/06/25/1561514006630.html
---
还记得上一期，写了
https://blog.mufengs.com/articles/2019/02/28/1551343140136.html

最近看到seafile支持多人同时在线升级，激动万分，于是就开始升级了

下载了最新的包，到制定位置解压

发现各种被占用，最后更新完了，发现ccnet配置了访问路径，还是只能本地访问127.0.0.1:8000

纠结万分之后，决定重装。不幸中的万幸是，这个只有我一个人用，所有的数据都有备份


## 快速开始
#### 安装 docker-compose

因为 Seafile v7.x.x 容器是通过 docker-compose 命令运行的，所以您应该先在服务器上安装该命令。
```
# for CentOS

yum install docker-compose -y

# for Ubuntu

apt-get install docker-compose -y
```

#### 下载并修改 docker-compose.yml
```
version: '2.0'
services:
  db:
    image: mariadb:10.1
    container_name: seafile-mysql
    environment:
      - MYSQL_ROOT_PASSWORD=db_dev  # Requested, set the root's password of MySQL service.
      - MYSQL_LOG_CONSOLE=true
    volumes:
      - /opt/seafile-mysql/db:/var/lib/mysql  # Requested, specifies the path to MySQL data persistent store.
    networks:
      - seafile-net

  memcached:
    image: memcached:1.5.6
    container_name: seafile-memcached
    entrypoint: memcached -m 256
    networks:
      - seafile-net
          
  seafile:
    image: seafileltd/seafile-mc:latest
    container_name: seafile
    ports:
      - "80:80"
#     - "443:443"  # If https is enabled, cancel the comment.
    volumes:
      - /opt/seafile-data:/shared   # Requested, specifies the path to Seafile data persistent store.
    environment:
      - DB_HOST=db
      - DB_ROOT_PASSWD=db_dev  # Requested, the value shuold be root's password of MySQL service.
#      - TIME_ZONE=Asia/Shanghai # Optional, default is UTC. Should be uncomment and set to your local time zone.
      - SEAFILE_ADMIN_EMAIL=me@example.com # Specifies Seafile admin user, default is 'me@example.com'.
      - SEAFILE_ADMIN_PASSWORD=asecret     # Specifies Seafile admin password, default is 'asecret'.
      - SEAFILE_SERVER_LETSENCRYPT=false   # Whether to use https or not.
      - SEAFILE_SERVER_HOSTNAME=seafile.example.com # Specifies your host name if https is enabled.
    depends_on:
      - db
      - memcached
    networks:
      - seafile-net

networks:
  seafile-net:
```
下载 docker-compose.yml 示例文件到您的服务器上，然后根据您的实际环境修改该文件。尤其是以下几项配置：

MySQL root 用户的密码 (MYSQL_ROOT_PASSWORD and DB_ROOT_PASSWD)

持久化存储 MySQL 数据的 volumes 目录 (volumes)

持久化存储 Seafile 数据的 volumes 目录 (volumes)

持久化存储 Elasticsearch 索引数据的 volumes 目录 (volumes)

#### 启动 Seafile 服务
执行以下命令启动 Seafile 服务
```
docker-compose up -d
```
需要等待几分钟，等容器首次启动时的初始化操作完成后，您就可以在浏览器上访问http://seafile.example.com 来打开 Seafile 主页。

注意：您应该在 docker-compose.yml文件所在的目下执行以上命令。




然后重启这个容器：

docker-compose restart


更多配置项
自定义管理员用户名和密码
默认的管理员账号是 me@example.com 并且该账号的密码是 asecret，您可以在 docker-compose.yml 中配置不同的用户名和密码，为此您需要做如下配置：
```
seafile:

    ...

﻿

    environment:

        ...

        - SEAFILE_ADMIN_EMAIL=me@example.com

        - SEAFILE_ADMIN_PASSWORD=a_very_secret_password

        ...

```
使用 Let's encrypt SSL 证书
如果您把 SEAFILE_SERVER_LETSENCRYPT 设置为 true，该容器将会自动为您申请一个 letsencrypt 机构颁发的 SSL 证书，并开启 https 访问，为此您需要做如下配置：
```
seafile:

    ...

    ports:

        - "80:80"

        - "443:443"

    ...

    environment:

        ...

        - SEAFILE_SERVER_LETSENCRYPT=true

        - SEAFILE_SERVER_HOSTNAME=seafile.example.com

        ...

```
如果您想要使用自己的 SSL 证书，而且如果用来持久化存储 Seafile 数据的目录为 /opt/seafile-data，您可以做如下处理：

创建 /opt/seafile-data/ssl 目录，然后拷贝您的证书文件和密钥文件到ssl目录下。

假设您的站点名称是 seafile.example.com，那么您的证书名称必须就是 seafile.example.com.crt，密钥文件名称就必须是 seafile.example.com.key。

#### 修改 Seafile 服务的配置
Seafile 的配置文件存放在 shared/seafile/conf 目录下，您可以根据Seafile 手册的指导来修改这些配置项。

一旦修改了配置文件，您需要重启服务以使其生效：

docker-compose restart


查找日志
Seafile 容器中 Seafile 服务本身的日志文件存放在 /shared/logs/seafile 目录下，或者您可以在宿主机上 Seafile 容器的卷目录中找到这些日志，例如：/opt/seafile-data/logs/seafile

同样 Seafile 容器的系统日志存放在 /shared/logs/var-log 目录下，或者宿主机目录 /opt/seafile-data/logs/var-log。

增加一个新的管理员
确保各容器正常运行，然后执行以下命令：
```
docker exec -it seafile /opt/seafile/seafile-server-latest/reset-admin.sh

```
根据提示输入用户名和密码，您现在有了一个新的管理帐户。

#### Seafile 目录结构
/shared
共享卷的挂载点,您可以选择在容器外部存储某些持久性信息.在这个项目中，我们会在外部保存各种日志文件和上传数据。 这使您可以轻松重建容器而不会丢失重要信息。

/shared/seafile: Seafile 服务的配置文件以及数据文件

/shared/logs: 日志目录

/shared/logs/var-log: 我们将容器内的/var/log链接到本目录。您可以在/shared/logs/var-log/nginx/中找到 nginx 的日志文件

/shared/logs/seafile: Seafile 服务运行产生的日志文件目录。比如您可以在 /shared/logs/seafile/seafile.log 文件中看到 seaf-server 的日志

/shared/ssl: 存放证书的目录，默认不存在

#### 升级 Seafile 服务
如果要升级 Seafile 服务到最新版本：

docker pull docker.seafile.top/seafileltd/seafile-pro-mc:latest

docker-compose down

docker-compose up -d


#### 备份和恢复
目录结构
我们假设您的 seafile 数据卷路径是 /opt/seafile-data，并且您想将备份数据存放到 /opt/seafile-backup 目录下。

您可以创建一个类似以下 /opt/seafile-backup 的目录结构：

/opt/seafile-backup

---- databases/  用来存放 MySQL 容器的备份数据

---- data/  用来存放 Seafile 容器的备份数据


要备份的数据文件：

/opt/seafile-data/seafile/conf  # configuration files

/opt/seafile-data/seafile/seafile-data # data of seafile

/opt/seafile-data/seafile/seahub-data # data of seahub


#### 备份数据
 步骤：

备份 MySQL 数据库数据；

备份 Seafile 数据目录；

备份数据库：
```
# 建议每次将数据库备份到一个单独的文件中。至少在一周内不要覆盖旧的数据库备份。

cd /opt/seafile-backup/databases

docker exec -it seafile-mysql mysqldump  -uroot --opt ccnet_db > ccnet_db.sql

docker exec -it seafile-mysql mysqldump  -uroot --opt seafile_db > seafile_db.sql

docker exec -it seafile-mysql mysqldump  -uroot --opt seahub_db > seahub_db.sql
```

备份 Seafile 资料库数据：

直接复制整个数据目录
```
cp -R /opt/seafile-data/seafile /opt/seafile-backup/data/

cd /opt/seafile-backup/data && rm -rf ccnet

```
使用 rsync 执行增量备份
```
rsync -az /opt/seafile-data/seafile /opt/seafile-backup/data/

cd /opt/seafile-backup/data && rm -rf ccnet

```
恢复数据
恢复数据库：
```
docker cp /opt/seafile-backup/databases/ccnet_db.sql seafile-mysql:/tmp/ccnet_db.sql

docker cp /opt/seafile-backup/databases/seafile_db.sql seafile-mysql:/tmp/seafile_db.sql

docker cp /opt/seafile-backup/databases/seahub_db.sql seafile-mysql:/tmp/seahub_db.sql

﻿
docker exec -it seafile-mysql /bin/sh -c "mysql -uroot ccnet_db < /tmp/ccnet_db.sql"

docker exec -it seafile-mysql /bin/sh -c "mysql -uroot seafile_db < /tmp/seafile_db.sql"

docker exec -it seafile-mysql /bin/sh -c "mysql -uroot seahub_db < /tmp/seahub_db.sql"
```

恢复 seafile 数据：
```
cp -R /opt/seafile-backup/data/* /opt/seafile-data/seafile/
```

#### 垃圾回收
在 seafile 中，当文件被删除时，组成这些文件的块数据不会立即删除，因为可能有其他文件也会引用这些块数据(用于去重功能的实现)。为了真正删除无用的块数据，还需要额外运行"GC"程序。GC 会自动检测到哪些数据块不再被任何文件所引用，并清除它们。

GC 脚本被放在docker容器的 /scripts 目录下。执行 GC 的方法很简单：docker exec seafile /scripts/gc.sh。对于社区版来说，该程序会暂停 Seafile 服务，但这是一个相对较快的程序，一旦程序运行完成，Seafile 服务也会自动重新启动。而专业版提供了在线运行 GC 的功能，不会暂停 Seafile 服务。

问题排查
您可以运行 docker exec 之类的docker命令来查找错误。
```
docker exec -it seafile /bin/bash
```

![image.png](https://img.hacpai.com/file/2019/06/image-1d5e299c.png)
