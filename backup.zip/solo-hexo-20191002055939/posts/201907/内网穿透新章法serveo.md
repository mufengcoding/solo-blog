title: 内网穿透新章法 serveo
date: '2019-07-29 06:00:03'
updated: '2019-07-29 06:00:54'
tags: [内网穿透]
permalink: /articles/2019/07/29/1564394400425.html
---
非常非常适合临时对外演示的方案

步骤如下
1.本地起一个测试的web服务
```
/Users/mac/venv/typeidea/bin/python /Users/mac/PycharmProjects/typeidea-env/typeidea/manage.py runserver 8000
```
输出如下
```shell
System check identified no issues (0 silenced).
July 29, 2019 - 17:52:55
Django version 2.2.3, using settings 'typeidea.settings.develop'
Starting development server at http://127.0.0.1:8000/
Quit the server with CONTROL-C.
```
2.命令行执行
```
ssh -R 80:127.0.0.1:8000 serveo.net
```

![image.png](https://img.hacpai.com/file/2019/07/image-85ca295e.png)

3.浏览器访问https://frugi.serveo.net

![image.png](https://img.hacpai.com/file/2019/07/image-a4039c90.png)

是不是很方便，是不是很easy

据说是ngrok绝佳替代品

[poll1564394372337]


官网地址：

