title: 基于 caddy 提升 https 安全等级
date: '2018-11-25 08:41:02'
updated: '2018-11-25 08:45:05'
tags: [HTTPS, hsts, caddy]
permalink: /articles/2018/11/25/1543153259670.html
---
## 起因
最近由于工作无暇处理博客，昨天正好看了下博客，发现博客的https被降权到B,所以折腾一波，提高A+

## 基础环境
web:   caddy +jetty

## 降权原因

发到myssl那边提示的降权的主要原因是由于网站含有http的不安全链接，于是想起来，有个图片是直接引用某网站的http链接，将http搞成https

去掉tls 1.0协议,添加hsts强制https

![7042A846A1204AA6902FEFDD7A244ECEpng](https://img.hacpai.com/file/2018/11/7042A846A1204AA6902FEFDD7A244ECE-e16f4352.png)
## 测试
Myssl那边由于vps所在地原因，一直更新不了。所以采用国外的[SSL Server Test (Powered by Qualys SSL Labs)](https://www.ssllabs.com/ssltest/)测试结果如下图
![D6165E07AA8142B9A8642199ECC880C4png](https://img.hacpai.com/file/2018/11/D6165E07AA8142B9A8642199ECC880C4-a13b6dc1.png)

另外也附上myssl没有实时更新的图




![11CC92A2A6664A30B4F944B927E9A781png](https://img.hacpai.com/file/2018/11/11CC92A2A6664A30B4F944B927E9A781-dc20ecf8.png)




## 附录
1.获取caddy，安装脚本
https://getcaddy.com/

2.caddy文档
[tls - Caddy User Guide](https://caddyserver.com/docs/tls)

3.myssl
https://myssl.com/
