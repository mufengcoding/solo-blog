title: 关于 ss 用不了代替方案
date: '2019-03-10 13:02:20'
updated: '2019-03-10 13:02:20'
tags: [科学上网]
permalink: /articles/2019/03/10/1552237340125.html
---
> [沐风](https://blog.mufengs.com)

最近ss用不了，不知道什么原因，可以ping通都是正常的，不愿意折腾

于是有了这个替代方案

最后参数代表的是你vps的帐号和IP
```
ssh -qTfnN -D 10086 root@192.16.9.2
```

-q Quiet mode. 安静模式，忽略一切对话和错误提示。  
-T Disable pseudo-tty allocation. 不占用 shell 了。  
-f Requests ssh to go to background just before command execution. 后台运行，并推荐加上 -n 参数。  
-n Redirects stdin from /dev/null (actually, prevents reading from stdin). -f 推荐的，不加这条参数应该也行。  
-N Do not execute a remote command. 不执行远程命令，专为端口转发度身打造。


浏览下载ProxySwitchy

[ProxySwitchyOmega25150.crx.zip](https://img.hacpai.com/file/2019/03/ProxySwitchyOmega25150.crx-9d2e5dac.zip)

拖拽到chrome的扩展程序中

配置ProxySwitchy
![image.png](https://img.hacpai.com/file/2019/03/image-78bf3250.png)

科学上网就是这么快，没有那么多华丽胡哨的

简单粗暴




