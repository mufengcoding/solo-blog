title: Centos8 安装飞行舱和 docker
date: '2019-11-01 05:59:00'
updated: '2019-11-01 05:59:00'
tags: [CentOS, Docker]
permalink: /articles/2019/11/01/1572602337997.html
---
最小化安装
选择了开发的包

有个不理解的就是centos8只出现了dvd的包，还没有出现mini的

# 安装飞行舱
```
#yum install  -y *cockpit*

#systemctl start cockpit

# systemctl enable --now cockpit.socket
```
效果图如下
![image.png](https://img.hacpai.com/file/2019/11/image-ce8e4524.png)


# 安装docker
```
yum install docker-ce
```
安装过程中报错了
问题: **package docker-ce-3:19.03.4-3.el7.x86_64 requires containerd.io >= 1.2.2-3, but none of the providers can be installed**


去docker的官方repo里面看到centos8并没有，只有7的，所以下载了一个最新的
https://download.docker.com/linux/centos/7/x86_64/stable/Packages/
![image.png](https://img.hacpai.com/file/2019/11/image-47df197e.png)

执行yum localinstall containerd.io-1.2.10-3.2.el7.x86_64.rpm,安装成功


ansible的playbook配置

```
---
- name: 安装docker服务
  hosts: swarm
  
  tasks:
    - name: copy file to nodes
      copy:
        src: /etc/yum.repos.d/docker-ce.repo
        dest: /etc/yum.repos.d/
      
    - name: install docker sofoware 
      yum: 
        name: docker-ce  
        state: latest
        
    - name: start end enable docker service
      service: name=docker  enabled=yes state=started

```

其中有一台机器出现出了bug

部署Portainer 访问报错 consider tuning tcp_mem
https://yeadoc.cn/2018/05/15/TCP-MEM%E5%B0%8F%E5%AF%BC%E8%87%B4%E4%B8%8B%E8%BD%BD%E6%85%A2%E6%88%96%E6%97%A0%E6%B3%95%E4%B8%8B%E8%BD%BD/


修改一下配置解决
```
echo "net.ipv4.tcp_mem = 39513 5268 88000" >> /etc/sysctl.conf
sysctl -p
```
