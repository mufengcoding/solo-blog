title: Django 基础入门篇（二）
date: '2019-06-17 10:22:16'
updated: '2019-06-17 10:22:16'
tags: [Python]
permalink: /articles/2019/06/17/1560781336455.html
---
距离上次的已有一个多月，由于各种事情耽搁了学习进度

![image.png](https://img.hacpai.com/file/2019/06/image-5685a2a7.png)
前台页面展示
![image.png](https://img.hacpai.com/file/2019/06/image-b34acc78.png)


项目目录结构
`tree -I "node_modules|__pycache__" > tree.md	`

```
.
├── Tempeletes
│   ├── base.html
│   ├── blog
│   │   ├── _post.html
│   │   ├── index.html
│   │   └── post.html
│   └── nginxconf
│       ├── _post.html
│       ├── index.html
│       └── post.html
├── api
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── migrations
│   │   └── __init__.py
│   ├── models.py
│   ├── tests.py
│   ├── urls.py
│   └── views.py
├── appextra
│   └── DjangoUeditor
│       ├── DjangoUeditor
│       │   ├── __init__.py
│       │   ├── commands.py
│       │   ├── forms.py
│       │   ├── models.py
│       │   ├── settings.py
│       │   ├── static
│       │   │   └── ueditor
│       │   │       ├── UEditorSnapscreen.exe
│       │   │       ├── _examples
│       │   │       │   ├── addCustomizeButton.js
│       │   │       │   ├── addCustomizeCombox.js
│       │   │       │   ├── addCustomizeDialog.js
│       │   │       │   ├── charts.html
│       │   │       │   ├── completeDemo.html
│       │   │       │   ├── customPluginDemo.html
│       │   │       │   ├── customToolbarDemo.html
│       │   │       │   ├── customizeDialogPage.html
│       │   │       │   ├── customizeToolbarUIDemo.html
│       │   │       │   ├── editor_api.js
│       │   │       │   ├── filterRuleDemo.html
│       │   │       │   ├── highlightDemo.html
│       │   │       │   ├── index.html
│       │   │       │   ├── jqueryCompleteDemo.html
│       │   │       │   ├── jqueryValidation.html
│       │   │       │   ├── multiDemo.html
│       │   │       │   ├── multiEditorWithOneInstance.html
│       │   │       │   ├── renderInTable.html
│       │   │       │   ├── resetDemo.html
│       │   │       │   ├── sectiondemo.html
│       │   │       │   ├── server
│       │   │       │   │   ├── getContent.ashx
│       │   │       │   │   ├── getContent.asp
│       │   │       │   │   ├── getContent.jsp
│       │   │       │   │   └── getContent.php
│       │   │       │   ├── setWidthHeightDemo.html
│       │   │       │   ├── simpleDemo.html
│       │   │       │   ├── sortableDemo.html
│       │   │       │   ├── submitFormDemo.html
│       │   │       │   ├── textareaDemo.html
│       │   │       │   └── uparsedemo.html
│       │   │       ├── dialogs
│       │   │       │   ├── anchor
│       │   │       │   │   └── anchor.html
│       │   │       │   ├── attachment
│       │   │       │   │   ├── attachment.css
│       │   │       │   │   ├── attachment.html
│       │   │       │   │   ├── attachment.js
│       │   │       │   │   ├── fileTypeImages
│       │   │       │   │   │   ├── icon_chm.gif
│       │   │       │   │   │   ├── icon_default.png
│       │   │       │   │   │   ├── icon_doc.gif
│       │   │       │   │   │   ├── icon_exe.gif
│       │   │       │   │   │   ├── icon_jpg.gif
│       │   │       │   │   │   ├── icon_mp3.gif
│       │   │       │   │   │   ├── icon_mv.gif
│       │   │       │   │   │   ├── icon_pdf.gif
│       │   │       │   │   │   ├── icon_ppt.gif
│       │   │       │   │   │   ├── icon_psd.gif
│       │   │       │   │   │   ├── icon_rar.gif
│       │   │       │   │   │   ├── icon_txt.gif
│       │   │       │   │   │   └── icon_xls.gif
│       │   │       │   │   └── images
│       │   │       │   │       ├── alignicon.gif
│       │   │       │   │       ├── alignicon.png
│       │   │       │   │       ├── bg.png
│       │   │       │   │       ├── file-icons.gif
│       │   │       │   │       ├── file-icons.png
│       │   │       │   │       ├── icons.gif
│       │   │       │   │       ├── icons.png
│       │   │       │   │       ├── image.png
│       │   │       │   │       ├── progress.png
│       │   │       │   │       ├── success.gif
│       │   │       │   │       └── success.png
│       │   │       │   ├── background
│       │   │       │   │   ├── background.css
│       │   │       │   │   ├── background.html
│       │   │       │   │   ├── background.js
│       │   │       │   │   └── images
│       │   │       │   │       ├── bg.png
│       │   │       │   │       └── success.png
│       │   │       │   ├── charts
│       │   │       │   │   ├── chart.config.js
│       │   │       │   │   ├── charts.css
│       │   │       │   │   ├── charts.html
│       │   │       │   │   ├── charts.js
│       │   │       │   │   └── images
│       │   │       │   │       ├── charts0.png
│       │   │       │   │       ├── charts1.png
│       │   │       │   │       ├── charts2.png
│       │   │       │   │       ├── charts3.png
│       │   │       │   │       ├── charts4.png
│       │   │       │   │       └── charts5.png
│       │   │       │   ├── emotion
│       │   │       │   │   ├── emotion.css
│       │   │       │   │   ├── emotion.html
│       │   │       │   │   ├── emotion.js
│       │   │       │   │   └── images
│       │   │       │   │       ├── 0.gif
│       │   │       │   │       ├── bface.gif
│       │   │       │   │       ├── cface.gif
│       │   │       │   │       ├── fface.gif
│       │   │       │   │       ├── jxface2.gif
│       │   │       │   │       ├── neweditor-tab-bg.png
│       │   │       │   │       ├── tface.gif
│       │   │       │   │       ├── wface.gif
│       │   │       │   │       └── yface.gif
│       │   │       │   ├── gmap
│       │   │       │   │   └── gmap.html
│       │   │       │   ├── help
│       │   │       │   │   ├── help.css
│       │   │       │   │   ├── help.html
│       │   │       │   │   └── help.js
│       │   │       │   ├── image
│       │   │       │   │   ├── image.css
│       │   │       │   │   ├── image.html
│       │   │       │   │   ├── image.js
│       │   │       │   │   └── images
│       │   │       │   │       ├── alignicon.jpg
│       │   │       │   │       ├── bg.png
│       │   │       │   │       ├── icons.gif
│       │   │       │   │       ├── icons.png
│       │   │       │   │       ├── image.png
│       │   │       │   │       ├── progress.png
│       │   │       │   │       ├── success.gif
│       │   │       │   │       └── success.png
│       │   │       │   ├── insertframe
│       │   │       │   │   └── insertframe.html
│       │   │       │   ├── internal.js
│       │   │       │   ├── link
│       │   │       │   │   └── link.html
│       │   │       │   ├── map
│       │   │       │   │   ├── map.html
│       │   │       │   │   └── show.html
│       │   │       │   ├── music
│       │   │       │   │   ├── music.css
│       │   │       │   │   ├── music.html
│       │   │       │   │   └── music.js
│       │   │       │   ├── preview
│       │   │       │   │   └── preview.html
│       │   │       │   ├── scrawl
│       │   │       │   │   ├── images
│       │   │       │   │   │   ├── addimg.png
│       │   │       │   │   │   ├── brush.png
│       │   │       │   │   │   ├── delimg.png
│       │   │       │   │   │   ├── delimgH.png
│       │   │       │   │   │   ├── empty.png
│       │   │       │   │   │   ├── emptyH.png
│       │   │       │   │   │   ├── eraser.png
│       │   │       │   │   │   ├── redo.png
│       │   │       │   │   │   ├── redoH.png
│       │   │       │   │   │   ├── scale.png
│       │   │       │   │   │   ├── scaleH.png
│       │   │       │   │   │   ├── size.png
│       │   │       │   │   │   ├── undo.png
│       │   │       │   │   │   └── undoH.png
│       │   │       │   │   ├── scrawl.css
│       │   │       │   │   ├── scrawl.html
│       │   │       │   │   └── scrawl.js
│       │   │       │   ├── searchreplace
│       │   │       │   │   ├── searchreplace.html
│       │   │       │   │   └── searchreplace.js
│       │   │       │   ├── snapscreen
│       │   │       │   │   └── snapscreen.html
│       │   │       │   ├── spechars
│       │   │       │   │   ├── spechars.html
│       │   │       │   │   └── spechars.js
│       │   │       │   ├── table
│       │   │       │   │   ├── dragicon.png
│       │   │       │   │   ├── edittable.css
│       │   │       │   │   ├── edittable.html
│       │   │       │   │   ├── edittable.js
│       │   │       │   │   ├── edittd.html
│       │   │       │   │   └── edittip.html
│       │   │       │   ├── template
│       │   │       │   │   ├── config.js
│       │   │       │   │   ├── images
│       │   │       │   │   │   ├── bg.gif
│       │   │       │   │   │   ├── pre0.png
│       │   │       │   │   │   ├── pre1.png
│       │   │       │   │   │   ├── pre2.png
│       │   │       │   │   │   ├── pre3.png
│       │   │       │   │   │   └── pre4.png
│       │   │       │   │   ├── template.css
│       │   │       │   │   ├── template.html
│       │   │       │   │   └── template.js
│       │   │       │   ├── video
│       │   │       │   │   ├── images
│       │   │       │   │   │   ├── bg.png
│       │   │       │   │   │   ├── center_focus.jpg
│       │   │       │   │   │   ├── file-icons.gif
│       │   │       │   │   │   ├── file-icons.png
│       │   │       │   │   │   ├── icons.gif
│       │   │       │   │   │   ├── icons.png
│       │   │       │   │   │   ├── image.png
│       │   │       │   │   │   ├── left_focus.jpg
│       │   │       │   │   │   ├── none_focus.jpg
│       │   │       │   │   │   ├── progress.png
│       │   │       │   │   │   ├── right_focus.jpg
│       │   │       │   │   │   ├── success.gif
│       │   │       │   │   │   └── success.png
│       │   │       │   │   ├── video.css
│       │   │       │   │   ├── video.html
│       │   │       │   │   └── video.js
│       │   │       │   ├── webapp
│       │   │       │   │   └── webapp.html
│       │   │       │   └── wordimage
│       │   │       │       ├── fClipboard_ueditor.swf
│       │   │       │       ├── imageUploader.swf
│       │   │       │       ├── tangram.js
│       │   │       │       ├── wordimage.html
│       │   │       │       └── wordimage.js
│       │   │       ├── index.html
│       │   │       ├── lang
│       │   │       │   ├── en
│       │   │       │   │   ├── en.js
│       │   │       │   │   └── images
│       │   │       │   │       ├── addimage.png
│       │   │       │   │       ├── alldeletebtnhoverskin.png
│       │   │       │   │       ├── alldeletebtnupskin.png
│       │   │       │   │       ├── background.png
│       │   │       │   │       ├── button.png
│       │   │       │   │       ├── copy.png
│       │   │       │   │       ├── deletedisable.png
│       │   │       │   │       ├── deleteenable.png
│       │   │       │   │       ├── listbackground.png
│       │   │       │   │       ├── localimage.png
│       │   │       │   │       ├── music.png
│       │   │       │   │       ├── rotateleftdisable.png
│       │   │       │   │       ├── rotateleftenable.png
│       │   │       │   │       ├── rotaterightdisable.png
│       │   │       │   │       ├── rotaterightenable.png
│       │   │       │   │       └── upload.png
│       │   │       │   └── zh-cn
│       │   │       │       ├── images
│       │   │       │       │   ├── copy.png
│       │   │       │       │   ├── localimage.png
│       │   │       │       │   ├── music.png
│       │   │       │       │   └── upload.png
│       │   │       │       └── zh-cn.js
│       │   │       ├── php
│       │   │       │   ├── Uploader.class.php
│       │   │       │   ├── action_crawler.php
│       │   │       │   ├── action_list.php
│       │   │       │   ├── action_upload.php
│       │   │       │   ├── config.json
│       │   │       │   └── controller.php
│       │   │       ├── themes
│       │   │       │   ├── default
│       │   │       │   │   ├── css
│       │   │       │   │   │   ├── ueditor.css
│       │   │       │   │   │   └── ueditor.min.css
│       │   │       │   │   ├── dialogbase.css
│       │   │       │   │   └── images
│       │   │       │   │       ├── anchor.gif
│       │   │       │   │       ├── arrow.png
│       │   │       │   │       ├── arrow_down.png
│       │   │       │   │       ├── arrow_up.png
│       │   │       │   │       ├── button-bg.gif
│       │   │       │   │       ├── cancelbutton.gif
│       │   │       │   │       ├── charts.png
│       │   │       │   │       ├── cursor_h.gif
│       │   │       │   │       ├── cursor_h.png
│       │   │       │   │       ├── cursor_v.gif
│       │   │       │   │       ├── cursor_v.png
│       │   │       │   │       ├── dialog-title-bg.png
│       │   │       │   │       ├── filescan.png
│       │   │       │   │       ├── highlighted.gif
│       │   │       │   │       ├── icons-all.gif
│       │   │       │   │       ├── icons.gif
│       │   │       │   │       ├── icons.png
│       │   │       │   │       ├── loaderror.png
│       │   │       │   │       ├── loading.gif
│       │   │       │   │       ├── lock.gif
│       │   │       │   │       ├── neweditor-tab-bg.png
│       │   │       │   │       ├── pagebreak.gif
│       │   │       │   │       ├── scale.png
│       │   │       │   │       ├── sortable.png
│       │   │       │   │       ├── spacer.gif
│       │   │       │   │       ├── sparator_v.png
│       │   │       │   │       ├── table-cell-align.png
│       │   │       │   │       ├── tangram-colorpicker.png
│       │   │       │   │       ├── toolbar_bg.png
│       │   │       │   │       ├── unhighlighted.gif
│       │   │       │   │       ├── upload.png
│       │   │       │   │       ├── videologo.gif
│       │   │       │   │       ├── word.gif
│       │   │       │   │       └── wordpaste.png
│       │   │       │   └── iframe.css
│       │   │       ├── third-party
│       │   │       │   ├── SyntaxHighlighter
│       │   │       │   │   ├── shCore.js
│       │   │       │   │   └── shCoreDefault.css
│       │   │       │   ├── codemirror
│       │   │       │   │   ├── codemirror.css
│       │   │       │   │   └── codemirror.js
│       │   │       │   ├── highcharts
│       │   │       │   │   ├── adapters
│       │   │       │   │   │   ├── mootools-adapter.js
│       │   │       │   │   │   ├── mootools-adapter.src.js
│       │   │       │   │   │   ├── prototype-adapter.js
│       │   │       │   │   │   ├── prototype-adapter.src.js
│       │   │       │   │   │   ├── standalone-framework.js
│       │   │       │   │   │   └── standalone-framework.src.js
│       │   │       │   │   ├── highcharts-more.js
│       │   │       │   │   ├── highcharts-more.src.js
│       │   │       │   │   ├── highcharts.js
│       │   │       │   │   ├── highcharts.src.js
│       │   │       │   │   ├── modules
│       │   │       │   │   │   ├── annotations.js
│       │   │       │   │   │   ├── annotations.src.js
│       │   │       │   │   │   ├── canvas-tools.js
│       │   │       │   │   │   ├── canvas-tools.src.js
│       │   │       │   │   │   ├── data.js
│       │   │       │   │   │   ├── data.src.js
│       │   │       │   │   │   ├── drilldown.js
│       │   │       │   │   │   ├── drilldown.src.js
│       │   │       │   │   │   ├── exporting.js
│       │   │       │   │   │   ├── exporting.src.js
│       │   │       │   │   │   ├── funnel.js
│       │   │       │   │   │   ├── funnel.src.js
│       │   │       │   │   │   ├── heatmap.js
│       │   │       │   │   │   ├── heatmap.src.js
│       │   │       │   │   │   ├── map.js
│       │   │       │   │   │   ├── map.src.js
│       │   │       │   │   │   ├── no-data-to-display.js
│       │   │       │   │   │   └── no-data-to-display.src.js
│       │   │       │   │   └── themes
│       │   │       │   │       ├── dark-blue.js
│       │   │       │   │       ├── dark-green.js
│       │   │       │   │       ├── gray.js
│       │   │       │   │       ├── grid.js
│       │   │       │   │       └── skies.js
│       │   │       │   ├── jquery-1.10.2.js
│       │   │       │   ├── jquery-1.10.2.min.js
│       │   │       │   ├── jquery-1.10.2.min.map
│       │   │       │   ├── snapscreen
│       │   │       │   │   └── UEditorSnapscreen.exe
│       │   │       │   ├── video-js
│       │   │       │   │   ├── font
│       │   │       │   │   │   ├── vjs.eot
│       │   │       │   │   │   ├── vjs.svg
│       │   │       │   │   │   ├── vjs.ttf
│       │   │       │   │   │   └── vjs.woff
│       │   │       │   │   ├── video-js.css
│       │   │       │   │   ├── video-js.min.css
│       │   │       │   │   ├── video-js.swf
│       │   │       │   │   ├── video.dev.js
│       │   │       │   │   └── video.js
│       │   │       │   ├── webuploader
│       │   │       │   │   ├── Uploader.swf
│       │   │       │   │   ├── webuploader.css
│       │   │       │   │   ├── webuploader.custom.js
│       │   │       │   │   ├── webuploader.custom.min.js
│       │   │       │   │   ├── webuploader.flashonly.js
│       │   │       │   │   ├── webuploader.flashonly.min.js
│       │   │       │   │   ├── webuploader.html5only.js
│       │   │       │   │   ├── webuploader.html5only.min.js
│       │   │       │   │   ├── webuploader.js
│       │   │       │   │   ├── webuploader.min.js
│       │   │       │   │   ├── webuploader.withoutimage.js
│       │   │       │   │   └── webuploader.withoutimage.min.js
│       │   │       │   └── zeroclipboard
│       │   │       │       ├── ZeroClipboard.js
│       │   │       │       ├── ZeroClipboard.min.js
│       │   │       │       └── ZeroClipboard.swf
│       │   │       ├── ueditor.all.js
│       │   │       ├── ueditor.all.min.js
│       │   │       ├── ueditor.config.js
│       │   │       ├── ueditor.parse.js
│       │   │       └── ueditor.parse.min.js
│       │   ├── templates
│       │   │   ├── ueditor.html
│       │   │   └── ueditor_old.html
│       │   ├── urls.py
│       │   ├── utils.py
│       │   ├── views.py
│       │   └── widgets.py
│       ├── PKG-INFO
│       ├── build
│       │   └── lib
│       │       └── DjangoUeditor
│       │           ├── __init__.py
│       │           ├── commands.py
│       │           ├── forms.py
│       │           ├── models.py
│       │           ├── settings.py
│       │           ├── urls.py
│       │           ├── utils.py
│       │           ├── views.py
│       │           └── widgets.py
│       └── setup.py
├── blog
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── migrations
│   │   ├── 0001_initial.py
│   │   ├── 0002_auto_20190508_1411.py
│   │   └── __init__.py
│   ├── models.py
│   ├── static
│   │   └── layui
│   │       ├── css
│   │       │   ├── layui.css
│   │       │   ├── layui.mobile.css
│   │       │   └── modules
│   │       │       ├── code.css
│   │       │       ├── laydate
│   │       │       │   └── default
│   │       │       │       └── laydate.css
│   │       │       └── layer
│   │       │           └── default
│   │       │               ├── icon-ext.png
│   │       │               ├── icon.png
│   │       │               ├── layer.css
│   │       │               ├── loading-0.gif
│   │       │               ├── loading-1.gif
│   │       │               └── loading-2.gif
│   │       ├── font
│   │       │   ├── iconfont.eot
│   │       │   ├── iconfont.svg
│   │       │   ├── iconfont.ttf
│   │       │   └── iconfont.woff
│   │       ├── images
│   │       │   └── face
│   │       │       ├── 0.gif
│   │       │       ├── 1.gif
│   │       │       ├── 10.gif
│   │       │       ├── 11.gif
│   │       │       ├── 12.gif
│   │       │       ├── 13.gif
│   │       │       ├── 14.gif
│   │       │       ├── 15.gif
│   │       │       ├── 16.gif
│   │       │       ├── 17.gif
│   │       │       ├── 18.gif
│   │       │       ├── 19.gif
│   │       │       ├── 2.gif
│   │       │       ├── 20.gif
│   │       │       ├── 21.gif
│   │       │       ├── 22.gif
│   │       │       ├── 23.gif
│   │       │       ├── 24.gif
│   │       │       ├── 25.gif
│   │       │       ├── 26.gif
│   │       │       ├── 27.gif
│   │       │       ├── 28.gif
│   │       │       ├── 29.gif
│   │       │       ├── 3.gif
│   │       │       ├── 30.gif
│   │       │       ├── 31.gif
│   │       │       ├── 32.gif
│   │       │       ├── 33.gif
│   │       │       ├── 34.gif
│   │       │       ├── 35.gif
│   │       │       ├── 36.gif
│   │       │       ├── 37.gif
│   │       │       ├── 38.gif
│   │       │       ├── 39.gif
│   │       │       ├── 4.gif
│   │       │       ├── 40.gif
│   │       │       ├── 41.gif
│   │       │       ├── 42.gif
│   │       │       ├── 43.gif
│   │       │       ├── 44.gif
│   │       │       ├── 45.gif
│   │       │       ├── 46.gif
│   │       │       ├── 47.gif
│   │       │       ├── 48.gif
│   │       │       ├── 49.gif
│   │       │       ├── 5.gif
│   │       │       ├── 50.gif
│   │       │       ├── 51.gif
│   │       │       ├── 52.gif
│   │       │       ├── 53.gif
│   │       │       ├── 54.gif
│   │       │       ├── 55.gif
│   │       │       ├── 56.gif
│   │       │       ├── 57.gif
│   │       │       ├── 58.gif
│   │       │       ├── 59.gif
│   │       │       ├── 6.gif
│   │       │       ├── 60.gif
│   │       │       ├── 61.gif
│   │       │       ├── 62.gif
│   │       │       ├── 63.gif
│   │       │       ├── 64.gif
│   │       │       ├── 65.gif
│   │       │       ├── 66.gif
│   │       │       ├── 67.gif
│   │       │       ├── 68.gif
│   │       │       ├── 69.gif
│   │       │       ├── 7.gif
│   │       │       ├── 70.gif
│   │       │       ├── 71.gif
│   │       │       ├── 8.gif
│   │       │       └── 9.gif
│   │       ├── lay
│   │       │   └── modules
│   │       │       ├── carousel.js
│   │       │       ├── code.js
│   │       │       ├── colorpicker.js
│   │       │       ├── element.js
│   │       │       ├── flow.js
│   │       │       ├── form.js
│   │       │       ├── jquery.js
│   │       │       ├── laydate.js
│   │       │       ├── layedit.js
│   │       │       ├── layer.js
│   │       │       ├── laypage.js
│   │       │       ├── laytpl.js
│   │       │       ├── mobile.js
│   │       │       ├── rate.js
│   │       │       ├── slider.js
│   │       │       ├── table.js
│   │       │       ├── tree.js
│   │       │       ├── upload.js
│   │       │       └── util.js
│   │       ├── layui.all.js
│   │       └── layui.js
│   ├── tests.py
│   ├── urls.py
│   └── views.py
├── course
│   └── resource
│       └── image
│           └── 5
│               └── 8
│                   └── 1PF6135619-2_20190508140040_671.jpg
├── db.sqlite3
├── dblog
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── manage.py
├── nginx_conf
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── migrations
│   │   ├── 0001_initial.py
│   │   └── __init__.py
│   ├── models.py
│   ├── nginxfile
│   │   ├── nginx.conf
│   │   └── web.conf
│   ├── tests.py
│   ├── urls.py
│   └── views.py
├── python-nmap-0.6.1
│   ├── CHANGELOG
│   ├── MANIFEST.in
│   ├── Makefile
│   ├── PKG-INFO
│   ├── README.txt
│   ├── build
│   │   └── lib
│   │       └── nmap
│   │           ├── __init__.py
│   │           ├── nmap.py
│   │           ├── test.py
│   │           └── test_nmap.py
│   ├── example.py
│   ├── gpl-3.0.txt
│   ├── nmap.html
│   ├── requirements.txt
│   └── setup.py
├── python-nmap-0.6.1.tar.gz
└── tree.md

98 directories, 495 files

```

修改后台登陆密码

python manage.py changepassword mufengs

![image.png](https://img.hacpai.com/file/2019/06/image-4cbf49e1.png)

后台编辑器使用的是DjangoUeditor
![image.png](https://img.hacpai.com/file/2019/06/image-8229326f.png)

新建项目
`django-admin startproject dblog`
创建子应用
`python manage.py startapp blog`

全局路由
![image.png](https://img.hacpai.com/file/2019/06/image-b98c37cf.png)

子应用路由
![image.png](https://img.hacpai.com/file/2019/06/image-cea11342.png)

基于snmp的ping检查
![image.png](https://img.hacpai.com/file/2019/06/image-ba50cb63.png)
![image.png](https://img.hacpai.com/file/2019/06/image-34463c00.png)




总体还是比较乱的。

下面 实现应用域名对应列表，实现查询功能~~~~~~~~

