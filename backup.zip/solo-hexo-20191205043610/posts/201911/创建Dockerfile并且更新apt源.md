title: 创建 Dockerfile 并且更新 apt 源
date: '2019-11-13 22:15:40'
updated: '2019-11-13 22:15:40'
tags: [Docker]
permalink: /articles/2019/11/13/1573701338469.html
---
在Dockerfile中添加如下两句代码：

```
1. RUN sed -i s@/archive.ubuntu.com/@/mirrors.aliyun.com/@g /etc/apt/sources.list
    
2. RUN apt-get clean
```

