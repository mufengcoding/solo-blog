title: shell 基础强化笔记 ( 二）
date: '2019-12-02 10:37:39'
updated: '2019-12-02 10:38:46'
tags: [运维, Shell]
permalink: /articles/2019/12/02/1575301055418.html
---

## 1.杂谈

shift+>缩进，v进入选择模式

seq命令用于产生从某个数到另外一个数之间的所有整数。

## 2.批量ping存活主机
```shell
 #!/bin/bash  
 for i in {1..254}  
 do  
  {  
  ip=120.255.0.$i  
  ping -c 1 -W 1 $ip &>/dev/null  
  if [ $? -eq 0 ];then  
  echo "$ip is ok"  
  else  
  echo "$ip is down"  
  fi  
  }&  
 done  
 wait  
 echo "ping is done"
```
## 3.批量判断是否22端口开启
```shell
 #!/bin/bash  
 >/tmp/activIp.log  
 for i in {1..254}  
 do  
  {  
  ip=120.255.0.$i  
  ping -c 1 -W 1 $ip &>/dev/null  
  if [ $? -eq 0 ];then  
  echo "$i. $ip is ok">>/tmp/activIp.log  
  else  
  echo "$i. $ip is down"  
  fi  
  }&  
 done  
 ​
 wait  
 echo "Scan ping is done"  
 echo "Scan port starting ..."  
 ​  
 IFS=$'\n'  
 for i in $(cat /tmp/activIp.log)  
 do  
  ip=$(echo $i |awk '{print $2}')  
  echo $ip  
  nmap $ip |grep "22" &>/dev/null  
 ​  
  if [ $? -eq 0 ];then  
  echo "$ip Port 22 is open!"  
  else  
  echo "$ip Port 22 is down!"  
  fi  
 done
```

## 4. mysql主从监测恢复脚本  
  
其中for循环中的{}&表示并发编程的意思
```shell
 #!/bin/bash  
 IO_Status=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Slave_IO_Running:/ {print $2}'|sed 's/\r//')  
 SQL_Status=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Slave_SQL_Running:/ {print $2}'|sed 's/\r//')  
 ​  
 if [ "$IO_Status" == "Yes" ] && [ "$SQL_Status" == "Yes" ];then  
  echo "数据库主从同步正常！"  
 else  
  echo "数据库主从同步失败!"  
  if [ ! "$IO_Status" == "Yes" ];then  
  IO_Err=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Last_IO/')  
  echo -e "\033[31m Mysql slave 链接异常 \033[0m \n $IO_Err"  
  fi  
  if [ ! "$SQL_Status" == "Yes" ];then  
  IO_Err=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Last_SQL_Errno:/ {print $2}'|sed 's/\r//')  
  echo -e "\033[31m Mysql slave Sql异常 \033[0m \n $IO_Err"  
  case $IO_Err in  
  1007)  
  sleep 2;  
  docker exec -it msmysql mysql -u root -p123456 -e "stop slave;set global sql_slave_skip_counter=1;start slave;"  
  IO_Err=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Last_SQL_Errno:/ {print $2}'|sed 's/\r//')  
  if [ $IO_Err -eq 0 ];then  
  echo "尝试跳过一次，主从恢复正常"  
  else  
  IO_Err2=$(docker exec -it msmysql mysql -u root -p123456 -e "show slave status\G"|awk '/Last_SQL_Err/')  
  echo "$IO_Err2"  
  echo "发邮件！"  
  fi  
  ;;  
  1008)  
  echo "发邮件！"  
  ;;  
  *)  
  echo "发邮件！"  
  esac  
  fi  
 fi
```
快速搭建 mysql主从测试环境参考：
https://www.cnblogs.com/songwenjie/p/9371422.html


