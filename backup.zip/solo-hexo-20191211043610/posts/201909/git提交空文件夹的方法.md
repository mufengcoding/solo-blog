title: git提交空文件夹的方法
date: '2019-09-18 05:16:35'
updated: '2019-09-18 05:18:30'
tags: [Git]
permalink: /articles/2019/09/18/1568798195593.html
---
![](https://img.hacpai.com/bing/20180214.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在git项目的根目录下，执行下面语句：
```shell
find . -name .git -prune -o -type d -empty -exec touch {}/.gitignore \;
find . -name .git -prune -o -type d -empty -exec touch {}/.emptyFolders \;
```
效果图：
![image.png](https://img.hacpai.com/file/2019/09/image-87c76d66.png)

原因大致是这样的，git始终只是关心文件的变化，而不关心目录，所以文件夹如果是空的话，就不会被提交到git仓库里面去。