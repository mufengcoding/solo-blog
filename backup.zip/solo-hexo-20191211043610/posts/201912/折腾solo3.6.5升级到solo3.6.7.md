title: 折腾 solo3.6.5 升级到 solo3.6.7
date: '2019-12-01 05:21:31'
updated: '2019-12-06 08:29:38'
tags: [Solo]
permalink: /articles/2019/12/01/1575195688729.html
---
## 1.前言
正好vps到期了，续费了下，顺便把博客升级下
搬瓦工蛮便宜的，一年也就是不到200¥，同样的价格在某里云和某讯估计买不到

## 2.为啥升级
因为之前跨版本升级的时候，不知道哪个地方搞错里，导致·偏好设置·打不开。恰巧要去设置一些东西，将网站里面的http链接去掉，防止影响到网站https的评价，毕竟还是喜欢看到A+的感觉
![image.png](https://img.hacpai.com/file/2019/12/image-a0cc637e.png)

## 3.升级心路历程

注：我用的是手工启动的方式，不用docker的原因的我的vps带不动，毕竟性能在那边。如果要跑mysql和容器的话，估计vps分分钟夯死，所以目前为止还是命令运行，h2做数据库，毕竟只是个blog也没有那么多流量和访问。

老规矩，之前的命令跑起来
```shell
wget [https://github.com/b3log/solo/releases/download/v3.6.7/solo-v3.6.7.zip](https://github.com/b3log/solo/releases/download/v3.6.7/solo-v3.6.7.zip)
```
what??? 直接404了，之前都可以的，不知所以的我，很懵逼。

404了没关系，浏览器还可以下载。打开我的mac的下载神器，proxyee-down-main
![image.png](https://img.hacpai.com/file/2019/12/image-3c99206d.png)
选择128线程，很就快下完了

文件拷贝到服务器上，然后解压直接运行
```
unzip solo-v3.6.7.zip -d blog3.6.7
nohup java -cp WEB-INF/lib/*:WEB-INF/classes org.b3log.solo.Starter >/dev/null 2>&1 &
```
what???没有WEB-INF这个文件，莫慌直接去看升级文档《 [Solo v3.6.7 发布，移除 Servlet 容器支持](https://hacpai.com/article/1573408539790)》，然后对比了下文件目录，原来是之前的war和zip目录结构不一样，没注意。

安装文档中的命令运行成功
···
nohup java -cp "lib/*:." org.b3log.solo.Server >/dev/null 2>&1 &
···

## 4. 后续问题

访问速度慢了

1.可能是网络问题有些头像从github加载的慢
2.网络不稳定

console有报错
![image.png](https://img.hacpai.com/file/2019/12/image-56569024.png)
忘记了之前有没有遇到过了😂 @Vanessa v姐有空帮忙看下哈

## 5. 后话

博客嘛，就是发一些东西或牢骚的地方，区别于社区。博客你可以随便发，社区大家经常发无聊的帖子的话，访客就会失去耐心寻找有价值的一部分。我之前觉的博客这样那样折腾挺牛逼，现在看来忘记了搭博客的初衷啊，搭博客就是为了写东西分享对不对，对于一个想写点或者记点东西的人来说，就得不偿失了。一个好的博客框架比如solo，一套干净的皮肤，有趣的分享就够了。

各种框架或语言，为了解决相应的问题
但所有的路数，终将殊途同归。
无趣的人儿，千篇一律
有趣的灵魂，万里挑一
但所有的灵魂，终将归于尘土。




2019年，12月1日的夜晚，寒风凛冽，瑟瑟冻骨。
