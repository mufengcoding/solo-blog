title: solo3.0.0更新到3.1.0
date: '2019-03-02 11:06:08'
updated: '2019-03-02 11:23:25'
tags: [Solo]
permalink: /articles/2019/03/02/1551542170554.html
---
![](https://img.hacpai.com/bing/20181117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

>[沐风](https://blog.mufengs.com)

此次个人博客更新的目的：
1.看下往社区同步功能
2.泄密bug

## 1.下载war包
```
wget https://github.com/b3log/solo/releases/download/v3.1.0/solo-v3.1.0.war
```
## 2.解压到目录
```
unzip solo-v3.1.0.war -d blog3.1.0
```
## 3.复制备份文件
```
cp -r /root/blog/WEB-INF/classes/*.properties blog3.1.0/WEB-INF/classes/
```
这边选择性覆盖
![image.png](https://img.hacpai.com/file/2019/03/image-9c79deee.png)

## 4.重启博客
```
ps -ef |grep java |grep -v grep|cut -c 9-15|xargs kill -9
nohup java -cp WEB-INF/lib/*:WEB-INF/classes org.b3log.solo.Starter >/dev/null 2>&1 &
```
## 5.查看日志

```
tail -f blog3.1.0/solo.log
```
![image.png](https://img.hacpai.com/file/2019/03/image-3ef0c119.png)

## 6.收工测试
如果这篇文章同步到社区，表示升级成功
